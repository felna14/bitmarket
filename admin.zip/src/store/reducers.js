import { combineReducers } from '@reduxjs/toolkit';

import commonReducer from '../components/common/commonSlice';
// import dashboardReducer from "../components/logedAdmin/dashboard/dashboardSlice";
import loginReducer from '../components/login/loginSlice';
import forgotmodalReducer from '../components/forgotPasswordModal/ForgotSlice';
import resetPasswordReducer from '../components/resetPassword/ResetPasswordSlice';
import customerManagementReducer from '../components/logedAdmin/customerManagement/customerManagementSlice';
import categoryManagementReducer from '../components/logedAdmin/CategoryManagement/categorymanagementSlice';
import subCategoryReducer from '../components/logedAdmin/subCategoryManagement/subcategorymanagementSlice';
import vendorManagementReducer from '../components/logedAdmin/vendorManagement/vendorManagementSlice';
import ProductsManagementReducer from '../components/logedAdmin/products/ProductsSlice';
import changePasswordReducer from '../components/logedAdmin/AccountManagement/ChangePassword/ChangePasswordSlice';
import variantsReducer from '../components/logedAdmin/variantsModule/variantsmoduleSlice';
import profileManagementReducer from '../components/logedAdmin/AccountManagement/Profile/ProfileManagementSlice';
import BrowsernotificationReducer from '../components/common/notifications/NotificationSlice';
import orderReducer from '../components/logedAdmin/order/orderSlice';
import paymentReducer from '../components/logedAdmin/payment/paymentSlice';
import dashboardReducer from '../components/logedAdmin/dashboard/dashboardSlice';
import bannerReducer from '../components/logedAdmin/BannerManagement/BannerManagementSlice';
import WalletReducer from '../components/connectWallet/WalletSlice';

const rootReducer = combineReducers({
  common: commonReducer,
  loginReducer,
  forgotmodalReducer,
  resetPasswordReducer,
  customerManagementReducer,
  categoryManagementReducer,
  subCategoryReducer,
  vendorManagementReducer,
  ProductsManagementReducer,
  variantsReducer,
  changePasswordReducer,
  profileManagementReducer,
  BrowsernotificationReducer,
  orderReducer,
  paymentReducer,
  dashboardReducer,
  bannerReducer,
  WalletReducer,
});

export default rootReducer;
