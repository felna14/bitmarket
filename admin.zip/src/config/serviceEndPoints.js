const serviceEndpoints = {
  login: 'auth/login',
  category: 'admin/category',
  customer_list: 'admin/customer_management/list',
  customer_management: 'admin/customer_management',
  customer_status: 'admin/customer_management/change_status',
  vendor_management: 'admin/vendor_management',
  vendor_status: 'admin/vendor_management/change_status',
  vendor_update: 'admin/vendor_management/update',
  variants_module: 'admin/variant',
  variants_add: 'admin/variant/add_variant',
  products: 'admin/product',
  profile: 'admin/profile/get_profile',
  profile_update: 'admin/profile/update',
  profile_changePassword: 'admin/profile/password',
  VarientUpdate: `admin/variant`,
  browserNotification: 'notification',
  order:'admin/order',
  excel:'admin/report/download_report',
  payment:"admin/payment",
  dashboardChart: 'admin/dashboard/revenue_chart',
  dashboardData: 'admin/dashboard',
  banner:`admin/banner`,
  PostblockChainResponse: 'admin/transaction',
  googleVerification:"auth/captcha"
};

export default serviceEndpoints;
