export const customerTableData = {
  keys: ['First Name', 'Last Name', 'Email ID', 'Phone Number'],
};
export const vendorTableData = {
  keys: ['Vendor Name', 'Email ID', 'Joined Date', 'Status'],
};
export const productTableData = {
  keys: ['Image', 'Product Name', 'Category', 'Brand', 'Vendor', 'Active'],
};
export const variantTableData = {
  keys: ['Variant Category', 'Variant Type', 'Number of Variants'],
};
export const orderTableData = {
  keys: [
    'Order ID',
    'Vendor Name',
    'Customer Name',
    'Order Date',
    'Total Amount',
    'Amount Paid',
    'Order Status',
  ],
};
export const paymentTableData = {
  keys: ['Date', 'Vendor', 'Total Amount', 'Commission', 'Order ID'],
};
