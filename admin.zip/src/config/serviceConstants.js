
const baseUrl = process.env.REACT_APP_BASE_URL;

if (!baseUrl) {
    throw new Error('API Url is not provided.');
}

export default `${baseUrl}/api`;
