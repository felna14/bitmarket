import axios from "axios";
import API_ROUTE from "./serviceConstants";
import { Notifications } from "../config/utils";

const bitMarketGateway = axios.create({
  baseURL: API_ROUTE,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 20000,
});

bitMarketGateway.interceptors.response.use(
  (response) => response,
  ({ response }) => {
    if (response?.data?.statusCode === 400) {
      Notifications(response?.data?.message, "error");
      return response;
    }
    const token =
      localStorage.getItem("access_token") ||
      sessionStorage.getItem("access_token");

    if (response?.data?.statusCode === 401) {
      if (!token) {
        Notifications(response?.data?.message, "error");
      } else {
        localStorage.clear();
        sessionStorage.clear();
      }
      window.location.href = "/";
    }
  }
);

bitMarketGateway.interceptors.request.use((config) => {
  let token;
  if (localStorage.getItem("rememberMe")) {
    token = localStorage.getItem("access_token");
  } else token = sessionStorage.getItem("access_token");
  if (token)
    config.headers = { ...config.headers, Authorization: `Bearer ${token}` };
  return config;
});
export default bitMarketGateway;
