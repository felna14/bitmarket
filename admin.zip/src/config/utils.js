import { toast } from 'react-toastify';
import BitMarketGateway from './service';

export const validateEmail = (val) =>
  String(val)
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );


export const ResponseApiConfig = async (
  rejectWithValue,
  endPoint,
  method,
  body = {},
  headers = {}
) => {
  try {
    const response = await BitMarketGateway[method](endPoint, body, {
      headers,
    });
    if (response.status < 200 || response.status >= 300) {
      return rejectWithValue(response.data);
    }
    return response?.data;
  } catch (error) {
    if (
      (error.response && error.response.status === 401) ||
      error.response.status === 400
    ) {
      return rejectWithValue(error.response.data);
    } else {
      throw error;
    }
  }
};

export const formatWithCommas = (number) => {
  if (typeof number !== 'undefined') {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
  return "";
}

const toastConfig = {
  position: toast.POSITION.TOP_RIGHT,
  autoClose: 2500,
  pauseOnFocusLoss: true,
  hideProgressBar: true,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: false,
  toastId: Math.random(),
};
// info, success, warning, error, default
export const Notifications = (message = null, type = 'default') => {
  if (!message) return;
  toast(message, { ...toastConfig, type });
};

export const formatMoney = (dollars) => {
  if (!dollars) return null;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(dollars);
}
