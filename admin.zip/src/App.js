import { Web3ReactProvider } from "@web3-react/core";
import { Web3Provider } from "@ethersproject/providers";
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer, Zoom } from 'react-toastify';
import Routes from "./routes/AppRoutes";


const App =() =>{
  return (
    <Web3ReactProvider getLibrary={getLibrary}>
      <ToastContainer closeButton transition={Zoom} icon theme="dark" hideProgressBar />
      <Routes />
    </Web3ReactProvider>
  );
}

const getLibrary = (provider) => {
  var library;

  library = new Web3Provider(provider);
  library.pollingInterval = 12000;

  return library;
};

export default App;
