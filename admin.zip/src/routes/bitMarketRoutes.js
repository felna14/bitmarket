import PrivateRoute from "./PrivateRoute.jsx";
import PublicRoute from "./PublicRoute.jsx";
import CommonRoute from "./CommonRoute.jsx";
import { components } from "./components.js";

export const bitMarketAdminRoutes = [
  {
    path: "/",
    name: "login",
    exact: true,
    component: components.login,
    route: PublicRoute,
  },
  {
    path: "/dashboard",
    name: "dashboard",
    exact: true,
    component: components.dashboard,
    route: PrivateRoute,
  },
  {
    path: "/customer-management",
    name: "customer-management",
    exact: true,
    component: components.customerManagement,
    route: PrivateRoute,
  },
  {
    path: "/vendorManagement",
    name: "Vendor-Management",
    exact: true,
    component: components.vendorManagement,
    route: PrivateRoute,
  },
  {
    path: "/subCategory-management",
    name: "subCategory-management",
    exact: true,
    component: components.subCategoryManagement,
    route: PrivateRoute,
  },
  {
    path: "/category-management",
    name: "category-management",
    exact: true,
    component: components.categoryManagement,
    route: PrivateRoute,
  },
  {
    path: "/change-password",
    name: "change-password",
    exact: true,
    component: components.changepassword,
    route: PublicRoute,
  },
  {
    path: "/products",
    name: "products",
    exact: true,
    component: components.products,
    route: PrivateRoute,
  },

  {
    path: "/payment",
    name: "payment",
    exact: true,
    component: components.payment,
    route: PrivateRoute,
  },
  {
    path: "/order",
    name: "order",
    exact: true,
    component: components.order,
    route: PrivateRoute,
  },
  {
    path: "/change-admin-password",
    name: "changePassword",
    exact: true,
    component: components.changePassword,
    route: PrivateRoute,
  },
  {
    path: '/profile',
    name: 'profile',
    exact: true,
    component: components.profile,
    route: PrivateRoute,
  },
  {
    path: '/notifications',
    name: 'notifications',
    exact: true,
    component: components.notifications,
    route: PrivateRoute,
  },
  {
    path: '/variants-module',
    name: ' variantsModule',
    exact: true,
    component: components.variantsModule,
    route: PrivateRoute,
  },
  {
    path:'/banner',
    name: ' banner',
    exact: true,
    component: components.banner,
    route: PrivateRoute,
  },
  {
    path: "/link-expired",
    name: "link-expired",
    exact: true,
    component: components.experLink,
    route: PublicRoute,
  },
  // {
  //   path: "*",
  //   name: "All",
  //   exact: true,
  //   component: components.NotFound,
  //   route: CommonRoute,
  //   auth: "CommonRoute",
  // },
];
