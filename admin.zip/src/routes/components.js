import React from "react";

export const components = {
  login: React.lazy(() => import("../components/login/login")),
  dashboard: React.lazy(() =>
    import("../components/logedAdmin/dashboard")
  ),
  customerManagement: React.lazy(() =>
    import("../components/logedAdmin/customerManagement")
  ),
  vendorManagement: React.lazy(() =>
    import("../components/logedAdmin/vendorManagement")
  ),
  subCategoryManagement: React.lazy(() =>
    import("../components/logedAdmin/subCategoryManagement")
  ),
  categoryManagement: React.lazy(() =>
    import("../components/logedAdmin/CategoryManagement")
  ),
  changepassword: React.lazy(() =>
    import("../components/resetPassword/ResetPassword")
  ),
  experLink: React.lazy(() => import("../components/common/experLink")),
  products: React.lazy(() => import("../components/logedAdmin/products")),
  changePassword: React.lazy(() =>
    import("../components/logedAdmin/AccountManagement/ChangePassword")
  ),
  profile: React.lazy(() =>
    import("../components/logedAdmin/AccountManagement/Profile")
  ),
  variantsModule: React.lazy(() =>
    import("../components/logedAdmin/variantsModule")
  ),
  payment: React.lazy(() => import("../components/logedAdmin/payment")),
  order: React.lazy(() => import("../components/logedAdmin/order")),
  banner: React.lazy(() => import("../components/logedAdmin/BannerManagement")),
  notifications: React.lazy(() => import("../components/common/notifications/notification")),
};
