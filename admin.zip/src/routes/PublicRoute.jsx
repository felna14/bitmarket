import React from "react";
import { Navigate } from "react-router-dom";

const PublicRoute = ({ component: Component, ...rest }) => {
  const token =
    localStorage.getItem("access_token") ||
    sessionStorage.getItem("access_token");
  const isLoggedIn = !!token;

  return isLoggedIn ? <Navigate to="/dashboard" /> : <Component {...rest} />;
};

export default PublicRoute;
