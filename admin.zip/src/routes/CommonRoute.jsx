import { useSelector } from "react-redux";
import { Route } from "react-router-dom";
import Header from "../components/common/Header";
import SideMenu from "../components/common/SideMenu";
const CommonRoute = ({ component: Component, ...rest }) => {
  const { hidden } = useSelector((state) => state.common.value);
  return (
    <Route
      {...rest}
      render={(props) => (
        <>
          <div className={`wrapper ${hidden ? "isActive" : ""}`}>
            <SideMenu />
            <div className="page-wrapper">
              <Header />
              <Component {...props} />
            </div>
          </div>
        </>
      )}
    />
  );
};

export default CommonRoute;
