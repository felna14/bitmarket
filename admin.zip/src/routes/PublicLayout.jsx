export default function PublicLayout({ children }) {
  return children;
}
