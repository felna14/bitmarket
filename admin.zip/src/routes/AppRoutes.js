import React, { Suspense } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import ErrorBoundary from "../components/common/ErrorBoundary";
import { NotFound } from "../components/common/NotFound";
import { bitMarketAdminRoutes } from "./bitMarketRoutes";

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        {bitMarketAdminRoutes.map((route, index) => {
          const RouteComponent = route.route; 
          return (
            <Route
              key={`route_${index}`}
              path={route.path}
              roles={route.roles}
              element={
                <ErrorBoundary>
                  <Suspense fallback={<></>}>
                    <RouteComponent
                      component={route.component}
                      isLoggedIn={route.isLoggedIn}
                    />
                  </Suspense>
                </ErrorBoundary>
              }
            />
          );
        })}
          <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;