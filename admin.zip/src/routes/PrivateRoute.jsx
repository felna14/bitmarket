import SideMenu from "../components/common/SideMenu";
import Header from "../components/common/Header";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

const PrivateRoute = ({ component: Component, ...rest }) => {
  const token =
    localStorage.getItem("access_token") ||
    sessionStorage.getItem("access_token");
  const isLoggedIn = !!token;
  const { hidden } = useSelector((state) => state.common.value);

  return isLoggedIn ? (
    <div className={`wrapper ${hidden ? "isActive" : ""}`}>
      <SideMenu />
      <div className="page-wrapper">
        <Header />
        <Component {...rest} />
      </div>
    </div>
  ) : (
    <Navigate to="/" />
  );
};

export default PrivateRoute;
