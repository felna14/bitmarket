/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import "../../assets/css/bootstrap.css";
import "../../assets/scss/login.scss";
import "../../assets/scss/common.scss";
import logo from "../../assets/img/logobitcoin.svg";
import logo1 from "../../assets/img/brand-name.svg";
import maillogo from "../../assets/img/log-mail.svg";
import wrngdngr from "../../assets/img/warn-dngr.svg";
import loglock from "../../assets/img/log-lock.svg";
import eyelocked from "../../assets/img/eye-locked.svg";
import eyeunlock from "../../assets/img/eye-unlock.svg";
import ForgotPasswordModal from "../forgotPasswordModal/forgotPasswordModal";
import { Link, useNavigate } from "react-router-dom";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import {
  clearMessageLogin,
  getLoginDetails,
  verificationCaptcha,
} from "./loginSlice";
import { Notifications } from "../../config/utils";

const Login = () => {
  const [forgetPasswordModal, setForgetPasswordModal] = useState(false);
  const [passwordType, setPasswordType] = useState("password");
  const [data, setData] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isLoggedIn, successMessage, errorMessage, verification,isLoading } =
    useSelector((state) => state?.loginReducer);
  //   const [localVerification, setLocalVerification] = useState(null);

  useEffect(() => {
    if (verification) {
      dispatch(getLoginDetails(data));
    }
  }, [verification]);

  useEffect(() => {
    if (successMessage && isLoggedIn) {
      Notifications("You have successfully logged in", "success");
      navigate("/dashboard");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageLogin());
  }, [successMessage, errorMessage]);

  const onClickHandler = () => {
    setForgetPasswordModal(true);
  };
  const handleSubmit = async event => {
    await setData(event);
    const captchaToken = process.env.REACT_APP_CAPTCHA_KEY;
    // const captchaToken = "6LcvuTomAAAAAJ7Ak52BB1HxTSMB8U8YoCDJL5y8"
    window?.grecaptcha?.ready(function () {
      window?.grecaptcha
        .execute(captchaToken, {
          action: 'submit',
        })
        .then(function (token) {
          dispatch(verificationCaptcha({ captcha_token: token }));
        });
      
    });
    // dispatch(getLoginDetails(event));
  };
  const togglePassword = () => {
    if (passwordType === "password") {
      setPasswordType("text");
      return;
    }
    setPasswordType("password");
  };
  return (
    <>
      <ForgotPasswordModal
        isShow={forgetPasswordModal}
        setShow={setForgetPasswordModal}
      />
      <div className="login-cover d-flex">
        <div className="container login-container">
          <div className="login-wrapper">
            <div className="left-block">
              <div className="welcome-title">
                <div className="welcome-logo mb-3">
                  <a href="#/">
                    <img src={logo1} alt="" />
                  </a>
                </div>
                {/* <h2>Welcome to BitMarket</h2> */}
                {/* <p>Please Login Your Account</p> */}
              </div>
            </div>
            <div className="right-block">
              <div className="form-block-cover form-block-cover-login">
                <div className="form-logo">
                  <a href="/">
                    <img src={logo} alt="" />
                  </a>
                </div>
                <Formik
                  initialValues={{
                    email: "",
                    password: "",
                    platform: "web",
                    role: "Admin",
                  }}
                  validationSchema={yup.object({
                    email: yup
                      .string()
                      .required("Email ID is Required")
                      .email("Invalid Email ID")
                      .typeError("Must be a Text"),

                    password: yup
                      .string()
                      .required("Password is Required")
                      .min(8, "Password must contain 8 or more characters"),
                    // .matches(
                    //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                    //   "Must Contain 8 Characters, Uppercase, Lowercase, Number & One Special Case Character"
                    // ),
                  })}
                  onSubmit={async (values, { resetForm }) => {
                    await handleSubmit(values);
                    // resetForm({ values: "" });
                  }}
                >
                  <Form>
                    <div className="form-container">
                      <div className="cutom-form-control">
                        <label htmlFor="Username" className="form-label">
                          Email ID<span className="text-danger">*</span>
                        </label>
                        <div className="input-group cutom-input-group">
                          <span className="input-group-text" id="basic-addon1">
                            <img src={maillogo} alt="" />
                          </span>
                          <Field
                            name="email"
                            type="text"
                            className="form-control"
                            placeholder="Email ID"
                          />
                          <ErrorMessage
                            name="email"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={wrngdngr} alt="" /> {msg}
                              </span>
                            )}
                          />
                        </div>
                      </div>

                      <div className="cutom-form-control passwordInput">
                        <label htmlFor="Password" className="form-label">
                          Password<span className="text-danger">*</span>
                        </label>
                        <div className="input-group cutom-input-group ">
                          <span className="input-group-text">
                            <img src={loglock} alt="" />
                          </span>
                          <Field
                            type={passwordType}
                            name="password"
                            className="form-control"
                            placeholder="Password"
                            aria-label="Password"
                            onPaste={(e) => {
                              e.preventDefault();
                              return false;
                            }}
                            onCopy={(e) => {
                              e.preventDefault();
                              return false;
                            }}
                          />
                          <ErrorMessage
                            name="password"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={wrngdngr} alt="" /> {msg}
                              </span>
                            )}
                          />

                          <span className="input-group-text">
                            {passwordType === "password" ? (
                              <img
                                src={eyelocked}
                                alt=""
                                onClick={togglePassword}
                              />
                            ) : (
                              <img
                                src={eyeunlock}
                                alt=""
                                onClick={togglePassword}
                              />
                            )}
                          </span>
                        </div>
                      </div>
                      <div className="fgt-pswd-lnk">
                        <a
                          data-bs-toggle="modal"
                          // href="#forgotPassword"
                          role="button"
                          onClick={onClickHandler}
                        >
                          Forgot password?
                        </a>
                      </div>
                    
                      <div className="btn-wrapper btn-wrapper-fluid d-flex">
                        <button type="submit" className="btn-def btn-submit">
                        {!isLoading ? (
                              <>
                                &nbsp;
                                Login
                              </>
                             ) : (
                              <span
                              class="spinner-border spinner-border-sm"
                              role="status"
                              aria-hidden="true"
                            ></span>
                            )} 
                        </button>
                      </div>
                    </div>
                  </Form>
                </Formik>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
