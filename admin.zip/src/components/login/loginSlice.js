import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import bitMarketGateway from "../../config/service";
import serviceEndpoints from "../../config/serviceEndPoints";

export const logoutUser = createAction("logout");
export const clearMessageLogin = createAction("clearMessageLogin");

export const getLoginDetails = createAsyncThunk(
  "authentication/login",
  async (data, { rejectWithValue }) => {
    const body = { ...data };
    try {
      const response = await bitMarketGateway.post(
        `${serviceEndpoints.login}`,
        body
      );
      if (response.status < 200 || response.status >= 300) {
        return rejectWithValue(response.data);
      }
      return response.data;
    } catch (error) {
      return error.message;
    }
  }
);

export const verificationCaptcha = createAsyncThunk(
  "verificationCaptcha",
  async (data, { rejectWithValue }) => {
    const body = { ...data,role:"Admin" };
    try {
      const response = await bitMarketGateway.post(
        `${serviceEndpoints.googleVerification}`,
        body
      );
      if (response.status < 200 || response.status >= 300) {
        return rejectWithValue(response.data);
      }
      return response.data;
    } catch (error) {
      return error.message;
    }
  }
);
const loginslice = createSlice({
  name: "login",
  initialState: {
    loginData: {},
    isLoading: false,
    userId: null,
    role_id: null,
    isLoggedIn: false,
    loginfail: false,
    verification:false
  },

  extraReducers: (builder) => {
    builder
      .addCase(getLoginDetails.pending, (state) => {
        state.isLoading = true;
        state.isLoggedIn = false;
        state.successMessage = "";
        state.userData = {};
        state.loginfail = false;
      })

      .addCase(getLoginDetails.fulfilled, (state, { payload }) => {
        const { statusCode, user,accessToken, message } = payload;
        state.isLoading = false;
        state.loginData = payload;
        state.userId = user?.id;
        state.successMessage = message;
        state.loginfail = false;
        if (statusCode === 200) {
          state.isLoggedIn = true;
          sessionStorage.setItem("access_token", accessToken);
          sessionStorage.setItem("userDetails", JSON.stringify(user));
          localStorage.setItem("access_token", accessToken);
          localStorage.setItem("userDetails", JSON.stringify(user));
        }
      })
      .addCase(getLoginDetails.rejected, (state,{payload}) => {
        state.loginData = {};
        state.isLoading = false;
        state.isLoggedIn = false;
        state.errorMessage = payload.message;
        state.loginfail = true;
      })

      .addCase(verificationCaptcha.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessage = "";
        state.verification=false
      })

      .addCase(verificationCaptcha.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.verification = payload?.verified;
        state.successMessage = payload.message;
      })
      .addCase(verificationCaptcha.rejected, (state, { payload }) => {
        state.verification=false;
        state.ResetData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase("logout", (state) => {
        state.isLoading = false;
        state.isLoggedIn = false;
        state.successMessage = "";
        state.errorMessage = "";
        state.userData = {};
        state.loginfail = false;
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = "/";
      })
       .addCase("clearMessageLogin", (state) => {
        state.errorMessage = "";
        state.successMessage = "";
      });
  },
});

export default loginslice.reducer;
