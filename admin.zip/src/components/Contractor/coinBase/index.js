import CoinBaseWeb3 from './coinBaseWeb3';

export { CoinBaseWeb3 };
