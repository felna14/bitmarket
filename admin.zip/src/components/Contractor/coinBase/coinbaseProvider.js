const coinbaseProvider = window.ethereum?.providers
  ? window.ethereum?.providers?.find((provider) => provider.isCoinbaseWallet)
  : window.ethereum;
export default coinbaseProvider;
