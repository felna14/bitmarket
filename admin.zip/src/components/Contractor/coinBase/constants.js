export const COINBASE = 'CoinBase';
