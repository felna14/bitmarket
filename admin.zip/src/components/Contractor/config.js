export const NETWORK_CONFIG = {
    ETHEREUM: {

      SEPOLIA: {
        CHAIN_ID: 11155111,
        RPC: 'https://eth-sepolia.g.alchemy.com/v2/BrDnQt9R_AatqNr67jVfKbs8bF5zSLuW',
        ORDER_TRACKING_CONTRACT_ADDRESS:
        '0x2A35DF46cd8571Ae9af9ae035e81B1694d73Ee3E',
        CHAIN_NAME:'SEPOLIA',
      },
    },
  };
  