import { Notifications } from '../../config/utils';
import { getGasPrice, toWei, checkSufficientBalance } from './utility';

const initiateContractTransaction = async ({
  web3,
  contractFunction,
  contractAddress,
  WalletAddress,
  amountValue,
}) => {
  const amount = amountValue ? toWei({ web3, amount: amountValue }) : '0x0';
  const balanceResponse = await checkSufficientBalance({
    web3,
    connectedAccount: WalletAddress,
    amount,
  });
  if (!balanceResponse) {
    return false;
  }
  const gasPrice = await getGasPrice({ web3 });
  // from walletaddress of admin
  const transactionInput = {
    from: WalletAddress,
    value: amount,
    gasPrice: gasPrice,
  };
  let result = null;
  let gasEstimated = null;
  // try {
  //   gasEstimated = await web3.eth.estimateGas({
  //     to: contractAddress,
  //     data: contractFunction.encodeABI(),
  //     ...transactionInput,
  //   });
  // } catch (error) {
  //   if (error.message === 'insufficient funds for transfer') {
  //     Notifications(error.message, 'error');
  //   } else Notifications(error.message.slice(20, 67), 'error');
  //   return false;
  // }
  try {
    result = await contractFunction.send({
      ...transactionInput,
      gas: gasEstimated,
    });
    if (result) Notifications('Vendor Added to BlockChain', 'success');
  } catch (error) {
    console.error(error);
  }

  return result;
};

export default initiateContractTransaction;
