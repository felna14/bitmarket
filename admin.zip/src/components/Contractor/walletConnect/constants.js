export const WALLET_CONNECT = 'Wallet Connect';
