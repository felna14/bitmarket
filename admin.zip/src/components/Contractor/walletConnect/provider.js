import WalletConnectProvider from '@walletconnect/web3-provider';

import { DEFAULT_NETWORK, getNetworkConfigured } from '../../Contractor';

const WalletConnectProviderWithInfura = (walletConnectQrCode = true) => {
  const networkConfig = getNetworkConfigured({
    blockchainNetwork: DEFAULT_NETWORK,
  });
  const rpc = {};
  rpc[networkConfig.CHAIN_ID] = networkConfig.RPC;

  let options = {
    rpc: rpc,
  };
  if (walletConnectQrCode === false) {
    options = {
      ...options,
      qrcode: false,
    };
  }
  return new WalletConnectProvider(options);
};

export default WalletConnectProviderWithInfura;
