import WalletConnectProviderWithInfura from './provider';

const disconnect = async () => {
  await WalletConnectProviderWithInfura(false).disconnect();
};

export { disconnect };
