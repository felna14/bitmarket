import Web3 from 'web3';
import WalletConnectProviderWithInfura from './provider';

const WalletConnectWeb3 = (provider = null) => {
  // provider has to be stored in redux and use it for wallet collect related web3
  return new Web3(provider || WalletConnectProviderWithInfura());
};

export default WalletConnectWeb3;
