const metaMaskProvider =  window.ethereum?.providers ? window.ethereum?.providers?.find((provider) => provider.isMetaMask) : window.ethereum;

export default metaMaskProvider;
