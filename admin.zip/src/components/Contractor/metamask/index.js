import MetaMaskWeb3 from './metaMaskWeb3';

export { MetaMaskWeb3 };
