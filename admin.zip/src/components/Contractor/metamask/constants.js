export const METAMASK = 'Metamask';
