import initiateContractTransaction from './initiateContractTransaction';
import getweb3Provider from './web3Provider';
import { DEFAULT_NETWORK } from './constants';
import { getNetworkConfigured } from './utility';
import { Abi } from './Abi';

const VendorAuthorise = async ({ address, walletselect, web3Object }) => {
  const WalletAddress = JSON.parse(localStorage.getItem('wallet_address'));
  const web3 = await getweb3Provider({
    walletselect,
    blockchainNetwork: DEFAULT_NETWORK,
    web3Object,
  });
  const networkConfig = getNetworkConfigured({
    blockchainNetwork: DEFAULT_NETWORK,
  });
  const orderTrackTokenAddress = networkConfig.ORDER_TRACKING_CONTRACT_ADDRESS;
  const orderContract = await new web3.eth.Contract(
    Abi,
    orderTrackTokenAddress
  );
  const VendorAuthorized = orderContract.methods.registerAsVendor([address]);
  const result = await initiateContractTransaction({
    WalletAddress,
    web3,
    contractFunction: VendorAuthorized,
    contractAddress: orderTrackTokenAddress,
  });
  return result;
};

export default VendorAuthorise;
