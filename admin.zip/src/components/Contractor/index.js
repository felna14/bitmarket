import {
  isWalletAddressValid,
  handleError,
  checkNetwork,
  getNetworkFromChainId,
  disconnectAllWallets,
  showBalance,
  getNetworkId,
  getNetworkConfigured,
} from './utility';

import web3Provider from './web3Provider';
import VendorAuthorise from './VendorAuthorise';

import {
  NETWORKS,
  CHAIN_ID,
  RPC_URL,
  CHAIN_NAME,
  DEFAULT_NETWORK,
} from './constants';

import { NETWORK_CONFIG } from './config';

export {
  web3Provider,
  handleError,
  isWalletAddressValid,
  checkNetwork,
  showBalance,
  getNetworkFromChainId,
  disconnectAllWallets,
  getNetworkId,
  VendorAuthorise,
  getNetworkConfigured,
  NETWORKS,
  CHAIN_ID,
  RPC_URL,
  CHAIN_NAME,
  NETWORK_CONFIG,
  DEFAULT_NETWORK,
};
