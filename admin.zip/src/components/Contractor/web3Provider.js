import { MetaMaskWeb3 } from './metamask';
import { WalletConnectWeb3 } from './walletConnect';
import { getNetworkConfigured } from './utility';

const getweb3Provider = ({ walletselect, blockchainNetwork, web3Object }) => {
  // // let web3 = null;
  // // if (walletAccountStore && walletAccountStore.account) {
  const web3 = getWeb3(walletselect, blockchainNetwork, web3Object);
  return web3;
};

const getWeb3 = (walletselect, blockchainNetwork, web3Object) => {
  const wallets = {
    Metamask: MetaMaskWeb3,
    'Coinbase Wallet': MetaMaskWeb3,
    Walletconnect:
      web3Object ||
      WalletConnectWeb3(getNetworkConfigured({ blockchainNetwork }).RPC),
  };

  if (walletselect in wallets) {
    return wallets[walletselect];
  } else {
    throw new Error(`Invalid wallet selected: ${walletselect}`);
  }
};

export default getweb3Provider;
