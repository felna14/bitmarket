export const Abi = [
  {
    inputs: [],
    stateMutability: "nonpayable",
    type: "constructor"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "DeliveryAck",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "LostInTransit",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "ManufacturerAck",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "OrderCancelled",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "orderCreatedDate",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "orderQuantity",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "vendorId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "address",
        name: "vendorAddress",
        type: "address"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "orderStatus",
        type: "uint8"
      },
      {
        indexed: false,
        internalType: "bool",
        name: "isPaidToVendor",
        type: "bool"
      }
    ],
    name: "OrderCreated",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "OrderDelivered",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "OrderReturnedToSeller",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "address",
        name: "vendorAddress",
        type: "address"
      }
    ],
    name: "VendorAuthorized",
    type: "event"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "_orderCreatedDate",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "_orderQuantity",
        type: "uint256"
      }
    ],
    name: "addOrderData",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    name: "authorizedVendors",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "deliveryAck",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      }
    ],
    name: "getCurrentOrderStatus",
    outputs: [
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "",
        type: "uint8"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "getCurrentOwner",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      },
      {
        internalType: "bool",
        name: "_isPaidToVendor",
        type: "bool"
      }
    ],
    name: "lostInTransit",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      }
    ],
    name: "manufacturerAck",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      },
      {
        internalType: "bool",
        name: "_isPaidToVendor",
        type: "bool"
      }
    ],
    name: "orderCancelled",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [],
    name: "orderCount",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    name: "orderData",
    outputs: [
      {
        internalType: "uint256",
        name: "orderId",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "orderCreatedDate",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "orderQuantity",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "vendorId",
        type: "uint256"
      },
      {
        internalType: "address",
        name: "vendorAddress",
        type: "address"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "orderStatus",
        type: "uint8"
      },
      {
        internalType: "bool",
        name: "isPaidToVendor",
        type: "bool"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      },
      {
        internalType: "bool",
        name: "_isPaidToVendor",
        type: "bool"
      }
    ],
    name: "orderDelivered",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "_orderStatus",
        type: "uint8"
      },
      {
        internalType: "bool",
        name: "_isPaidToVendor",
        type: "bool"
      }
    ],
    name: "orderReturnedToSeller",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [],
    name: "owner",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address[]",
        name: "_vendorAddress",
        type: "address[]"
      }
    ],
    name: "registerAsVendor",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_vendorAddress",
        type: "address"
      }
    ],
    name: "revokeVendor",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "_newOwner",
        type: "address"
      }
    ],
    name: "transferOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [],
    name: "vendorCount",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    name: "vendorIds",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "_orderId",
        type: "uint256"
      }
    ],
    name: "viewOrderData",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      },
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      },
      {
        internalType: "address",
        name: "",
        type: "address"
      },
      {
        internalType: "enum OrderTracking.OrderStatus",
        name: "",
        type: "uint8"
      },
      {
        internalType: "bool",
        name: "",
        type: "bool"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "viewTotalOrders",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "viewTotalVendors",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  }
];
