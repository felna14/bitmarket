import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import axios from "axios";

export const clearMessageResetPassword = createAction(
  "clearMessageResetPassword"
);
export const getResetpasswordDetails = createAsyncThunk(
  "auth/reset-password",

  async ({ token, ...data }, { rejectWithValue }) => {
    const body = { ...data };
    try {
      const response = await axios.put(
        `https://devapi-bitmarket.spericorn.com/api/auth/reset-password?${token}`,
        body
      );
      if (response.status < 200 || response.status >= 300) {
        return rejectWithValue(response.data);
      }
      return response.data;
    } catch (error) {
      if (
        (error.response && error.response.status === 401) ||
        error.response.status === 400
      ) {
        return rejectWithValue(error.response.data);
      } else {
        throw error;
      }
    }
  }
);

const forgotslice = createSlice({
  name: "forgot",
  initialState: {
    changePasswordData: {},
    isLoading: false,
  },

  extraReducers: (builder) => {
    builder
      .addCase(getResetpasswordDetails.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessage = "";
      })

      .addCase(getResetpasswordDetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.ResetData = payload;
        state.successMessage = payload.message;
      })
      .addCase(getResetpasswordDetails.rejected, (state, { payload }) => {
        state.ResetData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase("clearMessageForgot", (state) => {
        state.errorMessage = "";
        state.successMessage = "";
      });
  },
});

export default forgotslice.reducer;
