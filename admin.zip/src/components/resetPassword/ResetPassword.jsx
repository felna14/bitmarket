import React, { useEffect, useState } from "react";
import forgtpswd from "../../assets/img/forgt-pswd.svg";
import locktitle from "../../assets/img/lock-title.svg";
import loglock from "../../assets/img/log-lock.svg";
import warndangr from "../../assets/img/warn-dngr.svg";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";
import "../../assets/css/bootstrap.css";
import "../../assets/scss/login.scss";
import eyelocked from "../../assets/img/eye-locked.svg";
import eyeunlock from "../../assets/img/eye-unlock.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  clearMessageResetPassword,
  getResetpasswordDetails,
} from "./ResetPasswordSlice";
import { Notifications } from "../../config/utils";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

const ResetPassword = () => {
  const [passwordType, setPasswordType] = useState("password");
  const [confirmPasswordType, setConfirmPasswordType] = useState("password");
  const dispatch = useDispatch();
  const location = useLocation();

  const navigate = useNavigate();
  const { successMessage, errorMessage } = useSelector(
    (state) => state?.resetPasswordReducer
  );
  useEffect(() => {
    async function fetchData() {
      try {
        await axios.get(
          `https://devapi-bitmarket.spericorn.com/api/auth/resetPassword?${location?.search?.replace(
            /[?"']/g,
            ""
          )}`
        );
      } catch (error) {
        navigate("/link-expired");
      }
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location]);

  useEffect(() => {
    if (successMessage) {
      Notifications(successMessage, "success");
      navigate("/");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageResetPassword());
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [successMessage, errorMessage]);

  const handleSubmit = (values) => {
    dispatch(getResetpasswordDetails(values));
  };
  const togglePassword = () => {
    if (passwordType === "password") {
      setPasswordType("text");
      return;
    }
    setPasswordType("password");
  };
  const { changePasswordData } = useSelector(
    (state) => state?.resetPasswordReducer
  );
  useEffect(() => {
    if (changePasswordData.message) {
      Notifications(changePasswordData.message, "success");
    }
  }, [changePasswordData]);

  const togglePassword2 = () => {
    if (confirmPasswordType === "password") {
      setConfirmPasswordType("text");
      return;
    }
    setConfirmPasswordType("password");
  };
  return (
    <div className="login-cover d-flex">
      <div className="container login-container">
        <div className="login-wrapper">
          <div className="left-block">
            <div className="welcome-title">
              <div className="welcome-img">
                <img src={forgtpswd} alt="" />
              </div>
              <h2>Don't Miss Your Password</h2>
              <p>Keep Your Password Secret</p>
            </div>
          </div>
          <div className="right-block">
            <div className="form-block-cover form-block-cover-pswd form-block-h-pswd">
              <div className="form-title">
                <img src={locktitle} alt="" />
                Reset Password
              </div>
              <Formik
                initialValues={{
                  password: "",
                  confirmPassword: "",
                  token: location?.search?.replace(/[?"']/g, ""),
                }}
                validationSchema={yup.object({
                  password: yup
                    .string()
                    .required("Password is Required!")
                    .min(8, "Password must contain 8 or more characters")
                    .matches(
                      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/,
                      "Must Contain 8 Characters, Uppercase, Lowercase, Number & One Special Case Character"
                    ),

                  confirmPassword: yup
                    .string()
                    .required("Confirm Password is Required!")
                    .oneOf([yup.ref("password"), null], "Passwords must match")
                    .min(8, "Password must contain 8 or more characters")
                    .matches(
                      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/,
                      "Must Contain 8 Characters, Uppercase, Lowercase, Number & One Special Case Character"
                    ),
                })}
                onSubmit={(values) => {
                  handleSubmit(values);
                  // resetForm({ values: "" });
                }}
              >
                <Form>
                  <div className="form-container">
                    <div className="cutom-form-control passwordInput">
                      <label htmlFor="Password" className="form-label">
                        New Password
                      </label>
                      <div className="input-group cutom-input-group ">
                        <span className="input-group-text">
                          <img src={loglock} alt="" />
                        </span>
                        <Field
                          name="password"
                          type={passwordType}
                          className="form-control"
                          placeholder="Password"
                          aria-label="Password"
                        />
                        <span className="input-group-text">
                          {passwordType === "password" ? (
                            <img
                              src={eyelocked}
                              alt=""
                              onClick={togglePassword}
                            />
                          ) : (
                            <img
                              src={eyeunlock}
                              alt=""
                              onClick={togglePassword}
                            />
                          )}
                        </span>
                        <ErrorMessage
                          name="password"
                          render={(msg) => (
                            <span className="val-msg">
                              <img src={warndangr} alt="" /> {msg}
                            </span>
                          )}
                        />
                      </div>
                    </div>
                    <div className="cutom-form-control passwordInput">
                      <label htmlFor="Password" className="form-label">
                        Confirm Password
                      </label>
                      <div className="input-group cutom-input-group">
                        <span className="input-group-text">
                          <img src={loglock} alt="" />
                        </span>
                        <Field
                          name="confirmPassword"
                          type={confirmPasswordType}
                          className="form-control"
                          placeholder="Confirm Password"
                          aria-label="Password"
                        />
                        <span className="input-group-text">
                          {confirmPasswordType === "password" ? (
                            <img
                              src={eyelocked}
                              alt=""
                              onClick={togglePassword2}
                            />
                          ) : (
                            <img
                              src={eyeunlock}
                              alt=""
                              onClick={togglePassword2}
                            />
                          )}
                        </span>
                        <ErrorMessage
                          name="confirmPassword"
                          render={(msg) => (
                            <span className="val-msg">
                              <img src={warndangr} alt="" /> {msg}
                            </span>
                          )}
                        />
                      </div>
                    </div>

                    <div className="btn-wrapper d-flex">
                      <button type="button" className="btn-def btn-cancel">
                        Cancel
                      </button>
                      <button type="submit" className="btn-def btn-submit">
                        Submit
                      </button>
                    </div>
                  </div>
                </Form>
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
