/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from 'react';
import brandname from '../../assets/img/brand-name.svg';
import moblogo from '../../assets/img/mob-logo.svg';
import '../../assets/css/bootstrap.css';
import '../../assets/scss/common.scss';
import '../../assets/scss/side-nav.scss';
import '../../assets/scss/header.scss';
import '../../assets/scss/dashboard.scss';
import { Link, useLocation } from 'react-router-dom';
import LogoutModal from './LogoutModal';
import { Tooltip } from 'react-tooltip';

const SideMenu = () => {
  const location = useLocation();
  const [showSubNav, setShowSubNav] = useState(-1);
  const [logoutModal, setlogoutModal] = useState(false);
  const onClickHandler = () => {
    setlogoutModal(true);
  };
  const sidebarOptions = [
    {
      route: '/dashboard',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_element-4"
            data-name="vuesax/linear/element-4"
            transform="translate(-684 -252)"
          >
            <g id="element-4">
              <g id="Group_1" data-name="Group 1" transform="translate(0 1)">
                <path
                  id="Vector"
                  d="M7.722,8.085V1.908C7.722.545,7.14,0,5.7,0H2.026C.581,0,0,.545,0,1.908V8.085C0,9.448.581,9.993,2.026,9.993H5.7C7.14,9.993,7.722,9.448,7.722,8.085Z"
                  transform="translate(697.384 253.901)"
                  fill="none"
                  stroke="#"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-2"
                  data-name="Vector"
                  d="M7.722,3.543V1.908C7.722.545,7.14,0,5.7,0H2.026C.581,0,0,.545,0,1.908V3.543C0,4.906.581,5.451,2.026,5.451H5.7C7.14,5.451,7.722,4.906,7.722,3.543Z"
                  transform="translate(697.384 266.62)"
                  fill="none"
                  stroke="#"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-3"
                  data-name="Vector"
                  d="M7.722,1.908V8.085c0,1.363-.581,1.908-2.026,1.908H2.026C.581,9.993,0,9.448,0,8.085V1.908C0,.545.581,0,2.026,0H5.7C7.14,0,7.722.545,7.722,1.908Z"
                  transform="translate(686.936 262.078)"
                  fill="none"
                  stroke="#"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-4"
                  data-name="Vector"
                  d="M7.722,1.908V3.543c0,1.363-.581,1.908-2.026,1.908H2.026C.581,5.451,0,4.906,0,3.543V1.908C0,.545.581,0,2.026,0H5.7C7.14,0,7.722.545,7.722,1.908Z"
                  transform="translate(686.936 253.901)"
                  fill="none"
                  stroke="#"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
              </g>
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(684 252)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Dashboard',
    },
    {
      route: '/customer-management',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_bold_user"
            data-name="vuesax/bold/user"
            transform="translate(-108 -188)"
          >
            <g id="user">
              <path
                id="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(108 188)"
                fill="none"
                opacity="0"
              />
              <g
                id="Group_2"
                data-name="Group 2"
                transform="translate(1.147 1.442)"
              >
                <path
                  id="Vector-2"
                  data-name="Vector"
                  d="M8.349,4.174A4.174,4.174,0,1,1,4.174,0,4.174,4.174,0,0,1,8.349,4.174Z"
                  transform="translate(114.546 190)"
                  fill="none"
                  stroke="#"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-3"
                  data-name="Vector"
                  d="M7.589,0C3.406,0,0,2.805,0,6.262a.413.413,0,0,0,.417.417H14.761a.413.413,0,0,0,.417-.417C15.178,2.805,11.772,0,7.589,0Z"
                  transform="translate(111.132 200.436)"
                  fill="none"
                  stroke="#"
                  strokeWidth="1.5"
                />
              </g>
            </g>
          </g>
        </svg>
      ),
      label: 'Customer Management',
    },
    {
      route: '/vendorManagement',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_profile-2user"
            data-name="vuesax/linear/profile-2user"
            transform="translate(-172 -252)"
          >
            <g id="profile-2user">
              <path
                id="Vector"
                d="M4.6,8.87a1.818,1.818,0,0,0-.33,0,4.445,4.445,0,1,1,.33,0Z"
                transform="translate(176.56 254)"
                fill="none"
                stroke="#"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-2"
                data-name="Vector"
                d="M.13,0a3.5,3.5,0,0,1,3.5,3.5A3.5,3.5,0,0,1,.26,7,1.129,1.129,0,0,0,0,7"
                transform="translate(188.28 256)"
                fill="none"
                stroke="#"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-3"
                data-name="Vector"
                d="M1.815,1.373c-2.42,1.62-2.42,4.26,0,5.87a9.766,9.766,0,0,0,10.01,0c2.42-1.62,2.42-4.26,0-5.87A9.812,9.812,0,0,0,1.815,1.373Z"
                transform="translate(174.345 265.188)"
                fill="none"
                stroke="#"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-4"
                data-name="Vector"
                d="M0,6a4.837,4.837,0,0,0,1.96-.87,2.533,2.533,0,0,0,0-4.27A4.973,4.973,0,0,0,.03,0"
                transform="translate(190.34 266)"
                fill="none"
                stroke="#"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(196 276) rotate(180)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Vendor Management',
    },
    {
      route: '/category-management',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_note"
            data-name="vuesax/linear/note"
            transform="translate(-428 -252)"
          >
            <g id="note">
              <g id="Group_3" data-name="Group 3">
                <path
                  id="Vector"
                  d="M14.593,3.648v8.892c0,2.736-1.633,3.648-3.648,3.648h-7.3C1.633,16.189,0,15.277,0,12.541V3.648C0,.684,1.633,0,3.648,0a2.04,2.04,0,0,0,.6,1.45,2.04,2.04,0,0,0,1.45.6H8.892A2.055,2.055,0,0,0,10.945,0C12.96,0,14.593.684,14.593,3.648Z"
                  transform="translate(432.704 256.932)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-2"
                  data-name="Vector"
                  d="M7.3,2.052A2.055,2.055,0,0,1,5.244,4.1H2.052a2.052,2.052,0,0,1,0-4.1H5.244A2.055,2.055,0,0,1,7.3,2.052Z"
                  transform="translate(436.352 254.879)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-3"
                  data-name="Vector"
                  d="M0,0H3.648"
                  transform="translate(436.352 264.912)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-4"
                  data-name="Vector"
                  d="M0,0H7.3"
                  transform="translate(436.352 268.56)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
              </g>
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(428 252)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Category Management',
    },
    {
      route: '/subCategory-management',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_note-2"
            data-name="vuesax/linear/note-2"
            transform="translate(-108 -252)"
          >
            <g id="note-2">
              <path
                id="Vector"
                d="M14.691,7.939l-.98,4.18c-.84,3.61-2.5,5.07-5.62,4.77a10.514,10.514,0,0,1-1.62-.27l-1.68-.4c-4.17-.99-5.46-3.05-4.48-7.23l.98-4.19a10.474,10.474,0,0,1,.74-2.2C3.2.179,5.191-.471,8.531.319l1.67.39C14.391,1.689,15.671,3.759,14.691,7.939Z"
                transform="translate(114.969 254.501)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-2"
                data-name="Vector"
                d="M13.074,14.29a9.372,9.372,0,0,1-2.35,1.08l-1.58.52c-3.97,1.28-6.06.21-7.35-3.76L.514,8.18C-.766,4.21.294,2.11,4.264.83L5.844.31A10.224,10.224,0,0,1,7.014,0a10.474,10.474,0,0,0-.74,2.2l-.98,4.19c-.98,4.18.31,6.24,4.48,7.23l1.68.4A10.513,10.513,0,0,0,13.074,14.29Z"
                transform="translate(109.986 257.1)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-3"
                data-name="Vector"
                d="M0,0,4.85,1.23"
                transform="translate(120.64 260.53)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-4"
                data-name="Vector"
                d="M0,0,2.9.74"
                transform="translate(119.66 264.4)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(132 276) rotate(180)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Subcategory Management',
    },
    {
      route: '/banner',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_keyboard"
            data-name="vuesax/linear/keyboard"
            transform="translate(-300 -316)"
          >
            <g id="keyboard">
              <path
                id="Vector"
                d="M5,0h9a11.95,11.95,0,0,1,1.66.09C18.29.38,19,1.62,19,5v6c0,3.38-.71,4.62-3.34,4.91A11.95,11.95,0,0,1,14,16H5a11.95,11.95,0,0,1-1.66-.09C.71,15.62,0,14.38,0,11V5C0,1.62.71.38,3.34.09A11.95,11.95,0,0,1,5,0Z"
                transform="translate(302.5 320)"
                fill="none"
                // stroke="#c3affb"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-2"
                data-name="Vector"
                d="M0,0H3.5"
                transform="translate(313.5 326)"
                fill="none"
                // stroke="#c3affb"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-3"
                data-name="Vector"
                d="M0,0H10"
                transform="translate(307 331.5)"
                fill="none"
                // stroke="#c3affb"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-4"
                data-name="Vector"
                d="M.5.5h0"
                transform="translate(309.6 325.5)"
                fill="none"
                // stroke="#c3affb"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M.5.5h0"
                transform="translate(306.6 325.5)"
                fill="none"
                // stroke="#c3affb"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-6"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(300 316)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Banner Management',
    },
    {
      route: '/variants-module',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_convert-3d-cube"
            data-name="vuesax/linear/convert-3d-cube"
            transform="translate(-236 -188)"
          >
            <g id="convert-3d-cube">
              <g id="Group">
                <path
                  id="Vector"
                  d="M7,0A7,7,0,0,1,0,7L1.05,5.25"
                  transform="translate(251 203)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-2"
                  data-name="Vector"
                  d="M0,7A7,7,0,0,1,7,0L5.95,1.75"
                  transform="translate(238 190)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
              </g>
              <g id="Group-2" data-name="Group">
                <g id="Group-3" data-name="Group">
                  <path
                    id="Vector-3"
                    data-name="Vector"
                    d="M0,0,3.98,2.3,7.92.01"
                    transform="translate(249.7 192.45)"
                    fill="none"
                    stroke=""
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                  <path
                    id="Vector-4"
                    data-name="Vector"
                    d="M0,4.08V0"
                    transform="translate(253.68 194.74)"
                    fill="none"
                    stroke=""
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                </g>
                <path
                  id="Vector-5"
                  data-name="Vector"
                  d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21A2.186,2.186,0,0,0,3.39.21Z"
                  transform="translate(249.35 190)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
              </g>
              <g id="Group-4" data-name="Group">
                <g id="Group-5" data-name="Group">
                  <path
                    id="Vector-6"
                    data-name="Vector"
                    d="M0,0,3.97,2.3,7.92.01"
                    transform="translate(238.35 203.45)"
                    fill="none"
                    stroke=""
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                  <path
                    id="Vector-7"
                    data-name="Vector"
                    d="M0,4.08V0"
                    transform="translate(242.32 205.74)"
                    fill="none"
                    stroke=""
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                </g>
                <path
                  id="Vector-8"
                  data-name="Vector"
                  d="M3.39.21.99,1.54A2.137,2.137,0,0,0,0,3.22V5.76A2.111,2.111,0,0,0,.99,7.44l2.4,1.33a2.118,2.118,0,0,0,1.87,0l2.4-1.33a2.137,2.137,0,0,0,.99-1.68V3.22a2.111,2.111,0,0,0-.99-1.68L5.26.21A2.186,2.186,0,0,0,3.39.21Z"
                  transform="translate(238 201)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
              </g>
              <path
                id="Vector-9"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(236 188)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Variants Management',
    },
    {
      route: '/products',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_bag-2"
            data-name="vuesax/linear/bag-2"
            transform="translate(-556 -188)"
          >
            <g id="bag-2">
              <path
                id="Vector"
                d="M0,5.662v-.97A4.773,4.773,0,0,1,4.06.022,4.5,4.5,0,0,1,9,4.5v1.38"
                transform="translate(563.5 190.008)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-2"
                data-name="Vector"
                d="M5.751,14h6c4.02,0,4.74-1.61,4.95-3.57l.75-6c.27-2.44-.43-4.43-4.7-4.43h-8C.481,0-.219,1.99.051,4.43l.75,6C1.011,12.39,1.731,14,5.751,14Z"
                transform="translate(559.249 196)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-3"
                data-name="Vector"
                d="M.495.5H.5"
                transform="translate(571.001 199.5)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
              <path
                id="Vector-4"
                data-name="Vector"
                d="M.495.5H.5"
                transform="translate(564 199.5)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(556 188)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Products',
    },
    {
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_bold_user"
            data-name="vuesax/bold/user"
            transform="translate(-108 -188)"
          >
            <g id="user">
              <path
                id="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(108 188)"
                fill="none"
                opacity="0"
              />
              <g
                id="Group_2"
                data-name="Group 2"
                transform="translate(1.147 1.442)"
              >
                <path
                  id="Vector-2"
                  data-name="Vector"
                  d="M8.349,4.174A4.174,4.174,0,1,1,4.174,0,4.174,4.174,0,0,1,8.349,4.174Z"
                  transform="translate(114.546 190)"
                  fill="none"
                  stroke=""
                  strokeWidth="1.5"
                />
                <path
                  id="Vector-3"
                  data-name="Vector"
                  d="M7.589,0C3.406,0,0,2.805,0,6.262a.413.413,0,0,0,.417.417H14.761a.413.413,0,0,0,.417-.417C15.178,2.805,11.772,0,7.589,0Z"
                  transform="translate(111.132 200.436)"
                  fill="none"
                  stroke=""
                  strokeWidth="1.5"
                />
              </g>
            </g>
            <circle
              id="Ellipse_11"
              data-name="Ellipse 11"
              cx="6"
              cy="6"
              r="6"
              transform="translate(120 199)"
              fill="#4a1fc4"
            />
            <g
              id="Group_118"
              data-name="Group 118"
              transform="translate(-180.686 9.362)"
            >
              <path
                id="Vector-4"
                data-name="Vector"
                d="M2.613,1.307A1.307,1.307,0,1,1,1.307,0,1.307,1.307,0,0,1,2.613,1.307Z"
                transform="translate(305.735 194.013)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,4.494V3.728A.83.83,0,0,1,.827,2.9c.788,0,1.111-.557.714-1.241a.827.827,0,0,1,.3-1.128L2.6.1a.727.727,0,0,1,.993.261l.048.083a.757.757,0,0,0,1.433,0L5.122.361A.727.727,0,0,1,6.115.1l.753.431a.827.827,0,0,1,.3,1.128c-.4.684-.074,1.241.714,1.241a.83.83,0,0,1,.827.827v.767a.83.83,0,0,1-.827.827c-.788,0-1.111.557-.714,1.241a.826.826,0,0,1-.3,1.128l-.753.431a.727.727,0,0,1-.993-.261l-.048-.083a.757.757,0,0,0-1.433,0l-.048.083a.727.727,0,0,1-.993.261l-.753-.431a.827.827,0,0,1-.3-1.128c.4-.684.074-1.241-.714-1.241A.83.83,0,0,1,0,4.494Z"
                transform="translate(302.686 191.208)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Account Management',
      subNav: [
        {
          label: 'Profile',
          to: '/profile',
          route: '/profile',
        },
        {
          label: 'Change Password',
          to: '/change-admin-password',
          route: '/change-admin-password',
        },
      ],
    },
    {
      route: '/payment',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_card"
            data-name="vuesax/linear/card"
            transform="translate(-492 -508)"
          >
            <g id="card">
              <path
                id="Vector"
                d="M0,0H20"
                transform="translate(494 516.505)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-2"
                data-name="Vector"
                d="M0,0H2"
                transform="translate(498 524.505)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-3"
                data-name="Vector"
                d="M0,0H4"
                transform="translate(502.5 524.505)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-4"
                data-name="Vector"
                d="M4.44,0H15.55C19.11,0,20,.88,20,4.39V12.6c0,3.51-.89,4.39-4.44,4.39H4.44C.89,17,0,16.12,0,12.61V4.39C0,.88.89,0,4.44,0Z"
                transform="translate(494 511.505)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(492 508)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Payment',
    },
    {
      route: '/order',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_box"
            data-name="vuesax/linear/box"
            transform="translate(-556 -188)"
          >
            <g id="box">
              <g id="Group">
                <g id="Group-2" data-name="Group">
                  <path
                    id="Vector"
                    d="M0,0,8.83,5.11,17.6.03"
                    transform="translate(559.17 195.44)"
                    fill="none"
                    stroke=""
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                  <path
                    id="Vector-2"
                    data-name="Vector"
                    d="M0,9.07V0"
                    transform="translate(568 200.54)"
                    fill="none"
                    stroke=""
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                </g>
                <path
                  id="Vector-3"
                  data-name="Vector"
                  d="M7.54.48,2.2,3.45A4.719,4.719,0,0,0,0,7.18v5.65a4.719,4.719,0,0,0,2.2,3.73l5.34,2.97a4.792,4.792,0,0,0,4.15,0l5.34-2.97a4.719,4.719,0,0,0,2.2-3.73V7.18a4.719,4.719,0,0,0-2.2-3.73L11.69.48A4.725,4.725,0,0,0,7.54.48Z"
                  transform="translate(558.39 190)"
                  fill="none"
                  stroke=""
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.5"
                />
              </g>
              <path
                id="Vector-4"
                data-name="Vector"
                d="M9.49,9.14V5.48L0,0"
                transform="translate(563.51 192.1)"
                fill="none"
                stroke=""
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-5"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(556 188)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Order',
    },
    {
      route: '/notifications',
      icon: () => (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
        >
          <g
            id="vuesax_linear_notification"
            data-name="vuesax/linear/notification"
            transform="translate(-171 -188)"
          >
            <g id="notification">
              <path
                id="Vector"
                d="M8.046,0a5.817,5.817,0,0,0-6,5.6V8.3a4.24,4.24,0,0,1-.57,1.924L.326,12.01a1.756,1.756,0,0,0,1.08,2.736,22.327,22.327,0,0,0,13.27,0,1.828,1.828,0,0,0,1.08-2.736l-1.15-1.784a4.354,4.354,0,0,1-.56-1.924V5.6A5.829,5.829,0,0,0,8.046,0Z"
                transform="translate(174.974 192.025)"
                fill="none"
                // stroke="#fff"
                strokeLinecap="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-2"
                data-name="Vector"
                d="M3.7,1.8a4.532,4.532,0,0,0-.96-.285A4.831,4.831,0,0,0,0,1.8,2.142,2.142,0,0,1,1.85,0,2.142,2.142,0,0,1,3.7,1.8Z"
                transform="translate(181.17 189.94)"
                fill="none"
                // stroke="#fff"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
              />
              <path
                id="Vector-3"
                data-name="Vector"
                d="M6,0A3.009,3.009,0,0,1,3,3,3.011,3.011,0,0,1,.88,2.12,3.011,3.011,0,0,1,0,0"
                transform="translate(180.02 207.06)"
                fill="none"
                // stroke="#fff"
                strokeWidth="1.5"
              />
              <path
                id="Vector-4"
                data-name="Vector"
                d="M0,0H24V24H0Z"
                transform="translate(171 188)"
                fill="none"
                opacity="0"
              />
            </g>
          </g>
        </svg>
      ),
      label: 'Notifications',
    },
  ];
  return (
    <>
      <LogoutModal isShow={logoutModal} setShow={setlogoutModal} />
      <Tooltip id="sidemenu-tooltip" className="tooltip" />
      <div className="side-nav-wrapper">
        <div className="brand-name-wrapper">
          <a href="#/">
            <img
              src={brandname}
              className="brand-name web-logo"
              alt="Blockchain"
            />
            <img
              src={moblogo}
              className="brand-name mob-logo"
              alt="Blockchain"
            />
          </a>
        </div>
        <div className="side-nav custom-scroll">
          <ul className="nav-list">
            {sidebarOptions.map(
              ({ route, icon: NavIcon, label, subNav }, index) => (
                <li
                  className={`nav-item${
                    route === location?.pathname
                      ? ' active'
                      : '' ||
                        subNav?.some((nav) => nav.to === location?.pathname)
                      ? ' active'
                      : ''
                  }`}
                  key={index}
                >
                  {subNav ? (
                    <>
                      <Link
                        to={route}
                        className={`nav-link ${
                          showSubNav === index
                            ? 'active arrowActive '
                            : 'collapsed '
                        }`}
                        onClick={() =>
                          setShowSubNav(showSubNav === index ? -1 : index)
                        }
                        data-bs-toggle="collapse"
                        data-bs-target={`#subNav-${label}`}
                        aria-expanded={showSubNav === index}
                      >
                        <div
                          className="nav-icon"
                          data-tooltip-id="sidemenu-tooltip"
                          data-tooltip-content={label}
                        >
                          <NavIcon />
                        </div>
                        <span>{label}</span>
                      </Link>
                      <div
                        id="Product-drop"
                        className={`collapse ${
                          showSubNav === index ? 'show' : ''
                        }`}
                      >
                        <ul className="drop-block">
                          {subNav.map(
                            ({ to: subRoute, label: subLabel }, index) => (
                              <li
                                key={index}
                                className={
                                  location?.pathname === subRoute
                                    ? 'active'
                                    : ''
                                }
                              >
                                <Link to={subRoute}>{subLabel}</Link>
                              </li>
                            )
                          )}
                        </ul>
                      </div>
                    </>
                  ) : (
                    <Link to={route} className="nav-link">
                      <div
                        data-tooltip-id="sidemenu-tooltip"
                        data-tooltip-content={label}
                        className="nav-icon"
                      >
                        <NavIcon />
                      </div>
                      <span onClick={() =>
                          setShowSubNav(false)
                        }>{label}</span>
                    </Link>
                  )}
                </li>
              )
            )}
            <li className="nav-item logout-list">
              <a className="nav-link" onClick={onClickHandler}>
                <div
                  className="nav-icon"
                  data-tooltip-id="sidemenu-tooltip"
                  data-tooltip-content="Logout"
                >
                  <svg
                    id="shutdown-icon"
                    xmlns="http://www.w3.org/2000/svg"
                    width="28.61"
                    height="28.61"
                    viewBox="0 0 28.61 28.61"
                  >
                    <path
                      id="Path_12"
                      data-name="Path 12"
                      d="M14.3,0A14.3,14.3,0,1,1,0,14.3,14.306,14.306,0,0,1,14.3,0Z"
                      fill="#7f57f1"
                      fillRule="evenodd"
                    ></path>
                    <path
                      id="Path_13"
                      data-name="Path 13"
                      d="M37.763,38.1a1.494,1.494,0,0,1,2.258-1.956,8.441,8.441,0,1,1-12.836.081,1.492,1.492,0,1,1,2.284,1.921,5.454,5.454,0,1,0,8.293-.047Z"
                      transform="translate(-19.333 -27.329)"
                      fill="#fff"
                      fillRule="evenodd"
                    ></path>
                    <path
                      id="Path_14"
                      data-name="Path 14"
                      d="M58,29.457a1.5,1.5,0,0,1-3,0V24.989a1.5,1.5,0,1,1,3,0v4.468Z"
                      transform="translate(-42.194 -18.021)"
                      fill="#fff"
                      fillRule="evenodd"
                    ></path>
                  </svg>
                </div>
                <span>Logout</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default SideMenu;
