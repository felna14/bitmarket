import React from "react";

export const CommonTableHeader = ({tableData}) => {
  return (
    <>
    {tableData && tableData?.keys.map((item,index) =>(
      <th key={index}>{item}</th>
    ))}
      <th className="action text-start">Action</th>
    </>
  );
};
