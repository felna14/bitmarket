import React from "react";
import { Link } from "react-router-dom";

export const NotFound = () => {
  return (
    <div className="not-found-container">
      <h1>Page Not Found</h1>
      <p>Oops! The page you requested could not be found.</p>
      <Link to="/" class="btn btn-primary">
        Back To Home
      </Link>
    </div>
  );
};
