import React from 'react';
import { Modal } from 'react-bootstrap';
import '../../assets/scss/modal.scss';
import approved from '../../assets/img/approved-md.svg';
import blockwhiteicon from '../../assets/img/block.svg';

const ConfirmationModal = ({
  isShow,
  setBlockModal,
  handleConfirm,
  isStatus,
}) => {
  return (
    <Modal
      show={isShow}
      className={`${
        !isStatus
          ? 'blocked-modal pass-modal sml-modal'
          : 'modal fade blocked-modal pass-modal   sml-modal'
      }`}
      id="accountApproved"
      data-bs-backdrop="static"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="accountApprovedLabel"
      aria-hidden="true"
      data-backdrop="static"
      centered
    >
      <div className="modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-body">
            <div
              className={`outer-main pop-up-approve ${
                !isStatus ? 'pop-up-approve' : ''
              }`}
            >
              <div className="icons">
                <img src={!isStatus ? approved : blockwhiteicon} alt="" />
              </div>
              <h3 className="heading">
                Are you sure you want to {!isStatus ? 'Unblock' : 'Block'} ?
              </h3>
              <div className="btn-area">
                <button
                  className="btn btn-cus"
                  data-bs-dismiss="modal"
                  onClick={() => {
                    setBlockModal(false);
                  }}
                >
                  Cancel
                </button>
                <button
                  className={`btn btn-cus ${
                    isStatus ? 'btn-delete' : 'btn-green'
                  }`}
                  onClick={() => handleConfirm()}
                >
                  {!isStatus ? 'Unblock' : 'Block'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default ConfirmationModal;
