import React, { Component } from "react";
import {  useNavigate } from "react-router-dom";

const PageHasBeenForceRefreshed = "page-has-been-force-refreshed";

export const withRouter = (Component) => {
  const Wrapper = (props) => {
    const navigate = useNavigate();
    
    return (
      <Component
        navigate={navigate}
        {...props}
        />
    );
  };
  
  return Wrapper;
};

const retryPageLoading = () => {
  const pageHasAlreadyBeenForceRefreshed = JSON.parse(
    window.localStorage.getItem(PageHasBeenForceRefreshed) || "false"
  );
  if (!pageHasAlreadyBeenForceRefreshed) {
    window.localStorage.setItem(PageHasBeenForceRefreshed, "true");
    return window.location.reload();
  } else {
    window.localStorage.setItem(PageHasBeenForceRefreshed, "false");
  }
};

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, info) {
    retryPageLoading();
    this.setState({ hasError: true });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="not-found-container">
          <h1>SOMETHING WENT WRONG</h1>
          <p>
            Don't worry though. Our best man is on the case. Please report error or go back to home
          </p>
            <button 
              className="btn btn-primary"
              onClick={() => {
                this.props.navigate('/')
                window.location.reload();
               
              }}
            >
              Back To Home
            </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default withRouter(ErrorBoundary);
