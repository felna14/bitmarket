import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  value: {
    hidden :false
  },
}

export const commonSlice = createSlice({
  name: 'common',
  initialState,
  reducers: {
    show: (state) => {
      state.value.hidden = !state.value.hidden;
    },
  },
})

export const { show } = commonSlice.actions

export default commonSlice.reducer