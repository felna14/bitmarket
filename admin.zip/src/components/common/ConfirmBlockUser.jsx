import React from 'react';
import { Modal } from 'react-bootstrap';
import rejected from '../../assets/img/blocked-modal.svg';


const ConfirmBlockUser = ({ isShow, setterFunction, icon }) => {
  return (
    <Modal
      className="blocked-modal pass-modal sml-modal "
      id="Rejected"
      data-bs-backdrop="static"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="Rejected"
      aria-hidden="true"
      data-backdrop="static"
      show={isShow}
      centered
    >
      <div className="modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-body">
            <div className="outer-main pop-up-approve">
              <div className="icons">
                <img src={rejected} alt="" />
              </div>
              <h3 className="heading">You Have Been Blocked</h3>
              <div className="btn-area">
                <button
                  className="btn btn-cus btn-delete"
                  onClick={() => setterFunction(false)}
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default ConfirmBlockUser;
