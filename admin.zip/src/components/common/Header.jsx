import React, { useEffect, useState } from "react";
import hamburgermenu from "../../assets/img/hamburger-menu-icon.svg";
// import notificationAlert from '../../assets/img/notification-alert-icon.svg';
import Profile from "../../assets/img/Profile.svg";
import { useDispatch, useSelector } from "react-redux";
import { show } from "./commonSlice";
import { Link, useLocation } from "react-router-dom";
import walletimg from "../../assets/img/disc-wallet.svg";

import BrowserNotification from "./notifications";

import { getProfileDetails } from "../../components/logedAdmin/AccountManagement/Profile/ProfileManagementSlice";
import LogoutModal from "./LogoutModal";
import ConnectWalletModal from "../connectWallet/ConnectWalletModal";
import { disconnectWallet } from "../connectWallet/WalletSlice";

const Header = () => {
  const [showProfile, setShowProfile] = useState(false);
  const [logoutModal, setlogoutModal] = useState(false);
  const [userProfile, setUserProfile] = useState("");
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showConnectWallet, setShowConnectwallet] = useState(false);

  const dispatch = useDispatch();
  const location = useLocation();

  const { profileData } = useSelector(
    (state) => state.profileManagementReducer
  );

  const { AddressOfWallet } = useSelector((state) => state.WalletReducer);

  useEffect(() => {
    if (profileData.data) {
      setUserProfile(profileData.data);
      localStorage.setItem("userDetails", JSON.stringify(profileData.data));
    }
  }, [profileData]);

  useEffect(() => {
    const userDetails = localStorage.getItem("userDetails");
    if (userDetails) {
      setUserProfile(JSON.parse(userDetails));
    }
  }, []);

  const handleDisconnect = async () => {
    await dispatch(disconnectWallet());
  };

  return (
    <>
      <LogoutModal isShow={logoutModal} setShow={setlogoutModal} />
      <ConnectWalletModal
        showModal={showWalletModal}
        closeModal={() => setShowWalletModal(false)}
      />
      <header>
        <div className="left-block">
          <button
            className="btn"
            onClick={() => {
              dispatch(show());
            }}
          >
            <img src={hamburgermenu} alt="hamburger-menu" />
          </button>
          {location.pathname === "/dashboard" && (
            <span className="main-title">Welcome to Dashboard</span>
          )}
        </div>
        <div className="right-block">
          {location.pathname === "/vendorManagement" && (
            <>
              {!AddressOfWallet && (
                <div className="tbl-add-btn">
                  <button
                    type="button"
                    className="btn"
                    fdprocessedid="lz0zbq"
                    onClick={() => {
                      AddressOfWallet
                        ? setShowWalletModal(false)
                        : setShowWalletModal(true);
                    }}
                  >
                    Connect Wallet
                  </button>
                </div>
              )}
              {AddressOfWallet && (
                <div className="wallet-disc-cover">
                  <div className="dropdown">
                    <button
                      className={`btn wallet-disc-btn ${
                        showConnectWallet ? "show" : ""
                      }`}
                      // className="btn wallet-disc-btn"
                      type="button"
                      id="walletDisconnect"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                      onClick={() => setShowConnectwallet(!showConnectWallet)}
                    >
                      {AddressOfWallet
                        ? AddressOfWallet.slice(0, 19) + "..."
                        : ""}
                    </button>
                    <ul
                      className={`dropdown-menu ${
                        showConnectWallet ? "show" : ""
                      }`}
                      aria-labelledby="walletDisconnect"
                    >
                      <li onClick={handleDisconnect}>
                        <a
                          className="dropdown-item"
                          onClick={() =>
                            setShowConnectwallet(!showConnectWallet)
                          }
                        >
                          <img src={walletimg} alt="" />
                          <span>Disconnect wallet</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </>
          )}

          <BrowserNotification />
          <div className="dropdown Profile">
            <button
              className={`btn dropdown-toggle ${showProfile ? "show" : ""}`}
              type="button"
              onClick={() => setShowProfile(!showProfile)}
            >
              <img src={userProfile?.profile_image || Profile} alt="Profile" />
              <h6>
                {userProfile?.admin?.first_name || "William"}{" "}
                {userProfile?.admin?.last_name || "Benjamin"}
                <span>{userProfile?.role || "Admin"}</span>
              </h6>
            </button>
            <ul className={`dropdown-menu  ${showProfile ? "show" : ""}`}>
              <li>
                <Link
                  className="dropdown-item"
                  to="/profile"
                  onClick={() => setShowProfile(!showProfile)}
                >
                  Profile
                </Link>
              </li>
              <li>
                <Link
                  className="dropdown-item"
                  to="/change-admin-password"
                  onClick={() => setShowProfile(!showProfile)}
                >
                  Change Password
                </Link>
              </li>

              <li>
                <a
                  className="dropdown-item"
                  onClick={() => setlogoutModal(true)}
                >
                  Logout
                </a>
              </li>
            </ul>
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
