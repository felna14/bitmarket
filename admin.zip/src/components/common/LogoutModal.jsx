import React from 'react';
import { Modal } from 'react-bootstrap';
import logoutImg from '../../assets/img/logoout.svg';
import '../../assets/css/bootstrap.css';
import '../../assets/scss/modal.scss';
import '../../assets/scss/form.scss';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../login/loginSlice';

const LogoutModal = ({ isShow, setShow }) => {
  const dispatch = useDispatch();
  return (
    <Modal
      show={isShow}
      className="modal fade pass-modal sml-modal logout-modal"
      id="logout"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="logout-modalLabel"
      aria-hidden="true"
      centered
    >
      <div className=" modal-dialog-centered">
        <div className="w-100">
          <div className="modal-body">
            <div className="outer-main d-block">
              <div className="iconsmain">
                <div className="icons">
                  <img src={logoutImg} alt="" />
                </div>
              </div>
              <h3 className="heading">Are you sure want to Logout ?</h3>
              <p className="content">
                You Are Leaving Bitmarket. Please Confirm
              </p>

              <div className="btn-area">
                <button
                  className="btn btn-cus btn-cancel"
                  data-bs-dismiss="modal"
                  onClick={() => {
                    setShow(false);
                  }}
                >
                  Cancel
                </button>
                <button
                  to="/"
                  type="button"
                  className="btn btn-cus btn-save"
                  onClick={() => dispatch(logoutUser())}
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default LogoutModal;
