import React from 'react'
import '../../assets/scss/common.scss'

function LinkExpired() {
  return (
    <div className="link-expired">The Link has been Expired !!</div>
  )
}

export default LinkExpired
