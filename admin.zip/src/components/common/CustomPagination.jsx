import React from 'react';
import Pagination from 'react-paginate';
const CustomPagination = ({ currentPage, totalPages, onPageChange }) => {
  const handlePageClick = (data) => {
    const { selected } = data;
    onPageChange(selected);
  };
  return (
    <Pagination
      forcePage={currentPage - 1}
      pageCount={totalPages}
      pageRangeDisplayed={5}
      onPageChange={handlePageClick}
      className="pagination pagination-lg"
      activeClassName="active"
      pageLinkClassName="page-link"
      activeLinkClassName="page-item active"
      pageClassName="page-item"
      previousClassName="prev-arrow"
      nextClassName="next-arrow"
      previousLabel={<i className="fa-solid fa-chevron-left"></i>}
      nextLabel={<i className="fa-solid fa-chevron-right"></i>}
    />
  );
};

export default CustomPagination;
