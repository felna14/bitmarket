import React from 'react';
import { Modal } from 'react-bootstrap';
import deleteicon from '../../assets/img/delete.svg';
import '../../assets/scss/modal.scss';

const DeleteModal = ({ isShow, handleDelete, setDeleteModal }) => {
  return (
    <Modal
      show={isShow}
      className="modal fade  delete-modal sml-modal"
      id="delete-modal"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="delete-modalLabel"
      aria-hidden="true"
      data-backdrop="static"
      centered
    >
      <div className="modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-body">
            <div className="outer-main">
              <div className="icons-block d-block m-auto">
                <img src={deleteicon} alt="" />
              </div>
              <h3 className="heading">Are you sure you want to delete ?</h3>
              <div className="btn-area">
                <button
                  className="btn btn-cus "
                  data-bs-dismiss="modal"
                  onClick={() => {
                    setDeleteModal(false);
                  }}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-cus btn-save"
                  onClick={() => handleDelete()}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default DeleteModal;
