import React, { useEffect, useRef, useState } from "react";
import "../../../assets/scss/notification.scss";
import notificationAlert from "../../../assets/img/notification-alert-icon.svg";
import {
  getBrowserNotificationsForHeader,
  updateBrowserNotifications,
} from "./NotificationSlice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import moment from "moment";

const BrowserNotification = () => {
  const dispatch = useDispatch();
  const [showSort, setShowSort] = useState(false);
  const navigate = useNavigate();
  const [params] = useState({
    limit: 10,
    page: 1,
  });

  const modalRef = useRef();

  useEffect(() => {
    function handleClickOutside(event) {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setShowSort(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [modalRef]);

  useEffect(() => {
    getData();
    const intervalId = setInterval(getData, 10000);

    // Clean up the interval on component unmount
    return () => clearInterval(intervalId);
  }, [params.limit, params.page]);

  const getData = async () => {
    await dispatch(getBrowserNotificationsForHeader(params));
  };

  const { notificationsData } = useSelector(
    (state) => state.BrowsernotificationReducer
  );

  return (
    <div className="notification-block" ref={modalRef}>
      <div className="dropdown">
        <button
          className={`btn  ${showSort ? "show" : ""} `}
          type="button"
          onClick={() => {
            dispatch(updateBrowserNotifications());
            setShowSort(!showSort);
          }}
        >
          <img src={notificationAlert} alt="" />
          <span className="badge">
            {notificationsData?.unreadNotificationsCount || "0"}
          </span>
        </button>
        <div className={`dropdown-menu ${showSort ? "show" : ""}`}>
          <div className="notification-header">
            <h4 className="notification-header-title">
              Notifications
              <span className="badge">
                {notificationsData?.unreadNotificationsCount || "0"}
              </span>
            </h4>
            <span
              className="notification-header-mark cursor-pointer"
              onClick={() => {
                navigate("/notifications");
                setShowSort(!showSort);
              }}
            >
              View all notifications
            </span>
          </div>

          {notificationsData?.allNotification?.rows &&
            notificationsData?.allNotification?.rows
              .slice(0, 5)
              ?.map((item, index) => (
                <div className="notification-body custom-scroll" key={index}>
                  <ul>
                    <li className="isactive">
                      <span className="dropdown-item" href="#/">
                        <div
                          className="list"
                          onClick={() => {
                            setShowSort(!showSort);
                          }}
                        >
                          <div className="details">
                            <h4 className="title">
                              {item?.order_summary?.variant ? (
                                <>
                                  {item?.order_summary?.product?.product_name} (
                                  {item?.order_summary?.variant?.variant_name})
                                </>
                              ) : (
                                item?.order_summary?.product?.product_name
                              )}
                            </h4>
                            <p className="description">{item?.message}</p>
                            <span className="time">
                              {moment(item?.order_summary?.created_at).format(
                                "DD MMMM YYYY hh:mm A"
                              ) || "-"}
                            </span>
                          </div>
                        </div>
                      </span>
                    </li>
                  </ul>
                </div>
              ))}
          <div className="notification-body custom-scroll">
            <ul>
              {!notificationsData?.allNotification?.rows && (
                <li className="isactive">
                  <a className="dropdown-item" href="#/">
                    <div className="list">
                      <div className="details">
                        <h4 className="title">
                          Sorry! No Notifications Right Now
                        </h4>
                        <p className="description"></p>
                        <span className="time"></span>
                      </div>
                    </div>
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrowserNotification;
