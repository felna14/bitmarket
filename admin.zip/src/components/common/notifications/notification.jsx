import React, { useEffect, useState } from "react";
import "../../../assets/css/bootstrap.css";
import "../../../assets/scss/common.scss";
import "../../../assets/scss/side-nav.scss";
import "../../../assets/scss/header.scss";
import "../../../assets/scss/dashboard.scss";
import "../../../assets/scss/table.scss";
import "../../../assets/scss/form.scss";
import "../../../assets/scss/sub-category.scss";
import "../../../assets/scss/customer-management.scss";
import searchIcon from "../../../assets/img/search-icon.svg";
import noDataFound from "../../../assets/img/no_data.svg";
import Loader from "../../../assets/img/Loader.gif";

import { useDispatch, useSelector } from "react-redux";
import {
  getBrowserNotifications,
  updateBrowserNotifications,
} from "./NotificationSlice";
import CustomPagination from "../CustomPagination";
import moment from "moment";
import { formatMoney } from "../../../config/utils";

const Notification = () => {
  const dispatch = useDispatch();
  const [params, setParams] = useState({
    limit: 10,
    search: "",
    page: 1,
  });

  useEffect(() => {
    getData();
  }, [params.limit, params.search, params.page]);
  useEffect(() => {
    dispatch(updateBrowserNotifications());
  }, []);

  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
      page: 1,
    });
  };
  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const getData = async () => {
    await dispatch(getBrowserNotifications(params));
  };

  const { notificationsData, isLoadingNotifications=false } = useSelector(
    (state) => state.BrowsernotificationReducer
  );

  useEffect(() => {
    if (notificationsData?.allNotification?.count) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(notificationsData?.allNotification?.count),
        totalPages: Math.ceil(
          Number(notificationsData?.allNotification?.count) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [notificationsData]);
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;

  const getImage = (item) => {
    const image =
      item?.order_summary?.variants?.product?.product_images?.[0]
        ?.product_image ??
      item?.order_summary?.product?.product_images?.[0]?.product_image;

    return image || null;
  };

  return (
    <>
      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Notifications</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
            </div>
          </div>
          <div className="table-section custom-scroll custom-scroll-h sub-category-tbl notification-tbl">
            {isLoadingNotifications ? (
              <tr>
                <td className="table-loader" colSpan={5}>
                  <img src={Loader} alt="" />
                </td>
              </tr>
            ) : (
              <>
                <table className="table notification-table">
                  <tbody>
                    <tr>
                      <th>No.</th>
                      <th className="img-notification">Image</th>
                      <th>Product Name</th>
                      <th className="">Title</th>
                      <th className="">Order Status</th>
                      <th className="">Ordered Date</th>
                      <th className="">Price</th>
                    </tr>

                    {notificationsData &&
                    notificationsData?.allNotification?.rows.length ? (
                      notificationsData?.allNotification?.rows?.map(
                        (item, index) => (
                          <tr key={index}>
                            <td>{startSerialNumber + index}</td>
                            <td>
                              <img
                                src={getImage(item)}
                                className="product-img"
                                alt=""
                              />
                            </td>
                            <td> {item?.order_summary?.variant ? (
                              <>
                                {item?.order_summary?.product?.product_name} (
                                {item?.order_summary?.variant?.variant_name})
                              </>
                            ) : (
                              item?.order_summary?.product?.product_name
                            )}</td>
                            <td>{item?.title || "-"}</td>
                            <td>{item?.order_summary?.order_status || "-"}</td>
                            <td>
                              {moment(item?.order_summary?.created_at).format(
                                "DD MMMM YYYY"
                              ) || "-"}
                            </td>
                            <td>{formatMoney(item?.order_summary?.grand_total)}</td>
                          </tr>
                        )
                      )
                    ) : (
                      <tr>
                        <td className="text-center no-data-table" colSpan={7}>
                          <img
                            src={noDataFound}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          {notificationsData?.allNotification?.rows.length ? (
            <div className="footer-table col-md-12">
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            </div>
          ) : null}
        </div>
      </main>
    </>
  );
};

export default Notification;
