import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import serviceEndpoints from "../../../config/serviceEndPoints";
import { ResponseApiConfig } from "../../../config/utils";

export const getBrowserNotifications = createAsyncThunk(
  "notification-management",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("limit", data.limit);
    if (data?.search?.length) {
      params.append("search", data.search);
    }
    if (data.page) {
      params.append("page", data.page);
    }
    const endPoint = `${
      serviceEndpoints.browserNotification
    }?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);


export const getBrowserNotificationsForHeader = createAsyncThunk(
  "notification-management-header",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("limit", data.limit);
    if (data?.search?.length) {
      params.append("search", data.search);
    }
    if (data.page) {
      params.append("page", data.page);
    }
    const endPoint = `${
      serviceEndpoints.browserNotification
    }?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const updateBrowserNotifications = createAsyncThunk(
  "update-notification-management",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
   
      params.append("read_all", true);
    
    const endPoint = `${
      serviceEndpoints.browserNotification
    }?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "put");
  }
);

const notificationSlice = createSlice({
  name: "notification-management",
  initialState: {
    notificationsData: {},
    success: false,
    isLoadingNotifications: false,
    errorMessage: "",
    successMessageCategory: "",
  },

  extraReducers: (builder) => {
    builder
      .addCase(getBrowserNotifications.pending, (state) => {
        state.isLoadingNotifications = TextTrackCueList;
        state.errorMessage = "";
        state.success = false;
      })

      .addCase(getBrowserNotifications.fulfilled, (state, { payload }) => {
        state.isLoadingNotifications = false;
        state.success = true;
        state.notificationsData = payload;
      })
      .addCase(getBrowserNotifications.rejected, (state, { payload }) => {
        state.isLoadingNotifications = false;
        state.notificationsData = {};
        state.success = false;
        state.errorMessage = payload?.message;
      })
      .addCase(getBrowserNotificationsForHeader.pending, (state) => {
        // state.isLoadingNotifications = false;
        state.errorMessage = "";
        state.success = false;
      })

      .addCase(getBrowserNotificationsForHeader.fulfilled, (state, { payload }) => {
        // state.isLoadingNotifications = false;
        state.success = true;
        state.notificationsData = payload;
      })
      .addCase(getBrowserNotificationsForHeader.rejected, (state, { payload }) => {
        state.notificationsData = {};
        state.success = false;
        state.errorMessage = payload?.message;
      })
      .addCase(updateBrowserNotifications.pending, (state) => {
        // state.isLoadingNotifications = true;
        state.errorMessage = "";
        state.success = false;
      })

      .addCase(updateBrowserNotifications.fulfilled, (state, { payload }) => {
        // state.isLoadingNotifications = false;
        state.success = true;
        // state.notificationsData = payload;
      })
      .addCase(updateBrowserNotifications.rejected, (state, { payload }) => {
        // state.notificationsData = {};
        state.success = false;
        state.errorMessage = payload?.message;
      });
  },
});

export default notificationSlice.reducer;
