import React, { useEffect, useState } from "react";
import vendorsvg from "../../../assets/img/vendor.svg";
import vuesaxlinear from "../../../assets/img/vuesax-linear-send.svg";
import Customerssvg from "../../../assets/img/customers.svg";
import vuesaxlinearsend from "../../../assets/img/vuesax-linear-send.svg";
import BarChart from "./Components/BarChart";
import LineChart from "./Components/LineChart";
import { getChartDetails, getDashboardDetails } from "./dashboardSlice";
import { useSelector, useDispatch } from "react-redux";

const DashboardBody = () => {
  const dispatch = useDispatch();
  const [revenueMonthFilter, setRevenueMonthFilter] = useState("this_month");

  const { dashboardChartData, dashboardData } = useSelector(
    (state) => state.dashboardReducer
  );

  const RevenueMaxValue = dashboardChartData?.data?.find((d) =>
    Math.max(d.revenue)
  );
  const CommissionMaxValue = dashboardChartData?.data?.find((d) =>
    Math.max(d.commission)
  );

  useEffect(() => {
    getChartData();
  }, [revenueMonthFilter]);

  useEffect(() => {
    getDashboardData();
  }, []);

  const getDashboardData = async () => {
    await dispatch(getDashboardDetails());
  };

  const getChartData = async () => {
    await dispatch(getChartDetails({ filter: revenueMonthFilter }));
  };

  const [LinechartDataFromApi, setLinechartDataFromApi] = useState({
    labels: dashboardChartData?.data?.map((d) => d.date),

    datasets: [
      {
        label: "Commission Graph",
        data: dashboardChartData?.data?.map((d) => d.commission),
        backgroundColor: ["#7946e8"],
        borderColor: "#7946e8",
        barThickness: 8,
      },
    ],
  });

  useEffect(() => {
    setChartDataFromApi({
      labels: dashboardChartData?.data?.map((d) => d.date),
      datasets: [
        {
          label: "Revenue graph",
          data: dashboardChartData?.data?.map((d) => d.revenue),
          width: "100%",
          backgroundColor: ["#7946e8"],
          barThickness: 8,
          borderRadius: 5,
        },
      ],
    });

    setLinechartDataFromApi({
      labels: dashboardChartData?.data?.map((d) => d.date),

      datasets: [
        {
          label: "Commission Graph",
          data: dashboardChartData?.data?.map((d) => d.commission),
          backgroundColor: ["#7946e8"],
          borderColor: "#7946e8",
          width: "100%",
        },
      ],
    });
  }, [dashboardChartData?.data]);

  const [chartDataFromApi, setChartDataFromApi] = useState({
    labels: dashboardChartData?.data?.map((d) => d.date),
    datasets: [
      {
        label: "Revenue graph",
        data: dashboardChartData?.data?.map((d) => d.revenue),
        width: "100%",
        backgroundColor: ["#7946e8"],
        barThickness: 8,
        borderRadius: 5,
      },
    ],
  });

  const BarOptions = {
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          display: false,
        },
        ticks: {
          stepSize: RevenueMaxValue?.revenue / 6,
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  const LineOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        beginAtZero: true,
        grid: {
          display: false,
          lineWidth: 20,
        },
        ticks: {
          stepSize: CommissionMaxValue?.commission / 4,
        },
      },
    },
  };

  return (
    <>
      <main className="content-block custom-scroll">
        <div className="outer-content-block">
          <div className="dash-vendor-block ">
            <div className="custom-cards-block ">
              <div className="custom-cards">
                <div className="cards-header">
                  <div className="img-block">
                    <img src={vendorsvg} alt="" />
                  </div>
                  <h4>
                    {dashboardData?.vendorsCount} <span>Total Vendor</span>
                  </h4>
                </div>
                <div className="cards-footer">
                  {/* <img src={vuesaxlinear} alt="" /> */}
                  <span className="txt-success">
                    {dashboardData?.lastMonthVendorsCount}
                  </span>
                  <span>Last one month</span>
                </div>
              </div>
              <div className="custom-cards ">
                <div className="cards-header">
                  <div className="img-block">
                    <img src={Customerssvg} alt="" />
                  </div>
                  <h4>
                    {dashboardData?.customerCount} <span>Total Customers</span>
                  </h4>
                </div>
                <div className="cards-footer">
                  {/* <img src={vuesaxlinearsend} alt="" /> */}
                  <span className="txt-success">
                    {dashboardData?.lastMonthCustomerCount}
                  </span>
                  <span>Last one month</span>
                </div>
              </div>
            </div>
            {/* <div className="custom-chart-block ">
              <div className="custom-chart-title">
                <h6 className="title">Total commission received</h6>
                <div className="action ">
                  <div className="dropdown">
                    <select
                      className="btn dropdown-toggle"
                      onChange={(e) => setRevenueMonthFilter(e.target.value)}
                      value={revenueMonthFilter}
                    >
                      <option value="this_month">This Month</option>
                      <option value="last_month">Last Month</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="line-chart-height">
                <LineChart
                  chartData={LinechartDataFromApi}
                  options={LineOptions}
                />
              </div>
            </div> */}
          </div>
          <div className="custom-chart-blocks">
            <div className="custom-chart-title ">
              <h6 className="title">Total Revenue graph</h6>
              <div className="action">
                <div className="dropdown">
                  <select
                    className="btn dropdown-toggle"
                    onChange={(e) => setRevenueMonthFilter(e.target.value)}
                    value={revenueMonthFilter}
                  >
                    <option value="this_month">This Month</option>
                    <option value="last_month">Last Month</option>
                  </select>
                </div>
              </div>
            </div>
            <BarChart chartData={chartDataFromApi} options={BarOptions} />
          </div>
        </div>
      </main>
    </>
  );
};

export default DashboardBody;
