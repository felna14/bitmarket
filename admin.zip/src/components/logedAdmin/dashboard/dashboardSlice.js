
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../config/utils';

export const getChartDetails = createAsyncThunk(
  'dashboard-chart-management',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('filter', data.filter);
    const endPoint = `${serviceEndpoints.dashboardChart}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const getDashboardDetails = createAsyncThunk(
  'dashboard-details',
  async (data, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.dashboardData}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

const dashboardManagementSlice = createSlice({
  name: 'dashboard-management',
  initialState: {
    dashboardChartData: {},
    dashboardData: {},
    isLoading: false,
  },

  extraReducers: (builder) => {
    builder
      .addCase(getChartDetails.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getChartDetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.dashboardChartData = payload;
      })
      .addCase(getChartDetails.rejected, (state) => {
        state.dashboardChartData = {};
        state.isLoading = false;
      })
      .addCase(getDashboardDetails.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getDashboardDetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.dashboardData = payload;
      })
      .addCase(getDashboardDetails.rejected, (state) => {
        state.dashboardData = {};
        state.isLoading = false;
      });
  },
});

export default dashboardManagementSlice.reducer;
