import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import serviceEndpoints from "../../../config/serviceEndPoints";
import { ResponseApiConfig } from "../../../config/utils";

export const clearMessageCategory = createAction("clearMessageCategory");

export const getCategoryDetails = createAsyncThunk(
  "category-management",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("page", data.page);
    params.append("limit", data.limit);
    params.append("name", data.search);
    params.append("sortBy", data.sortby);
    params.append("sortOrder", data.sortOrder);

    const endPoint = `${serviceEndpoints.category}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const getCategoryDataById = createAsyncThunk(
  "single-category-management",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.category}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const postAddCategory = createAsyncThunk(
  "add-category",
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();
    formData.append("image", body.image);
    formData.append("name", body.name);
    formData.append("description", body.description);
    formData.append("slug", body.slug);

    const headers = {
      "Content-Type": "multipart/form-data",
    };

    const endPoint = `${serviceEndpoints.category}`;

    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      "post",
      formData,
      headers
    );
  }
);

export const deletecategoryById = createAsyncThunk(
  "delete-category",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.category}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "delete");
  }
);

export const editCategoryDatabyId = createAsyncThunk(
  "single-category-management-edit",
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();
    body.image && formData.append("image", body.image);
    formData.append("name", body.name);
    formData.append("description", body.description);

    formData.append("platform", "web");
    const headers = {
      "Content-Type": "multipart/form-data",
    };
    const endPoint = `${serviceEndpoints.category}/${editId}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      "patch",
      formData,
      headers
    );
  }
);

export const getAllCategoryDetails = createAsyncThunk(
  "all-categories",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("page", data.page);
    params.append("limit", data.limit);
    params.append("name", data.search);
    params.append("sortBy", data.sortby);
    params.append("sortOrder", data.sortOrder);

    const endPoint = `${serviceEndpoints.category}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

const categoryManagementSlice = createSlice({
  name: "category-management",
  initialState: {
    categoryData: {},
    allCategoryData: {},
    success: false,
    isLoadingCategory: false,
    errorMessage: "",
    successMessageCategory: "",
    singleCategoryData: "",
  },

  extraReducers: (builder) => {
    builder
      .addCase(getCategoryDetails.pending, (state) => {
        state.isLoadingCategory = true;
        state.errorMessage = "";
        state.success = false;
      })

      .addCase(getCategoryDetails.fulfilled, (state, { payload }) => {
        state.isLoadingCategory = false;
        state.success = true;
        state.categoryData = payload;
      })
      .addCase(getCategoryDetails.rejected, (state, { payload }) => {
        state.categoryData = {};
        state.isLoadingCategory = false;
        state.success = false;
      })
      .addCase(getCategoryDataById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
      })

      .addCase(getCategoryDataById.fulfilled, (state, { payload }) => {
        state.singleCategoryData = payload;
        state.isLoading = false;
      })
      .addCase(getCategoryDataById.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
      })
      .addCase(editCategoryDatabyId.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageCategory = "";
      })
      .addCase(editCategoryDatabyId.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageCategory = payload.message;
      })
      .addCase(editCategoryDatabyId.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(deletecategoryById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageCategory = "";
      })
      .addCase(deletecategoryById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageCategory = payload.message;
      })
      .addCase(deletecategoryById.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(postAddCategory.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageCategory = "";
      })
      .addCase(postAddCategory.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageCategory = payload.message;
      })
      .addCase(postAddCategory.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase("clearMessageCategory", (state) => {
        state.errorMessage = "";
        state.successMessageCategory = "";
        state.success = false;
      })
      .addCase(getAllCategoryDetails.pending, (state) => {
        state.allCategoryData = {};
      })

      .addCase(getAllCategoryDetails.fulfilled, (state, { payload }) => {
        state.allCategoryData = payload;
      })
      .addCase(getAllCategoryDetails.rejected, (state, { payload }) => {
        state.allCategoryData = {};
      });
  },
});

export default categoryManagementSlice.reducer;
