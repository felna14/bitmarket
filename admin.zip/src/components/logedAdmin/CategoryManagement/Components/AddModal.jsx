/* eslint-disable jsx-a11y/heading-has-content */
import React, { useState } from 'react';
import { Modal } from 'react-bootstrap';
import upload from '../../../../assets/img/upload-img.svg';
import { useDispatch } from 'react-redux';
import { Field, Formik, ErrorMessage, Form } from 'formik';
import * as yup from 'yup';
import warndngr from '../../../../assets/img/warn-dngr.svg';
import { postAddCategory } from '../categorymanagementSlice';
import { Notifications } from '../../../../config/utils';

const AddModal = ({ isShow, setShow, getCategory }) => {
  const dispatch = useDispatch();
  const [previewUrl, setPreview] = useState('');

  const [filePresent, setFilePresent] = useState('');

  const handleSubmit = async (event) => {
    await dispatch(postAddCategory(event));
    await getCategory();
    setPreview('');
    setFilePresent('');
    setShow(false);
  };
  const handleFileChange = (event, setFieldValue) => {
    const files = event?.target?.files[0];
    if (files?.size > 10e6) {
      Notifications('Please upload a file smaller than 10 MB', 'error');
    } else {
      if (files) {
        setFilePresent(files.name);
        setFieldValue('image', files);
        setPreview(URL.createObjectURL(files));
      }
    }
  };

  return (
    <Modal
      show={isShow}
      className="modal fade sub-cat-edit mid category-management-add-modal"
      id="category-management-add"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="category-management-addLabel"
      aria-hidden="true"
      centered
    >
      <div className="modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="category-management-addLabel">
              Add Category
            </h5>
            {/* <button
              type="button"
              className="btn-close"
              onClick={() => {
                setShow(false);
                setPreview('');
                setFilePresent('');
              }}
            ></button> */}
          </div>
          <Formik
            initialValues={{
              name: '',
              image: '',
              description: '',
              platform: 'web',
            }}
            validationSchema={yup.object({
              name: yup
                .string()
                .trim(' Name without spaces')
                .required('Category Name is Required'),

              description: yup.string().required('Description is Required'),
              image: yup.string().required('Image is Required'),
            })}
            enableReinitialize
            onSubmit={(values, { resetForm }) => {
              handleSubmit(values);
            }}
          >
            {({ values, setFieldValue, isSubmitting }) => (
              <Form>
                <div className="modal-body">
                  <div className="outer-main row">
                    <div className="col-lg-4 upload-sec">
                      <label className="form-label">
                        {' '}
                        Upload Image<span className="text-danger">*</span>
                      </label>

                      <div className="upload-area">
                        <div className="upload">
                          <img
                            src={
                              previewUrl.length
                                ? previewUrl
                                : values.image || upload
                            }
                            alt="Preview"
                          />
                          {!previewUrl.length ? (
                            <>
                              <h3 className="heading">
                                Drag And Drop Your Image Here.
                              </h3>
                              <p className="content">
                                File Should be Jpeg and PNG Maximum Size 5mb.
                              </p>
                            </>
                          ) : null}

                          <Field name="image">
                            {({ field }) => (
                              <>
                                <input
                                  type="file"
                                  accept="image/*"
                                  id="image"
                                  className="upload-hide"
                                  title=""
                                  onChange={(event) =>
                                    handleFileChange(event, setFieldValue)
                                  }
                                />
                              </>
                            )}
                          </Field>
                        </div>
                        <div>
                          <ErrorMessage
                            name="image"
                            render={(msg) => (
                              <span className="error">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>

                        {filePresent ? (
                          <div className="process">
                            <div className="head-sec">
                              <h3 className="name">{filePresent}</h3>
                              <h3 className="size"></h3>
                            </div>
                            <div className="progress">
                              <div
                                className="progress-bar progress-bar-striped"
                                role="progressbar"
                                aria-valuenow="75"
                                aria-valuemin="0"
                                aria-valuemax="100"
                                style={{ width: '100%' }}
                              ></div>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                    <div className="col-lg-8 profile-data-main">
                      <div className=" row profile-data">
                        <div className="col-md-12 form-group frm-itm">
                          <label className="form-label">
                            {' '}
                            Category<span className="text-danger">*</span>
                          </label>
                          <Field
                            name="name"
                            type="text"
                            className="form-control"
                            placeholder="Category"
                          />
                          <ErrorMessage
                            name="name"
                            render={(msg) => (
                              <span className="error">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>
                        <div className="col-md-12 form-group frm-itm address">
                          <label className="form-label">
                            {' '}
                            Description<span className="text-danger">*</span>
                          </label>
                          <Field
                            name="description"
                            as="textarea"
                            className="form-control form-control-textarea"
                            placeholder="Type Here.."
                          ></Field>
                          <ErrorMessage
                            name="description"
                            render={(msg) => (
                              <span className="error">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <div className="btn-area">
                    <button
                      type="button"
                      className="btn btn-cus btn-cancel"
                      data-bs-dismiss="modal"
                      onClick={() => {
                        setShow(false);
                        setPreview('');
                        setFilePresent('');
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="btn btn-cus btn-save"
                    >
                      {isSubmitting ? (
                        <span
                          class="spinner-border spinner-border-sm"
                          role="status"
                          aria-hidden="true"
                        ></span>
                      ) : (
                        'Submit'
                      )}
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </Modal>
  );
};
export default AddModal;
