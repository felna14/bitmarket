import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import galleryimport from "../../../../assets/img/gallery-import.svg";
import profileimg from "../../../../assets/img/avatar.png";
import { useDispatch, useSelector } from "react-redux";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";
import warndngr from "../../../../assets/img/warn-dngr.svg";
import {
  editCategoryDatabyId,
  getCategoryDataById,
} from "../categorymanagementSlice";
import { Notifications } from "../../../../config/utils";
import Loader from "../../../../assets/img/Loader.gif";

const EditModal = ({ isShow, setShow, getCategory, editId }) => {
  const dispatch = useDispatch();
  const [previewUrl, setPreview] = useState("");
  const { singleCategoryData, isLoading } = useSelector(
    (state) => state.categoryManagementReducer
  );
  const initialValues = {
    name: singleCategoryData?.category?.name || "",
    description: singleCategoryData?.category?.description || "",
    image: singleCategoryData?.category?.image || "",
    platform: "web",
  };

  const handleSubmit = async (event) => {
    const data = { ...event, editId: editId };
    await dispatch(editCategoryDatabyId(data));
    await dispatch(getCategoryDataById(editId));
    await getCategory();
    setShow(false);
    setPreview("");
  };

  const handleFileChange = (event, setFieldValue) => {
    const files = event?.target?.files[0];
    if (files?.size > 10e6) {
      Notifications("Please upload a file smaller than 10 MB", "error");
    } else {
      if (files) {
        setFieldValue("image", files);
        setPreview(URL.createObjectURL(files));
      }
    }
  };
  return (
    <Modal
      show={isShow}
      className="modal fade sub-cat-edit mid category-management-editLabel-modal"
      id="category-management-edit"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="category-management-editLabel"
      aria-hidden="true"
      centered
    >
      {isLoading ? (
        <>
          <div className="loaderWrapper loader-wrapper-height ">
            <div className="table-loader">
              <img src={Loader} alt="" />
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="category-management-editLabel">
                  Edit Category{" "}
                </h5>
                {/* <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={() => {
                setShow(false);
                setPreview("");
              }}
            ></button> */}
              </div>
              <Formik
                initialValues={initialValues}
                validationSchema={yup.object({
                  name: yup
                    .string()
                    .trim(" Name without spaces")
                    .required("Category Name is Required"),

                  description: yup.string().required("Description is Required"),
                })}
                enableReinitialize
                onSubmit={(values) => {
                  handleSubmit(values);
                }}
              >
                {({ values, setFieldValue, isSubmitting }) => (
                  <Form>
                    <div className="modal-body">
                      <div className="outer-main row m-0">
                        <div className="col-lg-3 upload-sec">
                          <label className="form-label">
                            {" "}
                            Upload Image<span className="text-danger">*</span>
                          </label>
                          <div className="profile-img">
                            <img
                              src={
                                previewUrl.length
                                  ? previewUrl
                                  : values.image || profileimg
                              }
                              alt="Preview"
                            />
                            <div className="upload-btn">
                              <Field name="image">
                                {({ field }) => (
                                  <>
                                    <input
                                      type="file"
                                      accept="image/*"
                                      id="image"
                                      className="file-input__input"
                                      title=""
                                      onChange={(event) =>
                                        handleFileChange(event, setFieldValue)
                                      }
                                    />
                                  </>
                                )}
                              </Field>
                              <img src={galleryimport} alt="" />
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-9 profile-data-main">
                          <div className=" row profile-data">
                            <div className="col-md-12 form-group frm-itm">
                              <label className="form-label">
                                {" "}
                                Category Name
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                type="text"
                                name="name"
                                className="form-control"
                                placeholder="Category Name"
                              />
                              <ErrorMessage
                                name="name"
                                render={(msg) => (
                                  <span className="error">
                                    <img src={warndngr} alt="" />
                                    {msg}
                                  </span>
                                )}
                              />
                            </div>
                            <div className="col-md-6 form-group frm-itm address">
                              <label className="form-label">
                                {" "}
                                Description
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                className="form-control"
                                name="description"
                                placeholder="Type Here.."
                                as="textarea"
                              />
                              <ErrorMessage
                                name="description"
                                render={(msg) => (
                                  <span className="error">
                                    <img src={warndngr} alt="" />
                                    {msg}
                                  </span>
                                )}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="modal-footer">
                      <div className="btn-area">
                        <button
                          type="button"
                          className="btn btn-cus btn-cancel"
                          data-bs-dismiss="modal"
                          onClick={() => {
                            setShow(false);
                            setPreview("");
                          }}
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="btn btn-cus btn-save"
                        >
                          {isSubmitting ? (
                            <span
                              class="spinner-border spinner-border-sm"
                              role="status"
                              aria-hidden="true"
                            ></span>
                          ) : (
                            "Submit"
                          )}
                        </button>
                      </div>
                    </div>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
};

export default EditModal;
