import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Modal } from "react-bootstrap";
import editpenicon from "../../../../assets/img/edit-pen-icon.svg";
import DeleteModal from "../../../common/deletemodal";
import EditModal from "./EditModal";
import deleteicon from "../../../../assets/img/delete-icon-red.svg";
import profileimg from "../../../../assets/img/avatar.png";
import Loader from "../../../../assets/img/Loader.gif";

import { deletecategoryById } from "../categorymanagementSlice";

const ViewModal = ({ isShow, setShow, viewId, getCategory, itemIsActive }) => {
  const [deleteModal, setDeleteModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const dispatch = useDispatch();
  const { singleCategoryData, isLoading } = useSelector(
    (state) => state.categoryManagementReducer
  );

  const handleEdit = () => {
    setEditModal(true);
  };

  const handleShowDelete = async () => {
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    await dispatch(deletecategoryById(viewId));
    await getCategory();
    setDeleteModal(false);
    setShow(false);
  };

  return (
    <>
      <DeleteModal
        isShow={deleteModal}
        handleDelete={handleDelete}
        setDeleteModal={setDeleteModal}
      />
      <EditModal
        isShow={editModal}
        setShow={setEditModal}
        editId={viewId}
        getCategory={getCategory}
      />
      <Modal
        show={isShow}
        className="modal fade cat-view mid management-view-modal-block"
        id="management-view"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="managementLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="managementLabel">
                    View Category
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => {
                      setShow(false);
                    }}
                  ></button>
                </div>

                <div className="modal-body">
                  <div className="outer-main row ">
                    <div className="col-md-8 content-sec">
                      <div className="product-info">
                        <div className="frm-itm">
                          <label className="form-label"> Category</label>
                          <h3 className="frm-value">
                            {singleCategoryData?.category?.name || ""}
                          </h3>
                        </div>
                        <div className="frm-itm light-red">
                          <label className="form-label"> Description</label>
                          <h3 className="frm-value">
                            {singleCategoryData?.category?.description || ""}
                          </h3>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4 imge-sec">
                      <div className="img-area img-area-section">
                        <img
                          src={
                            singleCategoryData?.category?.image || profileimg
                          }
                          alt=""
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  {itemIsActive === true && (
                    <div className="btn-area">
                      <button
                        type="button"
                        className="btn btn-cus edit-Button"
                        onClick={() => handleEdit()}
                      >
                        <img src={editpenicon} alt="" />
                        Edit
                      </button>
                      <button
                        type="button"
                        className="btn btn-cus btn-del"
                        onClick={() => handleShowDelete()}
                      >
                        <img
                          src={deleteicon}
                          alt=""
                          data-bs-toggle="modal"
                          data-bs-target="#delete-modal"
                        />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </Modal>
    </>
  );
};

export default ViewModal;
