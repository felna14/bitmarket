import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import ViewModal from './Components/ViewModal';
import EditModal from './Components/EditModal';
import AddModal from './Components/AddModal';
import DeleteModal from '../../common/deletemodal';
import CustomPagination from '../../common/CustomPagination';
import {
  deletecategoryById,
  getCategoryDataById,
  getCategoryDetails,
  clearMessageCategory,
} from './categorymanagementSlice';
import { Tooltip } from 'react-tooltip';
import searchIcon from '../../../assets/img/search-icon.svg';
import viewicon from '../../../assets/img/view-icon.svg';
import editIcon from '../../../assets/img/edit-icon.svg';
import deleteicon from '../../../assets/img/table-delete-icon.svg';
import filtericon from '../../../assets/img/filter-filled.svg';
import plusicon from '../../../assets/img/plus.svg';
import fourdot from '../../../assets/img/four-square.svg';
import Loader from '../../../assets/img/Loader.gif';
import nodataicon from '../../../assets/img/no_data.svg';
import profileimg from '../../../assets/img/avatar.png';

import '../../../assets/css/bootstrap.css';
import '../../../assets/scss/customer-management.scss';
import '../../../assets/scss/table.scss';
import '../../../assets/scss/form.scss';
import '../../../assets/scss/modal.scss';
import '../../../assets/scss/common.scss';

import { Notifications } from '../../../config/utils';

const CategoryManagement = () => {
  const [viewModal, setViewModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [addModal, setAddModal] = useState(false);
  const [dataId, setDataId] = useState('');
  const [showSort, setShowSort] = useState(false);
  const [itemIsActive, setItemActive] = useState(false);

  const {
    categoryData,
    successMessageCategory,
    errorMessage,
    isLoadingCategory,
  } = useSelector((state) => state.categoryManagementReducer);
  const dispatch = useDispatch();
  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: '',
    sortby: 'created_at',
    sortOrder: 'desc',
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  useEffect(() => {
    getCategory();
  }, [params.page, params.search, params.sortby, params.sortOrder]);
  useEffect(() => {
    if (params.search !== '') {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);
  useEffect(() => {
    if (categoryData?.pagination?.total) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(categoryData?.pagination?.total),
        totalPages: Math.ceil(
          Number(categoryData?.pagination?.total) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [categoryData?.pagination?.total]);

  useEffect(() => {
    if (successMessageCategory) {
      Notifications(successMessageCategory, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageCategory());
  }, [successMessageCategory, errorMessage]);

  const getCategory = async () => {
    await dispatch(getCategoryDetails(params));
  };
  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };
  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  const handleShowView = (item) => {
    setDataId(item.id);
    setViewModal(true);
    dispatch(getCategoryDataById(item.id));
    if (item?.is_active === true) setItemActive(true);
    else setItemActive(false);
  };

  const handleEdit = (item) => {
    setDataId(item.id);
    dispatch(getCategoryDataById(item.id));
    setEditModal(true);
  };

  const handleDeleteUser = (id) => {
    setDataId(id);
    setDeleteModal(true);
  };
  const handleDelete = async () => {
    await dispatch(deletecategoryById(dataId));
    await getCategory();
    setDeleteModal(false);
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;
  return (
    <>
      <Tooltip id="category-tooltip" className="tooltip" multiline={true} />
      <ViewModal
        isShow={viewModal}
        setShow={setViewModal}
        viewId={dataId}
        getCategory={getCategory}
        itemIsActive={itemIsActive}
      />
      <EditModal
        isShow={editModal}
        setShow={setEditModal}
        editId={dataId}
        getCategory={getCategory}
      />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <AddModal
        isShow={addModal}
        setShow={setAddModal}
        getCategory={getCategory}
      />

      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Category Management</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
              <div className="tbl-filter-block ">
                <div className="dropdown">
                  <button
                    className={`btn  ${showSort ? 'show' : ''} `}
                    type="button"
                    id="tbl-filter"
                    data-bs-toggle="dropdown"
                    aria-expanded="true"
                    onClick={() => setShowSort(!showSort)}
                  >
                    <img src={filtericon} alt="filter" />
                  </button>
                  <ul
                    className={`dropdown-menu dropdown-menu-end ${
                      showSort ? 'show' : ''
                    }`}
                    onClick={() => setShowSort(!showSort)}
                  >
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'name' && params.sortOrder === 'asc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'name',
                            sortOrder: 'asc',
                            page: 1,
                          })
                        }
                      >
                        A-Z
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'name' &&
                          params.sortOrder === 'desc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'name',
                            sortOrder: 'desc',
                            page: 1,
                          })
                        }
                      >
                        Z-A
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="tbl-add-btn">
                <button
                  className="btn"
                  data-bs-toggle="modal"
                  data-bs-target="#category-management-add"
                  onClick={() => setAddModal(true)}
                >
                  <img src={plusicon} alt="plus" />
                  <span>Add Category</span>
                </button>
              </div>
            </div>
          </div>
          <div className="table-section custom-scroll custom-scroll-h custom-scroll-h sub-category-tbl category-table">
            {isLoadingCategory ? (
              <tr>
                <td className="table-loader" colSpan={6}>
                  <img src={Loader} alt="" />
                </td>
              </tr>
            ) : (
              <>
                <table className="table">
                  <tbody>
                    <tr>
                      <th>
                        {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                        No.
                      </th>
                      <th className="custm-table-imgClass">Image</th>
                      <th className="category-name">Name</th>
                      <th className="tbl-description">Description</th>
                      <th className="action">Active</th>
                      <th className="action">Action</th>
                    </tr>
                    {categoryData && categoryData?.rows?.length ? (
                      categoryData?.rows?.map((item, index) => (
                        <tr key={index}>
                          <td>
                            {startSerialNumber + index}
                            {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                          </td>
                          <td>
                            <img
                              src={item.image || profileimg}
                              className="product-img"
                              alt="product"
                            />
                          </td>
                          <td>{item.name || ''}</td>
                          <td
                            className="td-description"
                            data-tooltip-id="category-tooltip"
                            data-tooltip-content={
                              item.description.length > 60
                                ? item.description
                                : ''
                            }
                          >
                            {item.description || ''}
                          </td>
                          <td
                            className={
                              item?.is_active === true
                                ? 'approved-txt'
                                : 'rejected-txt'
                            }
                          >
                            {item?.is_active === true ? 'Yes' : 'No' || ''}
                          </td>

                          <td>
                            <div className="action-icons d-flex">
                              <img
                                className="ms-0"
                                src={viewicon}
                                data-tooltip-id="category-tooltip"
                                data-tooltip-content="View"
                                alt=""
                                onClick={() => handleShowView(item)}
                              />
                              {item?.is_active === true ? (
                                <>
                                  <img
                                    src={editIcon}
                                    className="edit-icon"
                                    alt=""
                                    data-tooltip-id="category-tooltip"
                                    data-tooltip-content="Edit"
                                    onClick={() => handleEdit(item)}
                                  />
                                  <img
                                    src={deleteicon}
                                    className="delete-icon"
                                    alt=""
                                    data-tooltip-id="category-tooltip"
                                    data-tooltip-content="Delete"
                                    onClick={() => handleDeleteUser(item.id)}
                                  />
                                </>
                              ) : (
                                ''
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td className="text-center no-data-table" colSpan={6}>
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {categoryData?.rows?.length ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default CategoryManagement;
