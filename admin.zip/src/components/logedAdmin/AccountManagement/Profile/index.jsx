import React, { useEffect, useState } from 'react';

import editpenicon from '../../../../assets/img/edit-pen-icon.svg';
import profileimg from '../../../../assets/img/profileimg.png';
import noImage from '../../../../assets/img/noImage.jpg';

import '../../../../assets/scss/dashboard.scss';
import '../../../../assets/scss/customer-management.scss';
import '../../../../assets/scss/table.scss';
import '../../../../assets/scss/form.scss';
import '../../../../assets/scss/modal.scss';
import '../../../../assets/css/bootstrap.css';
import '../../../../assets/scss/common.scss';
import '../../../../assets/scss/side-nav.scss';
import '../../../../assets/scss/profile.scss';

import EditModal from './components/EditModal';
import { useDispatch, useSelector } from 'react-redux';
import { getProfileDetails } from './ProfileManagementSlice';

const Profile = () => {
  const [editModal, setEditModal] = useState(false);
  const dispatch = useDispatch();

  const { profileData } = useSelector(
    (state) => state.profileManagementReducer
  );

  useEffect(() => {
    getProfile();
  }, []);

  const getProfile = async () => {
    await dispatch(getProfileDetails());
  };

  return (
    <>
      <EditModal isShow={editModal} setShow={setEditModal} />
      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Profile</h3>
            </div>
            <div className="right-filter">
              <div className="profile-edit-block">
                <button
                  className="btn edit-btn"
                  onClick={() => setEditModal(true)}
                >
                  <img
                    src={editpenicon}
                    className="profile-edit-icon"
                    alt="edit"
                  />
                  Edit Profile
                </button>
              </div>
            </div>
          </div>
          <div className="profile-block-section">
            <div className="profile-pic-block">
              <img
                src={profileData?.data?.profile_image || noImage}
                className="profile-pic"
                alt=""
              />
            </div>

            <div className="profile-txt-section">
              <div className="profile-txt-block">
                <div className="profile-txt">
                  <label className="profile-label">First Name</label>
                  <h6 className="user-txt">
                    {profileData?.data?.admin?.first_name}
                  </h6>
                </div>
              </div>
              <div className="profile-txt-block">
                <div className="profile-txt">
                  <label for="" className="profile-label">
                    Last Name
                  </label>
                  <h6 className="user-txt">
                    {profileData?.data?.admin?.last_name}
                  </h6>
                </div>
              </div>
              <div className="profile-txt-block">
                <div className="profile-txt">
                  <label for="" className="profile-label">
                    Phone Number
                  </label>
                  <h6 className="user-txt">{profileData?.data?.phone}</h6>
                </div>
              </div>
              <div className="profile-txt-block">
                <div className="profile-txt">
                  <label for="" className="profile-label">
                    Email ID
                  </label>
                  <h6 className="user-txt">{profileData?.data?.email}</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default Profile;
