import { createSlice, createAsyncThunk, createAction } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../../config/utils';

export const clearMessageCategory = createAction('clearMessageCategory');

export const getProfileDetails = createAsyncThunk(
  'profile-management',
  async (data, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.profile}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const editProfileDetails = createAsyncThunk(
  'profile-edit',
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();
    body?.profile_image && formData.append('profile_image', body.profile_image);
    formData.append('first_name', body.first_name);
    formData.append('last_name', body.last_name);
    body?.phone && body?.phone?.length ? formData.append('phone', body.phone) : formData.append('phone', "")
    formData.append('email', body.email);
    formData.append('platform', 'web');

    const headers = {
      'Content-Type': 'multipart/form-data',
    };
    const endPoint = `${serviceEndpoints.profile_update}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      'put',
      formData,
      headers
    );
  }
);

const ProfileManagementSlice = createSlice({
  name: 'profile-management',
  initialState: {
    profileData: '',
    isLoading: false,
    updateSuccessMsg: '',
    UpdateErrorMessage: '',
  },
  extraReducers: (builder) => {
    builder
      .addCase(getProfileDetails.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getProfileDetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.profileData = payload;
        state.successMessage = payload.message;
      })
      .addCase(getProfileDetails.rejected, (state, { payload }) => {
        state.profileData = '';
        state.errorMessage = payload.message;
      })
      .addCase(editProfileDetails.pending, (state) => {
        state.isLoading = true;
      })

      .addCase(editProfileDetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.profileData = payload;
        state.updateSuccessMsg = payload.message;
      })
      .addCase(editProfileDetails.rejected, (state, { payload }) => {
        state.profileData = '';
        state.UpdateErrorMessage = payload.message;
      });
  },
});

export default ProfileManagementSlice.reducer;
