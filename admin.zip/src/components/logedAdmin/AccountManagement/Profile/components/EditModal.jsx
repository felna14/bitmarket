import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import profileimg from "../../../../../assets/img/profileimg.png";
import galleryimport from "../../../../../assets/img/gallery-import.svg";
import warndngr from "../../../../../assets/img/warn-dngr.svg";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";

import { useDispatch, useSelector } from "react-redux";
import {
  editProfileDetails,
  getProfileDetails,
} from "../ProfileManagementSlice";
import { Notifications } from "../../../../../config/utils";
import parsePhoneNumberFromString from "libphonenumber-js";

const EditModal = ({ isShow, setShow }) => {
  const [previewUrl, setPreview] = useState("");
  const { profileData, updateSuccessMsg } = useSelector(
    (state) => state.profileManagementReducer
  );
  const dispatch = useDispatch();
  useEffect(() => {
    getProfile();
  }, []);

  const getProfile = async () => {
    await dispatch(getProfileDetails());
  };

  const handleSubmit = async (data) => {
    await dispatch(editProfileDetails(data));
    await Notifications(updateSuccessMsg, "success");
    dispatch(getProfileDetails());
    setShow(false);
  };

  const handleFileChange = (event, setFieldValue) => {
    const files = event.target.files[0];
    setFieldValue("profile_image", files);
    setPreview(URL.createObjectURL(files));
  };

  return (
    <Modal
      show={isShow}
      className="modal fade vedr-edit mid"
      id="ProfileEdit"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="ProfileEditLabel"
      aria-hidden="true"
      centered
    >
      <Formik
        initialValues={{
          first_name: profileData ? profileData?.data?.admin?.first_name : "",
          last_name: profileData ? profileData?.data?.admin?.last_name : "",
          email: profileData ? profileData?.data?.email : "",
          phone: profileData ? profileData?.data?.phone : "",
          profile_image: "",
        }}
        validationSchema={yup.object({
          first_name: yup
            .string()
            .trim("First Name without Spaces")
            .required("First Name is Required")
            .matches(
              /^([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\s]*)$/gi,
              "Name can only contain Latin letters."
            ),
          last_name: yup
            .string()
            .trim("Last Name without spaces")
            .required("Last Name is Required")
            .matches(
              /^([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\s]*)$/gi,
              "Name can only contain Latin letters."
            ),
            phone: yup
            .string()
            .test("Invalid Phone Number", (value) => {
              if (!value) {
                return false;
              }
             
              const phoneNumber = parsePhoneNumberFromString(value);
              return phoneNumber ? phoneNumber.isValid() : false;
            })
            .matches(/^[0-9+]+$/, "Phone Number must contain only numbers")
            .required("Phone Number is Required"),
          email: yup
            .string()
            .required("Email Id is Required")
            .email("Invalid Email Id"),
        })}
        enableReinitialize
        onSubmit={(values) => {
          handleSubmit(values);
        }}
      >
        {({ values, setFieldValue, isSubmitting }) => (
          <Form>
            <div className="">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="ProfileEditLabel">
                    Edit Profile
                  </h5>
                  {/* <button
                    type="button"
                    className="btn-close"
                    onClick={() => {
                      setShow(false);
                      setPreview("");
                    }}
                  ></button> */}
                </div>

                <div className="modal-body">
                  <div className="outer-main">
                    <div className="col-md-4 profile-img-up">
                      <label className="form-label"> Upload Image</label>
                      <div className="profile-img">
            
                        <img
                          src={
                            previewUrl ||
                            profileData?.data?.profile_image ||
                            profileimg
                          }
                          className="Vendor-pic-block"
                          alt="Preview"
                        />
                        <div className="upload-btn">
                          <Field name="profile_image">
                            {({ field }) => (
                              <>
                                <input
                                  type="file"
                                  accept="image/*"
                                  id="profile_image"
                                  className="file-input__input"
                                  title=""
                                  onChange={(event) =>
                                    handleFileChange(event, setFieldValue)
                                  }
                                />
                              </>
                            )}
                          </Field>
                          <img src={galleryimport} alt="" />
                        </div>
                        {/* <ErrorMessage
                          name="profile_image"
                          render={(msg) => (
                            <span className="val-msg-profile-img">
                              <img src={warndngr} alt="" /> {msg}
                            </span>
                          )}
                        /> */}
                      </div>
                    </div>

                    <div className="col-md-8 profile-data-main">
                      <div className=" row profile-data">
                        <div className="col-md-6 form-group frm-itm">
                          <label className="form-label">
                            First Name{" "}
                            <span className="">
                              <span className="text-danger">*</span>
                            </span>
                          </label>
                          <Field
                            type="text"
                            name="first_name"
                            className="form-control"
                            placeholder="Enter First Name"
                          />
                          <ErrorMessage
                            name="first_name"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>

                        <div className="col-md-6 form-group frm-itm">
                          <label className="form-label">
                            Last Name{" "}
                            <span className="">
                              <span className="text-danger">*</span>
                            </span>
                          </label>
                          <Field
                            type="text"
                            name="last_name"
                            className="form-control"
                            placeholder=" Enter Last Name"
                          />
                          <ErrorMessage
                            name="last_name"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>

                        <div className="col-md-6 form-group frm-itm tel tel-block-space">
                          <label className="form-label">Phone Number</label>
                          <div className="phone-number">
                            <Field
                              type="text"
                              name="phone"
                              maxlength="14"
                              minlength="7"
                              className="form-control"
                              placeholder="Phone number"
                            />
                            <ErrorMessage
                              name="phone"
                              render={(msg) => (
                                <span className="val-msg">
                                  <img src={warndngr} alt="" />
                                  {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>

                        <div className="col-md-6 form-group frm-itm tel">
                          <label className="form-label">
                            Email ID{" "}
                            <span className="">
                              <span className="text-danger">*</span>
                            </span>
                          </label>
                          <Field
                            type="email"
                            name="email"
                            className="form-control cursor-not-allowed"
                            placeholder="Enter email id"
                            disabled
                          />
                          <ErrorMessage
                            name="email"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <div className="btn-area">
                    <button
                      type="button"
                      className="btn btn-cus btn-cancel"
                      data-bs-dismiss="modal"
                      onClick={() => setShow(false)}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="btn btn-cus btn-save"
                    >
                      {isSubmitting ? (
                        <span
                          class="spinner-border spinner-border-sm"
                          role="status"
                          aria-hidden="true"
                        ></span>
                      ) : (
                        "Save"
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Modal>
  );
};

export default EditModal;
