import { createSlice, createAsyncThunk, createAction } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../../config/utils';

export const clearChangePasswordMessage = createAction(
  'clearChangePasswordMessage'
);

export const changePasswordRequest = createAsyncThunk(
  'change-password-request',
  async (data, { rejectWithValue }) => {
    const { ...body } = data;
    const formData = new FormData();
    formData.append('oldPassword', body.oldPassword);
    formData.append('newPassword', body.newPassword);
    formData.append('confirmPassword', body.confirmPassword);

    const headers = {
      'Content-Type': 'multipart/form-data',
    };
    const endPoint = `${serviceEndpoints.profile_changePassword}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      'put',
      formData,
      headers
    );
  }
);



const ChangePasswordSlice = createSlice({
  name: 'change-password-slice',
  initialState: {
    succesMessageChangePassword: '',
    isLoading: false,
    errorMessage: '',
  },

  extraReducers: (builder) => {
    builder
      .addCase(changePasswordRequest.pending, (state) => {
        state.isLoading = true;
        state.succesMessageChangePassword = '';
        state.errorMessage = '';
      })

      .addCase(changePasswordRequest.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.succesMessageChangePassword = payload.message;
        state.errorMessage = '';
      })
      .addCase(changePasswordRequest.rejected, (state) => {
        state.isLoading = false;
        state.succesMessageChangePassword = '';
        state.errorMessage = state.message;
      })
      .addCase('clearChangePasswordMessage', (state) => {
        state.isLoading = false;
        state.succesMessageChangePassword = '';
        state.errorMessage = '';
      });
  },
});

export default ChangePasswordSlice.reducer;
