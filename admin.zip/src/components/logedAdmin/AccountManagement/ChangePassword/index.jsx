import React, { useEffect, useState } from 'react';
import loglock from '../../../../assets/img/log-lock.svg';
import eyelock from '../../../../assets/img/eye-locked.svg';
import '../../../../assets/css/bootstrap.css';
import '../../../../assets/scss/common.scss';
import '../../../../assets/scss/side-nav.scss';
import '../../../../assets/scss/header.scss';
import '../../../../assets/scss/customer-management.scss';
import '../../../../assets/scss/form.scss';
import '../../../../assets/scss/modal.scss';
import '../../../../assets/scss/change-password.scss';
import eyeunlock from '../../../../assets/img/eye-unlock.svg';
import warndngr from '../../../../assets/img/warn-dngr.svg';
import { Form, Formik, Field, ErrorMessage } from 'formik';
import * as yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import {
  changePasswordRequest,
  clearChangePasswordMessage,
} from './ChangePasswordSlice';
import { Notifications } from '../../../../config/utils';
import Loader from '../../../../assets/img/Loader.gif';

const ChangePassword = () => {
  const dispatch = useDispatch();
  const [passwordHide, setPasswordHide] = useState({
    oldPasswordHide: false,
    newPasswordHide: false,
    confirmPasswordHide: false,
  });
  const { succesMessageChangePassword, errorMessage, isLoading } = useSelector(
    (state) => state.changePasswordReducer
  );
  useEffect(() => {
    if (succesMessageChangePassword) {
      Notifications(succesMessageChangePassword, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearChangePasswordMessage());
  }, [succesMessageChangePassword, errorMessage]);

  const handleSubmit = async (values) => {
    await dispatch(changePasswordRequest(values));
  };

  return (
    <main className="content-block custom-scroll">
      {isLoading ? (
        <div
          className="table-loader"
          // colSpan={productTableData?.keys?.length + 2}
        >
          <img src={Loader} alt="" />
        </div>
      ) : (
        <div className="right-section-outer">
          <Formik
            initialValues={{
              oldPassword: '',
              newPassword: '',
              confirmPassword: '',
            }}
            validationSchema={yup.object({
              oldPassword: yup
                .string()
                .required(' Current Password is Required')
                .min(8, 'Your password is too short.'),
              newPassword: yup
                .string()
                .required(' New Password is Required')
                .min(8, 'Your password is too short.')
                .matches(
                  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                  'Must Contain 8 Characters, Uppercase, Lowercase, Number & One Special Case Character'
                ),
              confirmPassword: yup
                .string()
                .required(' Confirm Password is Required')
                .oneOf(
                  [yup.ref('newPassword')],
                  'Your passwords do not match.'
                ),
            })}
            onSubmit={(values, { resetForm }) => {
              handleSubmit(values);
            }}
          >
            {({ resetForm }) => (
              <Form>
                <div className="top-title-section">
                  <div className="title-text">
                    <h3>Change Password</h3>
                  </div>
                  <div className="right-filter"></div>
                </div>
                <div className="change-password-block">
                  <div className="form-block">
                    <div className="cutom-form-control">
                      <label htmlFor="oldPassword" className="form-label">
                        Current Password<span className="text-danger">*</span>
                      </label>
                      <div className="input-group cutom-input-group">
                        <span className="input-group-text">
                          <img src={loglock} alt="" />
                        </span>
                        <Field
                          type={
                            passwordHide.oldPasswordHide ? 'text' : 'password'
                          }
                          name="oldPassword"
                          className="form-control"
                          placeholder="Current Password"
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                        />
                        <ErrorMessage
                          name="oldPassword"
                          render={(msg) => (
                            <span className="val-msg">
                              <img src={warndngr} alt="" /> {msg}
                            </span>
                          )}
                        />
                        <span className="input-group-text">
                          {passwordHide.oldPasswordHide ? (
                            <img
                              src={eyeunlock}
                              alt=""
                              onClick={() =>
                                setPasswordHide((prevState) => ({
                                  ...prevState,
                                  oldPasswordHide: !prevState.oldPasswordHide,
                                }))
                              }
                            />
                          ) : (
                            <img
                              src={eyelock}
                              alt=""
                              onClick={() =>
                                setPasswordHide((prevState) => ({
                                  ...prevState,
                                  oldPasswordHide: !prevState.oldPasswordHide,
                                }))
                              }
                            />
                          )}
                        </span>
                      </div>
                    </div>
                    <div className="cutom-form-control">
                      <label htmlFor="newPassword" className="form-label">
                        New Password<span className="text-danger">*</span>
                      </label>
                      <div className="input-group cutom-input-group">
                        <span className="input-group-text">
                          <img src={loglock} alt="" />
                        </span>
                        <Field
                          type={
                            passwordHide.newPasswordHide ? 'text' : 'password'
                          }
                          name="newPassword"
                          className="form-control"
                          placeholder="New Password"
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                        />
                        <ErrorMessage
                          name="newPassword"
                          render={(msg) => (
                            <span className="val-msg">
                              <img src={warndngr} alt="" /> {msg}
                            </span>
                          )}
                        />
                        <span className="input-group-text">
                          {passwordHide.newPasswordHide ? (
                            <img
                              src={eyeunlock}
                              alt=""
                              onClick={() =>
                                setPasswordHide((prevState) => ({
                                  ...prevState,
                                  newPasswordHide: !prevState.newPasswordHide,
                                }))
                              }
                            />
                          ) : (
                            <img
                              src={eyelock}
                              alt=""
                              onClick={() =>
                                setPasswordHide((prevState) => ({
                                  ...prevState,
                                  newPasswordHide: !prevState.newPasswordHide,
                                }))
                              }
                            />
                          )}
                        </span>
                      </div>
                    </div>
                    <div className="cutom-form-control">
                      <label htmlFor="confirmPassword" className="form-label">
                        Confirm Password<span className="text-danger">*</span>
                      </label>
                      <div className="input-group cutom-input-group">
                        <span className="input-group-text">
                          <img src={loglock} alt="" />
                        </span>
                        <Field
                          type={
                            passwordHide.confirmPasswordHide
                              ? 'text'
                              : 'password'
                          }
                          name="confirmPassword"
                          className="form-control"
                          placeholder="Confirm Password"
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                        />
                        <ErrorMessage
                          name="confirmPassword"
                          render={(msg) => (
                            <span className="val-msg">
                              <img src={warndngr} alt="" /> {msg}
                            </span>
                          )}
                        />
                        <span className="input-group-text">
                          {passwordHide.confirmPasswordHide ? (
                            <img
                              src={eyeunlock}
                              alt=""
                              onClick={() =>
                                setPasswordHide((prevState) => ({
                                  ...prevState,
                                  confirmPasswordHide:
                                    !prevState.confirmPasswordHide,
                                }))
                              }
                            />
                          ) : (
                            <img
                              src={eyelock}
                              alt=""
                              onClick={() =>
                                setPasswordHide((prevState) => ({
                                  ...prevState,
                                  confirmPasswordHide:
                                    !prevState.confirmPasswordHide,
                                }))
                              }
                            />
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="btn-area">
                    <button
                      type="button"
                      onClick={() => resetForm()}
                      className="btn btn-cus btn-cancel"
                    >
                      Reset
                    </button>
                    <button type="submit" className="btn btn-cus btn-save">
                      Save
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      )}
    </main>
  );
};

export default ChangePassword;
