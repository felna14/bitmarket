import React, { useEffect, useState } from "react";
import searchIcon from "../../../assets/img/search-icon.svg";
import filterIcon from "../../../assets/img/filter-filled.svg";
import Approved from "../../../assets/img/approved-icon.svg";
import ApprovedDisable from "../../../assets/img/approved-disabled.svg";
import view from "../../../assets/img/view-icon.svg";
import edit from "../../../assets/img/edit-icon.svg";
import deleteIcon from "../../../assets/img/table-delete-icon.svg";
import nodataicon from "../../../assets/img/no_data.svg";
import reject from "../../../assets/img/reject-icons.svg";
import block from "../../../assets/img/block-icon.svg";
import Pending from "../../../assets/img/pending-clock-icon.svg";
import moment from "moment";
import unBlockIcon from "../../../assets/img/unblocked-icon.svg";
import DisabledReject from "../../../assets/img/reject-icon-disabled.svg";
import Loader from "../../../assets/img/Loader.gif";
import greenWalletIcon from "../../../assets/img/add_vendor_green.svg";
import greyWalletIcon from "../../../assets/img/add_vendor_grey.svg";
import ConnectWalletModal from "../../connectWallet/ConnectWalletModal";

import "../../../assets/css/bootstrap.css";
import "../../../assets/scss/header.scss";
import "../../../assets/scss/dashboard.scss";
import "../../../assets/scss/customer-management.scss";
import "../../../assets/scss/table.scss";
import "../../../assets/scss/form.scss";
import "../../../assets/scss/modal.scss";
import "../../../assets/scss/common.scss";
import "../../../assets/scss/side-nav.scss";
import "../../../assets/scss/filter.scss";

import ViewModal from "./Components/viewModal";
import EditModal from "./Components/EditModal";
import DeleteModal from "../../common/deletemodal";
import { CommonTableHeader } from "../../common/CommonTableHeader";
import { vendorTableData } from "../../../config/TableData";
import CustomPagination from "../../common/CustomPagination";
import { useDispatch, useSelector } from "react-redux";
import { Tooltip } from "react-tooltip";
import {
  blockVendorToggleById,
  clearMessageVendor,
  deleteVendorUserById,
  getVendorDataById,
  getVendorDetails,
  PostBlockChainTrackedResponseToBackend,
  updateStatus,
} from "./vendorManagementSlice";
import { Notifications } from "../../../config/utils";
import ConfirmPopUp from "../../common/ConfirmPopUp";
import ConfirmRejectPopup from "../../common/ConfirmRejectPopup";
import ConfirmationModal from "../../common/ConfirmationModal";
import { useMemo } from "react";
import { VendorAuthorise } from "../../Contractor";

import { disconnectWallet } from "../../connectWallet/WalletSlice";
import ConfirmationApproveModal from "./Components/ConfirmationApproveModal";
// import VendorAuthorise from '../../Contractor/VendorAuthorise';

const VendorManagement = () => {
  const [viewModal, setViewModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [isConfirm, setIsConfirm] = useState(false);
  const [isReject, setIsReject] = useState(false);
  const [dataId, setDataId] = useState("");
  const [approvedData, setApprovedData] = useState("");
  const [blockModal, setBlockModal] = useState(false);
  const [isStatusUser, setStatusUser] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const [vendor_name, setVendorname] = useState("");
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [isApproveConfirm, setIsApproveConfirm] = useState(false);

  const {
    vendorData,
    successMessageVendor,
    errorMessage,
    updateStatusVendor,
    isLoadingVendor,
  } = useSelector((state) => state.vendorManagementReducer);

  const { selectedWalletData, web3Object } = useSelector(
    (state) => state.WalletReducer
  );

  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: "",
    sortBy: "created_at",
    sortOrder: "desc",
    status: "",
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  const dispatch = useDispatch();

  const memoizedParams = useMemo(() => {
    return {
      page: params.page,
      search: params.search,
      status: params.status,
      sortBy: params.sortBy,
      sortOrder: params.sortOrder,
    };
  }, [
    params.page,
    params.search,
    params.status,
    params.sortBy,
    params.sortOrder,
  ]);

  useEffect(() => {
    getVendor();
  }, [memoizedParams]);

  useEffect(() => {
    if (params.search !== "") {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  const totalCount = Number(vendorData?.pagination?.total);
  const totalPages = Math.ceil(
    totalCount / Number(paginationParams?.perPage) || 1
  );

  useEffect(() => {
    if (totalCount) {
      setPaginationParams((prevState) => ({
        ...prevState,
        totalCount,
        totalPages,
      }));
    }
  }, [totalCount]);

  // useEffect(() => {
  //   if (updateStatusVendor === "Approved") {
  //     setIsConfirm(true);
  //   }
  //   if (updateStatusVendor === "Rejected") {
  //     setIsReject(true);
  //   }
  // }, [updateStatusVendor]);

  useEffect(() => {
    if (successMessageVendor) {
      Notifications(successMessageVendor, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageVendor());
  }, [successMessageVendor, errorMessage]);

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  const getVendor = async () => {
    await dispatch(getVendorDetails(params));
  };

  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const handleShowView = (item) => {
    setDataId(item.id);
    setViewModal(true);
    dispatch(getVendorDataById(item.id));
  };

  const handleEdit = (item) => {
    setDataId(item.id);
    dispatch(getVendorDataById(item.id));
    setEditModal(true);
  };

  const handleBlockVendor = (id, status) => {
    setDataId(id);
    setBlockModal(true);
    setStatusUser(status);
  };

  const handleBlock = async () => {
    await dispatch(blockVendorToggleById(dataId));
    await getVendor();
    setBlockModal(false);
  };

  const handleDeleteVendor = (id) => {
    setDataId(id);
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    await dispatch(deleteVendorUserById(dataId));
    await getVendor();
    setDeleteModal(false);
  };
  const handleStatusVendor = (status, id, vendor_name) => {
    setVendorname(vendor_name);
    setApprovedData({ status, id });
    setIsApproveConfirm(true);
    setStatusUser(status);
  };
  const handleStatus = async () => {
    await dispatch(updateStatus(approvedData));
    await getVendor();
    setIsApproveConfirm(false);
  };
  const handleChageStatus = (e) => {
    const status = e.target.value || "";
    setParams({
      ...params,
      status: status,
      page: 1,
    });
  };

  const handleChageSortBy = (e) => {
    const sortBy = e.target.value;
    setParams({
      ...params,
      sortBy: sortBy,
      page: 1,
    });
  };

  const accountChangedHandler = async (newAccount) => {
    if (newAccount.length === 0) {
      await dispatch(disconnectWallet());
    }
  };

  useEffect(() => {
    window.ethereum?.on("accountsChanged", accountChangedHandler);
  }, [window.ethereum]);

  const handleVendorAuthorize = async (walt_address, dataId) => {
    const address_localstorage = JSON.parse(
      localStorage.getItem("wallet_address")
    );
    if (!address_localstorage) {
      Notifications("Please Connect Your Wallet", "error");
    } else {
      await VendorAuthorise({
        address: walt_address,
        walletselect: selectedWalletData || "Metamask",
        web3Object,
      }).then((response) => {
        if (response) {
          const resdata = { response, vendorId: dataId };
          dispatch(PostBlockChainTrackedResponseToBackend(resdata));
          getVendor();
        }
      });
    }
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;

  return (
    <>
      <ConnectWalletModal
        showModal={showWalletModal}
        closeModal={() => setShowWalletModal(false)}
      />
      <Tooltip id="vendor-tooltip" className="tooltip" />
      <ViewModal
        isShow={viewModal}
        setShow={setViewModal}
        getVendor={getVendor}
        viewId={dataId}
      />
      <EditModal
        isShow={editModal}
        setShow={setEditModal}
        getVendor={getVendor}
        editId={dataId}
      />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />

      <ConfirmationModal
        isShow={blockModal}
        setBlockModal={setBlockModal}
        handleConfirm={handleBlock}
        isStatus={isStatusUser}
      />
      {/* <ConfirmRejectPopup
        isShow={isReject}
        setterFunction={setIsReject}
        icon={reject}
        vendor_name={vendor_name}
      />
      <ConfirmPopUp
        isShow={isConfirm}
        setterFunction={setIsConfirm}
        icon={Approved}
        vendor_name={vendor_name}
      /> */}
      <ConfirmationApproveModal
        isShow={isApproveConfirm}
        setIsApproveConfirm={setIsApproveConfirm}
        isStatus={isStatusUser}
        handleStatus={handleStatus}
        vendor_name={vendor_name}
      />

      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Vendor Management</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>

              <div className="tbl-filter-block  filter-area">
                <button
                  className="btn btn-filter"
                  type="button"
                  data-bs-toggle="collapse"
                  role="button"
                  aria-expanded="false"
                  aria-controls="collapseExample"
                  onClick={() => setShowSort(!showSort)}
                >
                  <img src={filterIcon} alt="filter" />
                </button>
              </div>
            </div>
          </div>
          <div
            className={`collapse  ${showSort ? "show" : ""}`}
            id="collapseExample"
          >
            <div className="card card-body filter-block">
              <div className="filter-main">
                <div className="row filter-form">
                  <div className="form-group frm-itm col-md-6">
                    <select
                      className="form-control select"
                      onChange={(e) => handleChageSortBy(e)}
                      value={params.sortBy}
                    >
                      <option value="vendor_name">Vendor</option>
                      <option value="created_at">Created At</option>
                    </select>
                  </div>
                  <div className="form-group frm-itm col-md-6">
                    <select
                      className="form-control select"
                      value={params?.status}
                      onChange={(e) => handleChageStatus(e)}
                    >
                      <option value="">Select</option>
                      <option value="Approved">Approved</option>
                      <option value="Rejected">Rejected</option>
                      <option value="Pending">Pending</option>
                    </select>
                  </div>
                </div>
                <div className="filter-btn">
                  <button
                    className="btn btn-clse"
                    onClick={() => setShowSort(false)}
                  >
                    Close
                  </button>
                  <button
                    className="btn btn-reset"
                    onClick={() =>
                      setParams({
                        ...params,
                        status: "",
                        sortBy: "created_at",
                        sortOrder: "asc",
                      })
                    }
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="table-section custom-scroll custom-scroll-h vendor-table">
            {isLoadingVendor ? (
              <>
                <div
                  className="table-loader"
                  colSpan={vendorTableData?.keys?.length + 3}
                >
                  <img src={Loader} alt="" />
                </div>
              </>
            ) : (
              <>
                <table className="table table-Vendor">
                  <tbody>
                    <tr>
                      <th>
                        {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                        No.
                      </th>

                      <CommonTableHeader tableData={vendorTableData} />
                      <th className="approved text-center">Approve/ Reject</th>
                    </tr>

                    {vendorData && vendorData.rows?.length ? (
                      vendorData?.rows?.map((item, index) => (
                        <tr key={index}>
                          <td>
                            {startSerialNumber + index}
                            {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                          </td>
                          <td onClick={() => handleShowView(item)}>
                            <span className="cursor-pointer">
                              {item?.vendor?.vendor_name || "-"}
                            </span>
                          </td>
                          <td>{item?.email || "-"}</td>
                          <td>
                            {moment(item?.vendor?.created_at).format(
                              "DD MMMM YYYY"
                            ) || "-"}
                          </td>
                          <td className="status-block">
                            <span
                              className={`status-txt ${
                                item?.vendor?.status === "Pending"
                                  ? "pending-txt"
                                  : item?.vendor?.status === "Approved"
                                  ? "approved-txt"
                                  : "rejected-txt"
                              }`}
                            >
                              <img
                                src={
                                  item?.vendor?.status === "Pending"
                                    ? Pending
                                    : item?.vendor?.status === "Approved"
                                    ? Approved
                                    : reject
                                }
                                alt="Approved"
                              />
                              {item?.vendor?.status}
                            </span>
                          </td>
                          <td>
                            <div className="action-icons">
                              <img
                                src={view}
                                className="view-icon"
                                data-tooltip-id="vendor-tooltip"
                                data-tooltip-content="View"
                                alt=""
                                onClick={() => handleShowView(item)}
                              />
                              <img
                                src={edit}
                                className="edit-icon"
                                data-tooltip-id="vendor-tooltip"
                                data-tooltip-content="Edit"
                                alt=""
                                onClick={() => handleEdit(item)}
                              />
                              {item?.vendor?.transactionHash ? (
                                <img
                                  src={greyWalletIcon}
                                  className="wallea-icon cursor-not-allowed"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Vendor Added"
                                  alt=""
                                  // onClick={() => setShowWalletModal(true)}
                                />
                              ) : (
                                <img
                                  src={greenWalletIcon}
                                  className="wallea-icon"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Add Vendor to Blockchain"
                                  alt=""
                                  // onClick={() => setShowWalletModal(true)}
                                  onClick={() =>
                                    handleVendorAuthorize(
                                      item?.vendor?.wallet_address,
                                      item?.vendor?.id
                                    )
                                  }
                                />
                              )}
                              <img
                                src={
                                  item?.vendor?.is_active ? unBlockIcon : block
                                }
                                data-tooltip-id="vendor-tooltip"
                                data-tooltip-content={
                                  item?.vendor?.is_active
                                    ? "Unblocked"
                                    : "Blocked"
                                }
                                className="block-icon"
                                onClick={() =>
                                  handleBlockVendor(
                                    item.id,
                                    item?.vendor?.is_active
                                  )
                                }
                                alt=""
                              />
                              <img
                                src={deleteIcon}
                                data-tooltip-id="vendor-tooltip"
                                data-tooltip-content="Delete"
                                className="delete-icon"
                                alt=""
                                onClick={() =>
                                  handleDeleteVendor(item?.vendor?.id)
                                }
                              />
                            </div>
                          </td>
                          <td>
                            {item?.vendor?.status === "Pending" && (
                              <div className="approved-block">
                                <img
                                  src={Approved}
                                  onClick={() =>
                                    handleStatusVendor(
                                      "Approved",
                                      item.id,
                                      item?.vendor?.vendor_name
                                    )
                                  }
                                  className="approved-icons"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Approve"
                                  alt="approved-icon"
                                />
                                <img
                                  src={reject}
                                  onClick={() =>
                                    handleStatusVendor(
                                      "Rejected",
                                      item.id,
                                      item?.vendor?.vendor_name
                                    )
                                  }
                                  className="reject-icons"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Reject"
                                  alt="reject-icons"
                                />
                              </div>
                            )}
                            {item?.vendor?.status === "Approved" && (
                              <div className="approved-block">
                                <img
                                  src={ApprovedDisable}
                                  className="approved-icons cursor-not-allowed"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Approve"
                                  alt="approved-icon"
                                />
                                <img
                                  src={DisabledReject}
                                  // onClick={() =>
                                  //   handleStatusVendor(
                                  //     "Rejected",
                                  //     item?.id,
                                  //     item?.vendor?.vendor_name
                                  //   )
                                  // }
                                  className="reject-icons cursor-not-allowed"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Reject"
                                  alt="reject-icons"
                                />
                              </div>
                            )}
                            {item?.vendor?.status === "Rejected" && (
                              <div className="approved-block">
                                <img
                                  src={Approved}
                                  onClick={() =>
                                    handleStatusVendor(
                                      "Approved",
                                      item?.id,
                                      item?.vendor?.vendor_name
                                    )
                                  }
                                  className="approved-icons"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Approve"
                                  alt="approved-icon"
                                />
                                <img
                                  src={DisabledReject}
                                  className="reject-icons cursor-not-allowed"
                                  data-tooltip-id="vendor-tooltip"
                                  data-tooltip-content="Reject"
                                  alt="reject-icons"
                                />
                              </div>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          className="text-center no-data-table"
                          colSpan={vendorTableData?.keys?.length + 3}
                        >
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {vendorData?.rows?.length > 0 ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default VendorManagement;
