import { createSlice, createAsyncThunk, createAction } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../config/utils';

export const clearMessageVendor = createAction('clearMessageVendor');
export const getVendorDetails = createAsyncThunk(
  'vendor-management',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('page', data.page);
    params.append('limit', data.limit);
    params.append('name', data.search);
    params.append('status', data.status);
    params.append('sortBy', data.sortBy);
    params.append('sortOrder', data.sortOrder)
    const endPoint = `${serviceEndpoints.vendor_management}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const getVendorDataById = createAsyncThunk(
  'single-vendor-management',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.vendor_management}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const blockVendorToggleById = createAsyncThunk(
  'block-vendor',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.vendor_status}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'put');
  }
);

export const deleteVendorUserById = createAsyncThunk(
  'delete-vendor',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.vendor_management}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'delete');
  }
);

export const PostBlockChainTrackedResponseToBackend = createAsyncThunk(
  'block-chain-tracked-response',
  async ({vendorId, ...data}, { rejectWithValue }) => {
    const body = { ...data };
    const endPoint = `${serviceEndpoints.PostblockChainResponse}/${vendorId}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'post', body.response);
  }
);

export const editVendorDatabyId = createAsyncThunk(
  'single-vendor-management-edit',
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();
    body.profile_image && formData.append('profile_image', body.profile_image);
    formData.append('vendor_name', body.vendor_name);
    formData.append('shop_name', body.shop_name);
    formData.append('phone', body.phone);
    formData.append('email', body.email);
    formData.append('country', body.country);
    formData.append('state', body.state);
    formData.append('city', body.city);
    formData.append('postal_code', body.postal_code);
    formData.append('wallet_address', body.wallet_address);
    formData.append('address', body.address);
    formData.append('commision', body.commision);
    formData.append('platform', 'web');
    const headers = {
      'Content-Type': 'multipart/form-data',
    };

    const endPoint = `${serviceEndpoints.vendor_update}/${editId}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      'put',
      formData,
      headers
    );
  }
);

export const updateStatus = createAsyncThunk(
  'updateStatus',
  async (data, { rejectWithValue }) => {
    const body = { status: data.status };
    const endPoint = `${serviceEndpoints.vendor_management}/${data.id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'put', body);
  }
);

const vendorManagementSlice = createSlice({
  name: 'vandor-management',
  initialState: {
    vendorData: {},
    success: false,
    isLoading: false,
    isLoadingVendor: false,
    errorMessage: '',
    SuccessStatus: false,
    successMessageVendor: '',
    singleVendorData: '',
    updateStatusVendor: '',
    BlockChainTrackedSuccessMessage: '',
  },

  extraReducers: (builder) => {
    builder
      .addCase(getVendorDetails.pending, (state) => {
        state.errorMessage = '';
        state.success = false;
        state.isLoadingVendor = true;
      })

      .addCase(getVendorDetails.fulfilled, (state, { payload }) => {
        state.isLoadingVendor = false;
        state.success = true;
        state.vendorData = payload;
      })
      .addCase(getVendorDetails.rejected, (state, { payload }) => {
        state.isLoadingVendor = false;
        state.isLoading = false;
        state.success = false;
        state.errorMessage = payload.message;
      })
      .addCase(getVendorDataById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
      })
      .addCase(getVendorDataById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.singleVendorData = payload;
      })
      .addCase(getVendorDataById.rejected, (state, { payload }) => {
        state.singleVendorData = {};
        state.isLoading = false;
      })

      .addCase(deleteVendorUserById.pending, (state) => {
        state.isLoadingVendor = true;
        state.errorMessage = '';
        state.successMessageVendor = '';
      })
      .addCase(deleteVendorUserById.fulfilled, (state, { payload }) => {
        state.isLoadingVendor = false;
        state.successMessageVendor = payload.message;
      })
      .addCase(deleteVendorUserById.rejected, (state, { payload }) => {
        state.singleVendorData = {};
        state.isLoadingVendor = false;
        state.errorMessage = payload.message;
      })

      .addCase(editVendorDatabyId.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
        state.successMessageVendor = '';
      })
      .addCase(editVendorDatabyId.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageVendor = payload.message;
      })
      .addCase(editVendorDatabyId.rejected, (state, { payload }) => {
        state.singleVendorData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })

      .addCase(blockVendorToggleById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
        state.successMessageVendor = '';
      })
      .addCase(blockVendorToggleById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageVendor = payload.message;
      })
      .addCase(blockVendorToggleById.rejected, (state, { payload }) => {
        state.singleVendorData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })

      .addCase(updateStatus.pending, (state) => {
        state.isLoadingVendor = true;
        state.errorMessage = '';
        state.successMessageVendor = '';
        state.updateStatusVendor = '';
      })
      .addCase(updateStatus.fulfilled, (state, { payload }) => {
        state.isLoadingVendor = false;
        state.SuccessStatus = true;
        state.updateStatusVendor = payload.status;
        state.successMessageVendor = payload.message;
      })
      .addCase(updateStatus.rejected, (state, { payload }) => {
        state.singleVendorData = {};
        state.isLoadingVendor = false;
        state.SuccessStatus = false;
        state.updateStatusVendor = '';
        state.errorMessage = payload.message;
      })

      .addCase('clearMessageVendor', (state) => {
        state.errorMessage = '';
        state.successMessageVendor = '';
        state.success = false;
        state.updateStatusVendor = '';
      })
      .addCase(PostBlockChainTrackedResponseToBackend.pending, (state) => {
        state.isLoading = true;
        state.BlockChainTrackedSuccessMessage = '';
        state.errorMessage = '';
      })
      .addCase(
        PostBlockChainTrackedResponseToBackend.fulfilled,
        (state, { payload }) => {
          state.isLoading = false;
          state.BlockChainTrackedSuccessMessage = payload?.message;
        }
      )
      .addCase(
        PostBlockChainTrackedResponseToBackend.rejected,
        (state, { payload }) => {
          state.isLoading = false;
          state.errorMessage = payload?.message;
        }
      );
  },
});

export default vendorManagementSlice.reducer;