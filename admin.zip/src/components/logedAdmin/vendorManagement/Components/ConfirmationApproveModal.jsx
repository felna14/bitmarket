import React from 'react';
import { Modal } from 'react-bootstrap';
import '../../../../assets/scss/modal.scss';
import approved from '../../../../assets/img/approved-md.svg';
import blockwhiteicon from '../../../../assets/img/block.svg';

const ConfirmationApproveModal = ({
  isShow,
  setIsApproveConfirm,
  handleStatus,
  isStatus,
}) => {
  return (
    <Modal
      show={isShow}
      className={`${
        !isStatus
          ? 'blocked-modal pass-modal sml-modal'
          : 'modal fade blocked-modal pass-modal   sml-modal'
      }`}
      id="accountApproved"
      data-bs-backdrop="static"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="accountApprovedLabel"
      aria-hidden="true"
      data-backdrop="static"
      centered
    >
      <div className="modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-body">
            <div
              className={`outer-main pop-up-approve ${
                isStatus ? 'pop-up-approve' : ''
              }`}
            >
              <div className="icons">
                <img
                  src={isStatus === 'Approved' ? approved : blockwhiteicon}
                  alt=""
                />
              </div>
              <h3 className="heading">
                Are you sure you want to{' '}
                {isStatus === 'Approved' ? 'Approve' : 'Reject'} ?
              </h3>
              <div className="btn-area">
                <button
                  className="btn btn-cus"
                  data-bs-dismiss="modal"
                  onClick={() => {
                    setIsApproveConfirm(false);
                  }}
                >
                  Cancel
                </button>
                <button
                  className={`btn btn-cus ${
                    isStatus === 'Approved' ? ' btn-green ' : 'btn-delete'
                  }`}
                  onClick={() => handleStatus()}
                >
                  {isStatus === 'Approved' ? 'Approve' : 'Reject'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default ConfirmationApproveModal;
