import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import profilepic from "../../../../assets/img/profileimg.png";
import galleryimport from "../../../../assets/img/gallery-import.svg";
import "react-datepicker/dist/react-datepicker.css";

import { Field, Form, Formik, ErrorMessage } from "formik";
import * as yup from "yup";

import wrngdngr from "../../../../assets/img/warn-dngr.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  clearMessageVendor,
  editVendorDatabyId,
  getVendorDataById,
} from "../vendorManagementSlice";
import { parsePhoneNumberFromString } from "libphonenumber-js";
import { Notifications } from "../../../../config/utils";
import Loader from "../../../../assets/img/Loader.gif";

const EditModal = ({ isShow, setShow, editId, getVendor }) => {
  const [previewUrl, setPreview] = useState("");
  const { singleVendorData, successMessageVendor, errorMessage, isLoading } =
    useSelector((state) => state.vendorManagementReducer);

  const dispatch = useDispatch();
  const initialValues = {
    vendor_name: singleVendorData?.vendor?.vendor?.vendor_name || "",
    commision: singleVendorData?.vendor?.vendor?.commision || "",
    phone: singleVendorData?.vendor?.phone || "",
    email: singleVendorData?.vendor?.email || "",
    country: singleVendorData?.vendor?.vendor?.country || "",
    state: singleVendorData?.vendor?.vendor?.state || "",
    city: singleVendorData?.vendor?.vendor?.city || "",
    postal_code: singleVendorData?.vendor?.vendor?.postal_code || "",
    shop_name: singleVendorData?.vendor?.vendor?.shop_name || "",
    wallet_address: singleVendorData?.vendor?.vendor?.wallet_address || "",
    shop_email: singleVendorData?.vendor?.vendor?.shop_email || "",
    profile_image: "",
    address: singleVendorData?.vendor?.vendor?.address || "",
  };

  useEffect(() => {
    if (successMessageVendor) {
      Notifications(successMessageVendor, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageVendor());
  }, [successMessageVendor, errorMessage]);

  const onSave = async (values) => {
    const data = { ...values, editId: editId };
    await dispatch(editVendorDatabyId(data));
    dispatch(getVendorDataById(editId));
    await getVendor();
    setShow(false);
    setPreview("");
  };
  const handleFileChange = (event, setFieldValue) => {
    const files = event.target.files[0];
    if (files?.size > 10e6) {
      Notifications("Please upload a file smaller than 10 MB", "error");
    } else {
      setFieldValue("profile_image", files);
      setPreview(URL.createObjectURL(files));
    }
  };

  return (
    <>
      <Modal
        show={isShow}
        className="modal fade vedr-edit mid"
        id="vedr-mng-edit"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="vedr-mng-editLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="modal-dialog-centered ">
              <div className="edit-modal-Customer">
                <div className="modal-header">
                  <h5 className="modal-title" id="vedr-mng-editLabel">
                    Edit Vendor
                  </h5>
                </div>
                <Formik
                  initialValues={initialValues}
                  validationSchema={yup.object({
                    email: yup
                      .string()
                      .required("Email ID is Required!")
                      .email("Invalid email address"),
                    vendor_name: yup
                      .string()
                      .test(
                        "no-numbers-special-characters",
                        "Vendor Name Should Only Contain Letters",
                        (value) => {
                          return /^[a-zA-Z\s]+$/.test(value);
                        }
                      )
                      .trim("Vendor Name without spaces")
                      .required("Vendor Name is Required"),
                    commision: yup
                      .number()
                      .required("Commission is Required")
                      .typeError("Commission is Invalid")
                      .positive("Commission should be a positive number"),
                    phone: yup
                      .string()
                      .test("Invalid Phone Number", (value) => {
                        if (!value) {
                          return false;
                        }

                        const phoneNumber = parsePhoneNumberFromString(value);
                        return phoneNumber ? phoneNumber.isValid() : false;
                      })
                      .matches(
                        /^[0-9+]+$/,
                        "Phone Number must contain only numbers"
                      )
                      .required("Phone Number is Required"),
                    shop_name: yup.string().required("Shop Name is Required"),
                    country: yup
                      .string()
                      .trim("Country without spaces")
                      .required("Country is Required"),
                    postal_code: yup
                      .number()
                      .required("Postal Code is Required")
                      .typeError("Postal Code is Invalid")
                      .positive("Postal Code should be a positive number"),
                    wallet_address: yup
                      .string()
                      .trim("Wallet Adddres without Spaces")
                      .max("60", "Wallet Address is Too Long")
                      .required("Wallet Address is Required"),
                    address: yup.string().required("Address is Required"),
                  })}
                  enableReinitialize
                  onSubmit={(values, { resetForm }) => {
                    onSave(values);
                  }}
                >
                  {({ values, setFieldValue, isSubmitting }) => (
                    <Form>
                      <div className="modal-body">
                        <div className="outer-main edit-modal-block">
                          <div className="col-lg-3 profile-img-up">
                            <label className="form-label"> Upload Image</label>
                            <div className="profile-img">
                              <img
                                src={
                                  previewUrl.length
                                    ? previewUrl
                                    : singleVendorData?.vendor?.profile_image ||
                                      profilepic
                                }
                                className="Vendor-pic-block"
                                alt="Preview"
                              />
                              <div className="upload-btn">
                                <Field name="profile_image">
                                  {({ field }) => (
                                    <>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        id="profile_image"
                                        className="file-input__input"
                                        title=""
                                        onChange={(event) =>
                                          handleFileChange(event, setFieldValue)
                                        }
                                      />
                                    </>
                                  )}
                                </Field>
                                <img src={galleryimport} alt="" />
                              </div>
                            </div>
                          </div>

                          <div className="col-lg-9 profile-data-main">
                            <div className=" row profile-data">
                              <div className="col-md-4 form-group frm-itm">
                                <label className="form-label">
                                  Vendor Name
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  name="vendor_name"
                                  type="text"
                                  className="form-control"
                                  placeholder="Vendor Name"
                                />
                                <ErrorMessage
                                  name="vendor_name"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <label className="form-label">
                                  {" "}
                                  Commission %
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  name="commision"
                                  type="text"
                                  className="form-control"
                                  placeholder="Commission %"
                                  maxLength="8"
                                />
                                <ErrorMessage
                                  name="commision"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-4 form-group frm-itm tel">
                                <label className="form-label">
                                  {" "}
                                  Phone number
                                  <span className="text-danger">*</span>
                                </label>
                                <div className="phone-number">
                                  <Field
                                    name="phone"
                                    type="text"
                                    maxlength="14"
                                    minlength="7"
                                    className="form-control"
                                    placeholder="Phone Number"
                                  />
                                </div>
                                <ErrorMessage
                                  name="phone"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <div className="position-relative">
                                  <label className="form-label">
                                    {" "}
                                    Email ID
                                    <span className="text-danger">*</span>
                                  </label>
                                  <Field
                                    name="email"
                                    type="email"
                                    className="form-control cursor-not-allowed"
                                    placeholder="Email ID"
                                    disabled={true}
                                  />
                                  <ErrorMessage
                                    name="email"
                                    render={(msg) => (
                                      <span className="error">
                                        <img src={wrngdngr} alt="" /> {msg}
                                      </span>
                                    )}
                                  />
                                </div>
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <div className="position-relative">
                                  <label className="form-label">
                                    {" "}
                                    Address
                                    <span className="text-danger">*</span>
                                  </label>
                                  <Field
                                    name="address"
                                    className="form-control"
                                    type="text"
                                    maxLength="255"
                                    placeholder="Type Here.."
                                  />
                                  <ErrorMessage
                                    name="address"
                                    render={(msg) => (
                                      <span className="error">
                                        <img src={wrngdngr} alt="" /> {msg}
                                      </span>
                                    )}
                                  />
                                </div>
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <label className="form-label">City</label>
                                <Field
                                  name="city"
                                  type="text"
                                  className="form-control"
                                  placeholder="City"
                                />
                                <ErrorMessage
                                  name="city"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <label className="form-label">State</label>
                                <Field
                                  name="state"
                                  type="text"
                                  className="form-control"
                                  placeholder="State"
                                />
                                <ErrorMessage
                                  name="state"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <label className="form-label">
                                  Country<span className="text-danger">*</span>
                                </label>
                                <Field
                                  name="country"
                                  type="text"
                                  className="form-control"
                                  placeholder="Country"
                                />
                                <ErrorMessage
                                  name="country"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <label className="form-label">
                                  Postal Code
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  name="postal_code"
                                  type="text"
                                  className="form-control"
                                  maxLength="8"
                                  placeholder="Postal Code"
                                />
                                <ErrorMessage
                                  name="postal_code"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-12 head">
                                <h3>Shop Details</h3>
                              </div>

                              <div className="col-md-4 form-group frm-itm">
                                <div className="position-relative">
                                  <label className="form-label">
                                    Shop name
                                    <span className="text-danger">*</span>
                                  </label>
                                  <Field
                                    name="shop_name"
                                    type="text"
                                    className="form-control"
                                    placeholder="Shop Name"
                                  />
                                  <ErrorMessage
                                    name="shop_name"
                                    render={(msg) => (
                                      <span className="error">
                                        <img src={wrngdngr} alt="" /> {msg}
                                      </span>
                                    )}
                                  />
                                </div>
                              </div>

                              <div className="col-md-8 form-group frm-itm">
                                <label className="form-label">
                                  Wallet Address
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  name="wallet_address"
                                  type="text"
                                  className="form-control cursor-not-allowed"
                                  disabled
                                  placeholder="Wallet Address"
                                />
                                <ErrorMessage
                                  name="wallet_address"
                                  render={(msg) => (
                                    <span className="error">
                                      <img src={wrngdngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="modal-footer">
                        <div className="btn-area">
                          <button
                            type="button"
                            className="btn btn-cus btn-cancel"
                            onClick={() => {
                              setShow(false);
                              setPreview("");
                            }}
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            disabled={isSubmitting}
                            className="btn btn-cus btn-save"
                          >
                            {isSubmitting ? (
                              <span
                                className="spinner-border spinner-border-sm"
                                role="status"
                                aria-hidden="true"
                              ></span>
                            ) : (
                              "Save"
                            )}
                          </button>
                        </div>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </div>
          </>
        )}
      </Modal>
    </>
  );
};

export default EditModal;
