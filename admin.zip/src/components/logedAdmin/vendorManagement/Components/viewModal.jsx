import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import profilepic from "../../../../assets/img/profileimg.png";
import pendingclockicon from "../../../../assets/img/pending-clock-icon.svg";
import deleteicon from "../../../../assets/img/delete-icon.svg";
import editpenicon from "../../../../assets/img/edit-pen-icon.svg";
import blocksvg from "../../../../assets/img/block.svg";
import EditModal from "./EditModal";
import DeleteModal from "../../../common/deletemodal";
import { useDispatch, useSelector } from "react-redux";
import Approved from "../../../../assets/img/approved-icon.svg";
import ApprovedIcon from "../../../../assets/img/approveIcon.svg";
import reject from "../../../../assets/img/reject-icons.svg";
import rejectwhite from "../../../../assets/img/Path.svg";
import { Notifications } from "../../../../config/utils";
import {
  clearMessageVendor,
  deleteVendorUserById,
  updateStatus,
} from "../vendorManagementSlice";
import moment from "moment";
import { vendorTableData } from "../../../../config/TableData";
import Loader from "../../../../assets/img/Loader.gif";

const ViewModal = ({ isShow, setShow, getVendor, viewId }) => {
  const [editModal, setEditModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const dispatch = useDispatch();
  const { singleVendorData, succesMessageCustomer, errorMessage, isLoading } =
    useSelector((state) => state.vendorManagementReducer);

  useEffect(() => {
    if (succesMessageCustomer) {
      Notifications(succesMessageCustomer, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageVendor());
  }, [succesMessageCustomer, errorMessage]);

  const handleEdit = () => {
    setEditModal(true);
  };
  const handleShowDelete = async () => {
    setDeleteModal(true);
  };
  const handleDelete = async () => {
    await dispatch(deleteVendorUserById(viewId));
    await getVendor();
    setDeleteModal(false);
    setShow(false);
  };

  const handleStatus = async (status) => {
    await dispatch(updateStatus({ id: viewId, status }));
    await getVendor();
    setShow(false);
  };

  const status = singleVendorData?.vendor?.vendor?.status;

  return (
    <>
      <EditModal
        isShow={editModal}
        setShow={setEditModal}
        editId={viewId}
        getVendor={getVendor}
      />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <Modal
        show={isShow}
        className="modal fade vedr-man mid"
        id="vedr-mng-view"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="vedr-mng-viewLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="">
              <div className="">
                <div className="modal-header">
                  <h5 className="modal-title" id="vedr-mng-viewLabel">
                    View Vendor Details
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => {
                      setShow(false);
                    }}
                  ></button>
                </div>

                <div className="modal-body">
                  <div className="outer-main row ">
                    <div className="col-lg-3 profile-img-view">
                      <div className="profile-img">
                        <img
                          src={
                            singleVendorData?.vendor?.profile_image ||
                            profilepic
                          }
                          alt=""
                        />
                      </div>
                      <div className="profile-info">
                        <span className="profile-lab">Joining Date</span>
                        <h3 className="date">
                          {moment(
                            singleVendorData?.vendor?.vendor?.created_at
                          ).format("DD MMMM YYYY") || ""}
                        </h3>

                        <div className="profile-lab">Status</div>
                        <span
                          className={`status orng ${
                            status === "Pending"
                              ? "pending-txt"
                              : status === "Approved"
                              ? "approved-txt"
                              : "rejected-txt"
                          }`}
                        >
                          <span className="icon">
                            <img
                              src={
                                status === "Pending"
                                  ? pendingclockicon
                                  : status === "Approved"
                                  ? Approved
                                  : reject
                              }
                              alt=""
                            />{" "}
                          </span>
                          <span className="txt">{status}</span>
                        </span>
                      </div>
                    </div>

                    <div className="col-lg-9 profile-data-main">
                      <div className=" row profile-data border-bot">
                        <div className="col-md-4 form-group frm-itm">
                          <label className="form-label"> Vendor Name</label>
                          <h3 className="frm-value">
                            {singleVendorData?.vendor?.vendor?.vendor_name ||
                              ""}
                          </h3>
                        </div>
                        <div className="col-md-4 form-group frm-itm">
                          <label className="form-label"> Email ID</label>
                          <h3 className="frm-value">
                            {singleVendorData?.vendor?.email || ""}
                          </h3>
                        </div>
                        <div className="col-md-4 form-group frm-itm">
                          <label className="form-label"> Commission %</label>
                          <h3 className="frm-value">
                            {" "}
                            {singleVendorData?.vendor?.vendor?.commision
                              ? singleVendorData?.vendor?.vendor?.commision +
                                "%"
                              : "-" || ""}
                          </h3>
                        </div>
                        <div className="col-md-8 form-group frm-itm">
                          <label className="form-label"> Address</label>
                          <h3 className="frm-value">
                            {singleVendorData?.vendor?.vendor?.address
                              ? singleVendorData?.vendor?.vendor?.address + ", "
                              : "" || ""}{" "}
                            {singleVendorData?.vendor?.vendor?.city
                              ? singleVendorData?.vendor?.vendor?.city + ", "
                              : "" || ""}{" "}
                            {singleVendorData?.vendor?.vendor?.state
                              ? singleVendorData?.vendor?.vendor?.state + "-"
                              : "" || ""}{" "}
                            {singleVendorData?.vendor?.vendor?.postal_code
                              ? singleVendorData?.vendor?.vendor?.postal_code +
                                ", "
                              : "" || ""}{" "}
                            {singleVendorData?.vendor?.vendor?.country || ""}
                          </h3>
                        </div>
                        <div className="col-md-4 form-group frm-itm ">
                          <label className="form-label"> Phone number</label>
                          <h3 className="frm-value">
                            {singleVendorData?.vendor?.phone || ""}
                          </h3>
                        </div>
                      </div>

                      <div className=" row profile-data">
                        <div className="col-md-12 head p-0">
                          <h3>Shop Details</h3>
                        </div>
                        <div className="col-md-4 form-group frm-itm">
                          <label className="form-label">Shop Name</label>
                          <h3 className="frm-value">
                            {singleVendorData?.vendor?.vendor?.shop_name || ""}
                          </h3>
                        </div>
                        <div className="col-md-4 form-group frm-itm">
                          <label className="form-label"> Wallet Address</label>
                          <h3 className="frm-value">
                            {singleVendorData?.vendor?.vendor?.wallet_address ||
                              "-"}
                          </h3>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <div className="btn-area">
                    <button
                      type="button"
                      className="btn btn-cus"
                      onClick={() => handleShowDelete()}
                    >
                      <img src={deleteicon} alt="" /> Delete
                    </button>
                    <button
                      type="button"
                      className="btn btn-cus edit-Button"
                      onClick={() => {
                        handleEdit();
                      }}
                    >
                      <img src={editpenicon} alt="" /> Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleStatus("Rejected");
                      }}
                      disabled={status === "Rejected"}
                      className={`btn btn-cus btn-red ${
                        status === "Rejected" ? "cursor-not-allowed" : ""
                      }`}
                    >
                      <img src={rejectwhite} alt="" /> Reject
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleStatus("Approved");
                      }}
                      className={`btn btn-cus btn-green ${
                        status === "Approved" ? "cursor-not-allowed" : ""
                      }`}
                      disabled={status === "Approved"}
                    >
                      <img src={ApprovedIcon} alt="" /> Approve
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </Modal>
    </>
  );
};

export default ViewModal;
