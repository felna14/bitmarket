import React, { useEffect, useState } from "react";

import "../../../assets/scss/dashboard.scss";
import "../../../assets/scss/customer-management.scss";
import "../../../assets/scss/table.scss";
import "../../../assets/scss/form.scss";
import "../../../assets/scss/modal.scss";
import "../../../assets/css/bootstrap.css";
import "../../../assets/scss/common.scss";
import "../../../assets/scss/side-nav.scss";
import "../../../assets/scss/filter.scss";
import searchIcon from "../../../assets/img/search-icon.svg";
import Loader from "../../../assets/img/Loader.gif";
import excel from "../../../assets/img/export-excel.svg";

import fourdot from "../../../assets/img/four-square.svg";
import viewicon from "../../../assets/img/view-icon.svg";
import nodataicon from "../../../assets/img/no_data.svg";
import filtericon from "../../../assets/img/filter-filled.svg";
import DeleteModal from "../../common/deletemodal";
import ViewModal from "./Components/ViewModal";
import CustomPagination from "../../common/CustomPagination";
import { useDispatch, useSelector } from "react-redux";
import {
  clearMessagePayment,
  getExcelDataForPayment,
  getPayment,
  getPaymentDataById,
  getPaymentListVendors,
} from "./paymentSlice";
import { formatMoney, formatWithCommas, Notifications } from "../../../config/utils";
import moment from "moment";
import { CommonTableHeader } from "../../common/CommonTableHeader";
import { paymentTableData } from "../../../config/TableData";
import { Tooltip } from "react-tooltip";
import ReactSelect from "react-select";
import CopyToClipboard from "react-copy-to-clipboard";

const Payment = () => {
  const [viewModal, setViewModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [showSort, setShowSort] = useState(false);
    const [copy, setCopy] = useState(false);
  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: "",
    sort_By: "created_at",
    order_status: "",
    sortOrder: "desc",
    start_date: "",
    end_date: "",
    vendor_name: "",
    filter: "",
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  const [filter, setFilter] = useState("");
  const dispatch = useDispatch();
  const {
    isLoadingPayment,
    allPayment,
    errorMessage,
    successMessagePayment,
    excelData,
    vendorListData,
  } = useSelector((state) => state.paymentReducer) || [];

  const options =
    vendorListData?.vendors?.map((vendorName) => ({
      label: vendorName,
      value: vendorName,
    })) || [];

  useEffect(() => {
    getAllProducts();
  }, [
    params.page,
    params.search,
    params.sortby,
    params.sortOrder,
    params.start_date,
    params.end_date,
    params.vendor_name,
    params.filter,
  ]);

  useEffect(() => {
    dispatch(getPaymentListVendors());
  }, []);

  useEffect(() => {
    if (params.search !== "") {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  useEffect(() => {
    const { count } = allPayment?.payments || {};
    if (count) {
      setPaginationParams((prevPaginationParams) => ({
        ...prevPaginationParams,
        totalCount: Number(count),
        totalPages: Math.ceil(
          Number(count) / Number(paginationParams?.perPage) || 1
        ),
      }));
    }
  }, [allPayment?.payments?.count]);
  useEffect(() => {
    if (successMessagePayment) {
      Notifications(successMessagePayment, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessagePayment());
  }, [successMessagePayment, errorMessage]);

  const getAllProducts = async () => {
    await dispatch(getPayment(params));
  };

  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  useEffect(() => {
    if (filter.length) {
      const data = {filter:filter,search:params.search}
      dispatch(getExcelDataForPayment(data));
    }
  }, [filter,params.search]);

  const handleDownloadExcel = () => {
    if (excelData?.filename?.url) {
      const fileName = excelData?.filename?.url.split("/").pop();
      const link = document.createElement("a");
      link.href = `https://devapi-bitmarket.spericorn.com${excelData?.filename?.url}`;
      link.setAttribute("download", `${fileName}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
  };

  const handleChageFilter = (e) => {
    setFilter(e.target.value);
  };

  const handleSelectVendor = (selectedOption) => {
    setParams({
      ...params,
      vendor_name: selectedOption.value,
      page: 1,
    });
  };

  const handleFilter = (e) => {
    const filter = e.target.value || "";
    setParams({
      ...params,
      filter: filter,
      page: 1,
    });
    setFilter(e.target.value);
  };

  const handleShowView = (id) => {
    setViewModal(true);
    dispatch(getPaymentDataById(id));
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;
  const handleCopy = (text) => {
    setCopy(text);
    setTimeout(() => {
      setCopy(false);
    }, 500);
  };
  return (
    <>
      <Tooltip id="payment-tooltips" className="tooltip" />
      <ViewModal isShow={viewModal} setShow={setViewModal} />
      <DeleteModal isShow={deleteModal} setDeleteModal={setDeleteModal} />
      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Payment</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
              <div class="tbl-filter-block  filter-area">
                <button
                  class="btn btn-filter"
                  type="button"
                  onClick={() => setShowSort(!showSort)}
                >
                  <img src={filtericon} alt="filter" />
                </button>
              </div>
              <select
                className="form-select export-select"
                aria-label="Default select example"
                value={filter}
                onChange={(e) => handleFilter(e)}
              >
                <option value="" selected>
                  Select
                </option>
                <option value="today">Today</option>
                <option value="this_week">This Week</option>
                <option value="last_week">Last Week</option>
                <option value="this_month">This Month</option>
                <option value="last_month">last Month</option>
                <option value="last_six_months">Last Six Months</option>
                <option value="this_year">This Year</option>
              </select>
              <div className="tbl-add-btn">
                <button
                  className="btn"
                  data-bs-toggle="modal"
                  data-bs-target="#sub-category-management"
                  onClick={() => handleDownloadExcel()}
                >
                  <img src={excel} alt="excel" />
                  <span>Export to Excel</span>
                </button>
              </div>
            </div>
          </div>
          <div className={`collapse ${showSort ? "show" : ""}`}>
            <div className="card card-body filter-block">
              <div className="filter-main">
                <div className="row filter-form">
                  <div className="form-group frm-itm col-md-4">
                    <label className="form-label">Vendor Name</label>
                    <ReactSelect
                      defaultValue={params.vendor_name}
                      onChange={handleSelectVendor}
                      options={options}
                    />
                  </div>
                  <div className="form-group frm-itm col-md-4">
                    <label className="form-label">Start Date</label>
                    <input
                      id="datepicker"
                      placeholder=""
                      autocomplete="off"
                      className="form-control date-input hasDatepicker"
                      type="date"
                      value={params.start_date}
                      onChange={(e) =>
                        setParams({ ...params, start_date: e.target.value })
                      }
                    />
                  </div>
                  <div className="form-group frm-itm col-md-4">
                    <label className="form-label">End Date</label>
                    <input
                      id="datepicker"
                      placeholder=""
                      autocomplete="off"
                      className="form-control date-input hasDatepicker"
                      type="date"
                      value={params.end_date}
                      min={params.start_date}
                      onChange={(e) =>
                        setParams({ ...params, end_date: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div className="filter-btn filterButton">
                  <button
                    className="btn btn-clse"
                    onClick={() => setShowSort(false)}
                  >
                    Close
                  </button>
                  <button
                    className="btn btn-reset"
                    onClick={() =>
                      setParams({
                        ...params,
                        vendor_name: "",
                        start_date: "",
                        end_date: "",
                      })
                    }
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="table-section custom-scroll custom-scroll-h sub-category-tbl payment-table">
            {isLoadingPayment ? (
              <>
                <div
                  className="table-loader"
                  colSpan={paymentTableData?.keys?.length + 3}
                >
                  <img src={Loader} alt="" />
                </div>
              </>
            ) : (
              <>
                <table className="table payment-block">
                  <tbody>
                    <tr>
                      <th>
                        {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                        No.
                      </th>
                      {/* <CommonTableHeader tableData={paymentTableData} /> */}
                      <th>Date</th>
                      <th>Vendor</th>
                      <th>Total Amount</th>
                      {/* <th className="text-center">Commission</th> */}
                      <th>Order ID</th>
                      <th>Action</th>
                    </tr>
                    {allPayment?.payments?.rows.length ? (
                      allPayment?.payments?.rows?.map((item, index) => (
                        <tr key={index}>
                          <td>
                            {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                            {startSerialNumber + index}
                          </td>
                          <td>
                            {moment(item.payment_date).format("DD MMMM YYYY")}
                          </td>
                          <td>
                            {[
                              ...new Set(
                                item?.order?.order_summaries?.map(
                                  ({ vendor }) => vendor.vendor_name
                                )
                              ),
                            ].join(", ") || "-"}
                          </td>
                          <td>
                            {formatMoney(item?.total_amount)}
                          </td>
                          {/* <td>{"$" + item?.commission}</td> */}
                          <CopyToClipboard
                            text={item?.order?.id}
                            onCopy={handleCopy}
                          >
                          <td
                            data-tooltip-id="payment-tooltips"
                            data-tooltip-content={
                              copy ? "Copied!" : item?.order?.id
                            }
                            className="payment-order cursor-copy"
                          >
                            {item?.order?.id}
                          </td>
                          </CopyToClipboard>

                          <td>
                            <div className="action-icons">
                              <img
                                src={viewicon}
                                alt="view-icon"
                                onClick={() => handleShowView(item?.id)}
                              />
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          className="text-center no-data-table"
                          colSpan={paymentTableData?.keys?.length + 3}
                        >
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            <CustomPagination
              currentPage={params?.page}
              totalPages={paginationParams?.totalPages}
              onPageChange={handlePageClick}
            />
          </div>
        </div>
      </main>
    </>
  );
};

export default Payment;
