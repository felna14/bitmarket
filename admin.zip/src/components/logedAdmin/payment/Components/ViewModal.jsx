import moment from "moment";
import React from "react";
import { Modal } from "react-bootstrap";
import { useSelector } from "react-redux";
import Loader from "../../../../assets/img/Loader.gif";
import { formatMoney } from "../../../../config/utils";

const ViewModal = ({ isShow, setShow }) => {
  const {
    singlePayment: { payment },
    isLoading,
  } = useSelector((state) => state.paymentReducer) || [];

  return (
    <>
      <Modal
        show={isShow}
        className="modal fade payment-view mid"
        id="PaymentView"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="OrderViewLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="modal-header">
              <h5 className="modal-title" id="OrderViewLabel">
                View Payment
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={() => setShow(false)}
              ></button>
            </div>

            <div className="modal-body custom-scroll">
              <div className="outer-main modalWidth">
                <div className=" row payment-value">
                  <div className="col-md-3 frm-itm">
                    <label className="form-label">Payment Date</label>
                    <h3 className="frm-value">
                      {moment(payment?.payment_date).format("DD MMMM YYYY")}
                    </h3>
                  </div>
                  <div className="col-md-3 frm-itm light-red">
                    <label className="form-label">Vendor</label>
                    <h3 className="frm-value">
                      {[
                        ...new Set(
                          payment?.order?.order_summaries?.map(
                            ({ vendor }) => vendor.vendor_name
                          )
                        ),
                      ].join(",") || "-"}
                    </h3>
                  </div>
                  {/* <div className="col-md-3 frm-itm">
                    <label className="form-label">Total Amount</label>
                    <h3 className="frm-value">
                      {"$" + Number(payment?.total_amount)?.toLocaleString()}
                    </h3>
                  </div> */}
                  <div className="col-md-3 frm-itm">
                    <label className="form-label">Commission Received</label>
                    <h3 className="frm-value">{formatMoney(payment?.commission)}</h3>
                  </div>
                  <div className="col-md-3 frm-itm light-red">
                    <label className="form-label">Order ID</label>
                    <h3 className="frm-value">{payment?.order?.id}</h3>
                  </div>
                  <div className="col-md-3 frm-itm">
                    <label className="form-label">Customer</label>
                    <h3 className="frm-value">
                      {payment?.order?.customer?.first_name || ""}
                      {payment?.order?.customer?.last_name || ""}
                    </h3>
                  </div>
                  <div className="col-md-3 frm-itm light-red">
                    <label className="form-label">Payment ID</label>
                    <h3 className="frm-value">{payment?.id}</h3>
                  </div>
                  <div className="col-md-3 frm-itm light-red">
                    <label className="form-label">Payment Status</label>
                    <h3 className="frm-value">{payment?.status}</h3>
                  </div>
                  <div className="col-md-3 frm-itm light-red">
                    <label className="form-label">Amount in Crypto</label>
                    <h3 className="frm-value">
                      {payment?.pay_currency}&nbsp;
                      {Number(payment?.pay_amount).toFixed(6) || "-"}
                    </h3>
                  </div>
                  <div className="col-md-3 frm-itm light-red">
                    <label className="form-label">Amount in Dollar</label>
                    <h3 className="frm-value">
                      {/* {"$" + Number(payment?.price_amount).toFixed(2) || "-"} */}
                      {formatMoney(payment?.total_amount)}
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
        {/* </div>
        </div> */}
      </Modal>
    </>
  );
};

export default ViewModal;
