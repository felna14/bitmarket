import { createAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../config/utils';

export const clearMessagePayment = createAction('clearMessagePayment');

export const getPayment = createAsyncThunk(
  'payment-management',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('page', data.page);
    params.append('limit', data.limit);
    params.append('search', data.search);
    
    if (data.vendor_name?.length) {
      params.append('vendor_name', data.vendor_name);
    }
    
    if (data.start_date?.length) {
      params.append('from', data.start_date);
    }
    
    if (data.end_date?.length) {
      params.append('end', data.end_date);
    }
    
    if (data.filter) {
      params.append('filter', data.filter);
    }
    
    const endPoint = `${serviceEndpoints.payment}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const getPaymentDataById = createAsyncThunk(
  'single-payment-management',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.payment}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const getExcelDataForPayment = createAsyncThunk(
  'export-excel-management-payment',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('filter', data.filter);
    params.append('type', 'payments');
    if (data.search) {
      params.append("search", data.search);
    }
    
    const endPoint = `${serviceEndpoints.excel}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const getPaymentListVendors = createAsyncThunk(
  'payment-list-vendors',
  async (data, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.payment}/list_vendors`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

const PaymentSlice = createSlice({
  name: 'payment-management',
  initialState: {
    allPayment: '',
    singleProductData: '',
    excelData: {},
    isLoading: false,
    successMessagePayment: '',
    errorMessage: '',
    success: false,
    singlePayment: '',
    vendorListData: '',
  },
  extraReducers: (builder) => {
    builder
      .addCase(getPayment.pending, (state) => {
        state.isLoadingPayment = true;
        state.errorMessage = '';
        state.successMessage = '';
        state.successMessagePayment = false;
        state.entityParams = '';
      })
      .addCase(getPayment.fulfilled, (state, { payload }) => {
        state.isLoadingPayment = false;
        state.allPayment = payload;
      })
      .addCase(getPayment.rejected, (state, { payload }) => {
        state.allPayment = '';
        state.isLoadingPayment = false;
        state.errorMessage = payload.message;
      })

      .addCase(getPaymentDataById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
        state.successMessagePayment = false;
        state.entityParams = '';
        state.singlePayment = '';
      })
      .addCase(getPaymentDataById.fulfilled, (state, { payload }) => {
        state.singlePayment = payload;
        state.isLoading = false;
      })
      .addCase(getPaymentDataById.rejected, (state, { payload }) => {
        state.singlePayment = '';
        state.errorMessage = payload.message;
        state.isLoading = false;
      })

      .addCase(getExcelDataForPayment.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
      })
      .addCase(getExcelDataForPayment.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.excelData = payload;
      })
      .addCase(getExcelDataForPayment.rejected, (state, { payload }) => {
        state.excelData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(getPaymentListVendors.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
      })
      .addCase(getPaymentListVendors.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.vendorListData = payload;
      })
      .addCase(getPaymentListVendors.rejected, (state, { payload }) => {
        state.vendorListData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase('clearMessagePayment', (state) => {
        state.errorMessage = '';
        state.successMessagePayment = '';
        state.success = false;
      });
  },
});

export default PaymentSlice.reducer;
