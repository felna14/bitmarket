import React from "react";
import { Modal } from "react-bootstrap";
import { useSelector } from "react-redux";
import moment from "moment";
import Approved from "../../../assets/img/approved-icon.svg";
import emptyCart from "../../../assets/img/empty-cart.svg";
import Loader from "../../../assets/img/Loader.gif";
import { formatMoney } from "../../../config/utils";

const ViewModal = ({ isShow, setShow }) => {
  const { singleOrderData, isLoading } = useSelector(
    (state) => state.orderReducer
  );

  const variant = singleOrderData?.order?.variant;
  const product = singleOrderData?.order?.product;
  const quantity = singleOrderData?.order?.quantity;

  const discountPrice = variant?.discount_price ?? product?.discount_price;
  const totalPrice = (Number(discountPrice) || 0) * (Number(quantity) || 0);

  const handleModalEnter = () => {
    const modalEl = document.getElementById("OrderView");
    if (modalEl) {
      modalEl.classList.add("modal-dialog-scrollable");
    }
  };

  return (
    <Modal
      show={isShow}
      className="modal fade oder-view mid order-info-modal"
      id="OrderView"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="OrderViewLabel"
      aria-hidden="true"
      onEnter={handleModalEnter}
      centered
    >
      {isLoading ? (
        <>
          <div className="loaderWrapper loader-wrapper-height ">
            <div className="table-loader">
              <img src={Loader} alt="" />
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="modal-header">
            <h5 className="modal-title" id="OrderViewLabel">
              View Order
            </h5>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={() => setShow(false)}
            ></button>
          </div>

          <div className="modal-body custom-scroll">
            <div className="orderInfo-body">
              <div className="orderInfo-title">
                <b>
                  {/* <img
                      src={iconTruck}
                      className="truck-icons"
                      alt=""
                    /> */}
                  Delivering To :
                </b>
                <span>
                  {singleOrderData?.order?.order?.address?.line1
                    ? singleOrderData?.order?.order?.address?.line1 + ", "
                    : ""}
                  {singleOrderData?.order?.order?.address?.city
                    ? singleOrderData?.order?.order?.address?.city + ", "
                    : ""}
                  {singleOrderData?.order?.order?.address?.state
                    ? singleOrderData?.order?.order?.address?.state + " -"
                    : ""}
                  {singleOrderData?.order?.order?.address?.postal_code
                    ? singleOrderData?.order?.order?.address?.postal_code + ", "
                    : ""}
                  {singleOrderData?.order?.order?.address?.country
                    ? singleOrderData?.order?.order?.address?.country
                    : "-"}
                </span>
              </div>
              <div className="orderInfo-datile-block">
                <div className="row">
                  <div className="col-lg-3 col-md-3 col-sm-4">
                    <div className="orderInfo-datile-slider">
                      <div className="detail-img-slider">
                        <div className="slide">
                          <img
                            src={
                              singleOrderData?.order?.variants
                                ? singleOrderData?.order?.variants?.product
                                    ?.product_images[0].product_image
                                : singleOrderData?.order?.product
                                    ?.product_images[0].product_image
                            }
                            className="products-img"
                            alt=""
                          />
                        </div>
                      </div>
                      <div className="sellerInfo-block">
                        <h4>Seller Info </h4>
                        <div className="sellerInfo-details-txt">
                          <img
                            src={emptyCart}
                            className="sellerInfo-img"
                            alt=""
                          />
                          <div className="txt">
                            <h6>
                              {" "}
                              {singleOrderData?.order?.vendor?.vendor_name ||
                                "-"}
                            </h6>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-6 col-md-5 col-sm-8">
                    <div className="orderInfo-datile-title">
                      <h5 className="title">
                        {singleOrderData?.order?.product?.product_name} &nbsp;
                        {singleOrderData?.order?.variant?.variant_name
                          ? `(${singleOrderData?.order?.variant?.variant_name})`
                          : ""}
                      </h5>
                      <span>
                        {singleOrderData?.order?.product?.description}
                      </span>
                    </div>
                    <div className="orderInfo-user-details">
                      <div className="list-block">
                        <p>
                          Order ID
                          <span>{singleOrderData?.order?.order_id}</span>
                        </p>
                      </div>
                      <div className="list-block">
                        <p>
                          Order Date
                          <span>
                            {moment(singleOrderData?.order?.created_at).format(
                              "DD MMMM YYYY"
                            )}
                          </span>
                        </p>
                      </div>
                      <div className="list-block">
                        <p>
                          Brand
                          <span>
                            {singleOrderData?.order?.product?.brand?.brand_name}
                          </span>
                        </p>
                      </div>
                      {singleOrderData?.variant_category_name?.variant_name && (
                        <div className="list-block">
                          <p>
                            Variant{" "}
                            <span>
                              {
                                singleOrderData?.order?.variant_category_name
                                  ?.variant_name
                              }
                            </span>
                          </p>
                        </div>
                      )}
                      <div className="list-block">
                        <p>
                          Quantity{" "}
                          <span>{singleOrderData?.order?.quantity}</span>
                        </p>
                      </div>
                      <div className="list-block">
                        <p>
                          Order Status{" "}
                          <span className="payment-status-block">
                            {singleOrderData?.order?.order_status}
                          </span>
                        </p>
                      </div>
                      <div className="list-block">
                        <p>
                          Payment Status{" "}
                          <span className="payment-status-block">
                            {singleOrderData?.order?.order?.payment?.status}
                          </span>
                        </p>
                      </div>
                    {/* </div>
                    <div className="orderInfo-user-details orderInfo-user-details-add"> */}
                      <div className="list-block">
                        <p>
                          Amount in Crypto
                          <span>
                            {
                              singleOrderData?.order?.order?.payment
                                ?.pay_currency
                            }
                            &nbsp;
                            {Number(
                              singleOrderData?.order?.order?.payment?.pay_amount
                            ).toFixed(6) || "-"}
                          </span>
                        </p>
                      </div>
                      <div className="list-block">
                        <p>
                          Amount in Dollar
                          <span>
                            {formatMoney(singleOrderData?.order?.grand_total) ||
                              "-"}
                          </span>
                        </p>
                      </div>
                      <div className="list-block">
                        <p>
                          Transaction ID
                          <span>
                            {
                              singleOrderData?.order?.order?.payment
                                ?.transaction_id
                            }
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-4 col-sm-12">
                    <div className="price-details-block">
                      <div className="price-details-header">
                        <h5>Price Details</h5>
                      </div>
                      <div className="price-details-body">
                        <ul>
                          <li>
                            Product Price{" "}
                            <span>
                              {formatMoney(
                                Number(singleOrderData?.order?.price) *
                                  singleOrderData?.order?.quantity
                              )}
                            </span>
                          </li>
                          <li>
                            Commission fee{" "}
                            <span>
                              {formatMoney(singleOrderData?.order?.commision)}
                            </span>
                          </li>
                          <li>
                            Discount{" "}
                            <span className="success-txt">
                              {formatMoney(totalPrice)}
                            </span>
                          </li>
                          <li>
                            Delivery Charges{" "}
                            <span className="success-txt">
                              {singleOrderData?.order?.shipping_charge !== "0"
                                ? `${formatMoney(
                                    singleOrderData?.order?.shipping_charge
                                  )}`
                                : "Free"}
                            </span>
                          </li>
                        </ul>
                      </div>
                      <div className="price-details-footer">
                        <ul>
                          <li>
                            Total Amount{" "}
                            <span>
                              <img
                                src="img/ethereum-sm.svg"
                                class="img-block"
                                alt=""
                              />{" "}
                              {formatMoney(singleOrderData?.order?.grand_total)}
                            </span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                {/* </div> */}
              </div>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
};

export default ViewModal;
