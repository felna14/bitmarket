import React, { useEffect, useState } from "react";

import searchIcon from "../../../assets/img/search-icon.svg";
import viewicon from "../../../assets/img/view-icon.svg";
import filtericon from "../../../assets/img/filter-filled.svg";
import excel from "../../../assets/img/export-excel.svg";
import ViewModal from "./ViewModal";
import { CommonTableHeader } from "../../common/CommonTableHeader";
import Loader from "../../../assets/img/Loader.gif";
import nodataicon from "../../../assets/img/no_data.svg";
import Approved from "../../../assets/img/approved-icon.svg";
import reject from "../../../assets/img/reject-icons.svg";

import CustomPagination from "../../common/CustomPagination";
import { CopyToClipboard } from "react-copy-to-clipboard";

import "../../../assets/scss/header.scss";
import "../../../assets/scss/dashboard.scss";
import "../../../assets/scss/customer-management.scss";
import "../../../assets/scss/table.scss";
import "../../../assets/scss/form.scss";
import "../../../assets/scss/modal.scss";
import "../../../assets/css/bootstrap.css";
import "../../../assets/scss/common.scss";
import "../../../assets/scss/side-nav.scss";
import "../../../assets/scss/filter.scss";

import { useDispatch, useSelector } from "react-redux";
import { formatMoney, Notifications } from "../../../config/utils";
import {
  getOrder,
  getOrderById,
  getExcelData,
  clearMessageOrder,
} from "./orderSlice";
import { orderTableData } from "../../../config/TableData";
import { Tooltip } from "react-tooltip";
import moment from "moment";

const Order = () => {
  const [viewModal, setViewModal] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const [filter, setFilter] = useState("today");
  const [copy, setCopy] = useState(false);

  const dispatch = useDispatch();

  const [dataId, setDataId] = useState("");

  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: "",
    sort_By: "created_at",
    order_status: "",
    sortOrder: "desc",
    created_at: "",
    filter: "",
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  useEffect(() => {
    getAllOrders();
  }, [
    params.page,
    params.search,
    params.sort_By,
    params.order_status,
    params.sortOrder,
    params.created_at,
    params.filter,
  ]);

  useEffect(() => {
    if (params.search !== "") {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  const {
    isLoadingOrders,
    allOrders,
    errorMessage,
    successMessageOrder,
    excelData,
  } = useSelector((state) => state.orderReducer) || [];

  useEffect(() => {
    if (allOrders?.orders?.count) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(allOrders?.orders?.count),
        totalPages: Math.ceil(
          Number(allOrders?.orders?.count) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [allOrders?.orders?.count]);
  useEffect(() => {
    if (successMessageOrder) {
      Notifications(successMessageOrder, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageOrder());
  }, [successMessageOrder, errorMessage]);

  useEffect(() => {
    if (filter.length) {
      const data = {filter:filter,search:params.search}
      dispatch(getExcelData(data));
    }
  }, [filter,params.search]);

  const handleDownloadExcel = () => {
    if (excelData?.filename?.url) {
      const fileName = excelData?.filename?.url.split("/").pop();
      const link = document.createElement("a");
      link.href = `https://devapi-bitmarket.spericorn.com${excelData?.filename?.url}`;
      link.setAttribute("download", `${fileName}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
  };

  const getAllOrders = async () => {
    await dispatch(getOrder(params));
  };

  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  const handleShowView = (item) => {
    setViewModal(true);
    setDataId(item.id);
    dispatch(getOrderById(item.id));
  };

  const handleChageSort_By = (e) => {
    const sort_By = e.target.value;
    setParams({
      ...params,
      sort_By: sort_By,
      page: 1,
    });
  };
  const handleChageStatus = (e) => {
    const order_status = e.target.value || "";
    setParams({
      ...params,
      order_status: order_status,
      page: 1,
    });
  };
  const handleFilter = (e) => {
    const filter = e.target.value || "";
    setParams({
      ...params,
      filter: filter,
      page: 1,
    });
    setFilter(e.target.value);
  };

  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;

  const handleCopy = (text) => {
    setCopy(text);
    setTimeout(() => {
      setCopy(false);
    }, 500);
  };

  return (
    <>
      <Tooltip id="order-tooltip" className="tooltip" />
      <ViewModal
        isShow={viewModal}
        setShow={setViewModal}
        viewId={dataId}
        getOrderById={getOrderById}
      />

      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Order</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
              <div class="tbl-filter-block  filter-area">
                <button
                  class="btn btn-filter"
                  type="button"
                  onClick={() => setShowSort(!showSort)}
                >
                  <img src={filtericon} alt="filter" />
                </button>
              </div>
              <select
                className="form-select export-select"
                aria-label="Default select example"
                // value={filter}
                value={params?.filter}
                // onChange={(e) => handleChageFilter(e)}
                onChange={(e) => handleFilter(e)}
              >
                <option value="" selected>
                  Select
                </option>
                <option value="today">Today</option>
                <option value="this_week">This Week</option>
                <option value="last_week">Last Week</option>
                <option value="this_month">This Month</option>
                <option value="last_month">last Month</option>
                <option value="last_six_months">Last Six Months</option>
                <option value="this_year">This Year</option>
              </select>
              <div className="tbl-add-btn">
                <button
                  className="btn"
                  data-bs-toggle="modal"
                  data-bs-target="#sub-category-management"
                  onClick={() => handleDownloadExcel()}
                >
                  <img src={excel} alt="excel" />
                  <span>Export to Excel</span>
                </button>
              </div>
            </div>
          </div>
          <div className={`collapse ${showSort ? "show" : ""}`}>
            <div className="card card-body filter-block">
              <div className="filter-main">
                <div className="row filter-form">
                  <div className="form-group frm-itm col-md-4">
                    <select
                      className="form-control select"
                      onChange={(e) => handleChageSort_By(e)}
                      value={params.sort_By}
                    >
                      <option value="created_at">Created At</option>
                    </select>
                  </div>
                  <div className="form-group frm-itm col-md-4">
                    <select
                      className="form-control select"
                      value={params?.order_status}
                      onChange={(e) => handleChageStatus(e)}
                    >
                      <option value="" selected>
                        Select
                      </option>

                      <option value="ORDERED">Ordered</option>
                      <option value="TRANSIT">In Transit</option>
                      <option value="SHIPPED">Shipped</option>
                      <option value="DELIVERED">Delivered</option>
                      <option value="CANCEL">Cancelled</option>
                    </select>
                  </div>
                  <div className="form-group frm-itm col-md-4">
                    <input
                      id="datepicker"
                      placeholder=""
                      autocomplete="off"
                      className="form-control date-input hasDatepicker"
                      type="date"
                      value={params.created_at}
                      onChange={(e) =>
                        setParams({ ...params, created_at: e.target.value })
                      }
                    />
                  </div>
                </div>
                <div className="filter-btn">
                  <button
                    className="btn btn-clse"
                    onClick={() => setShowSort(false)}
                  >
                    Close
                  </button>
                  <button
                    className="btn btn-reset"
                    onClick={() =>
                      setParams({
                        ...params,
                        order_status: "",
                        sort_By: "created_at",
                        sortOrder: "asc",
                        created_at: "",
                        filter: "",
                      })
                    }
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="table-section custom-scroll custom-scroll-h table-section-lg order-table">
            {isLoadingOrders ? (
              <>
                <div
                  className="table-loader"
                  colSpan={orderTableData?.keys?.length + 3}
                >
                  <img src={Loader} alt="" />
                </div>
              </>
            ) : (
              <>
                <table className="table">
                  <tbody>
                    <tr>
                      <th>No.</th>
                      <CommonTableHeader tableData={orderTableData} />
                    </tr>

                    {allOrders && allOrders?.orders?.rows?.length ? (
                      allOrders?.orders?.rows?.map((item, index) => (
                        <tr>
                          <td>{startSerialNumber + index}</td>

                          <CopyToClipboard
                            text={item?.order_id}
                            onCopy={handleCopy}
                          >
                            <td
                              className="order-data cursor-copy"
                              data-tooltip-content={
                                copy ? "Copied!" : item?.order_id
                              }
                              data-tooltip-id="order-tooltip"
                            >
                              {item?.order_id || "-"}
                            </td>
                          </CopyToClipboard>
                          <Tooltip effect="solid" />

                          <td>{item?.vendor?.vendor_name || "-"}</td>
                          <td>
                            {item?.order?.customer?.first_name || "-"}{" "}
                            {item?.order?.customer?.last_name}
                          </td>
                          <td>
                            {moment(item?.created_at).format("DD MMMM YYYY")}
                          </td>
                          <td>{formatMoney(item?.grand_total)}</td>
                          <td>{item?.order?.payment?.pay_currency} { Number(item?.order?.payment?.pay_amount).toFixed(2)}</td>

                          <td className="status-block">
                            <span
                              className={`status-txt ${
                                item?.order_status === "CANCEL"
                                  ? "rejected-txt"
                                  : "approved-txt"
                              }`}
                            >
                              <img
                                src={
                                  item?.order_status === "CANCEL"
                                    ? reject
                                    : Approved
                                }
                                alt="Approved"
                              />
                              {item?.order_status === "PAYMENT_SUCCESS"
                                ? "SUCCESS"
                                : item?.order_status}
                            </span>
                          </td>
                          <td>
                            <div className="view-action">
                              <img
                                src={viewicon}
                                className="view-icon"
                                data-tooltip-id="order-tooltip"
                                data-tooltip-content="View"
                                onClick={() => handleShowView(item)}
                                alt=""
                              />
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          className="text-center no-data-table"
                          colSpan={orderTableData?.keys?.length + 3}
                        >
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {allOrders?.orders?.rows?.length > 0 ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default Order;
