import { createAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import serviceEndpoints from "../../../config/serviceEndPoints";
import { ResponseApiConfig } from "../../../config/utils";

export const clearMessageOrder = createAction("clearMessageOrder");

export const getOrder = createAsyncThunk(
  "order-get",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("page", data.page);
    params.append("limit", data.limit);
    params.append("search", data.search);
    params.append("sortBy", data.sort_By);
    params.append("sortOrder", data.sortOrder);
    params.append("created_at", data.created_at);

    if (data.order_status) {
      params.append("order_status", data.order_status);
    }

    if (data.filter) {
      params.append("filter", data.filter);
    }

    const endPoint = `${serviceEndpoints.order}?${params.toString()}`;

    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const getOrderById = createAsyncThunk(
  "single-order",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.order}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);
export const getExcelData = createAsyncThunk(
  "export-excel-management",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("filter", data.filter);
    params.append("type", "orders");
    if (data.search) {
      params.append("search", data.search);
    }
    const endPoint = `${serviceEndpoints.excel}/?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);
const OrderSlice = createSlice({
  name: "order",
  initialState: {
    allOrders: "",
    singleOrderData: "",
    excelData: {},
    isLoading: false,
    successMessageOrder: "",
    errorMessage: "",
    success: false,
  },
  extraReducers: (builder) => {
    builder
      .addCase(getOrder.pending, (state) => {
        state.isLoadingOrders = true;
        state.errorMessage = "";
        state.successMessageOrder = "";
        // state.success = false;
        state.entityParams = "";
      })

      .addCase(getOrder.fulfilled, (state, { payload }) => {
        state.isLoadingOrders = false;
        // state.success = true;
        state.allOrders = payload;
        // state.successMessageOrder = payload?.message;
      })
      .addCase(getOrder.rejected, (state, { payload }) => {
        state.allOrders = "";
        state.isLoadingOrders = false;
        state.errorMessage = payload?.message;
      })
      .addCase(getOrderById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.singleOrderData = "";
        state.successMessageOrder = "";
      })
      .addCase(getOrderById.fulfilled, (state, { payload }) => {
        state.singleOrderData = payload;
        state.isLoading = false;
      })
      .addCase(getOrderById.rejected, (state, { payload }) => {
        state.singleOrderData = "";
        state.errorMessage = payload.message;
        state.isLoading = false;
      })
      .addCase(getExcelData.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
      })
      .addCase(getExcelData.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.excelData = payload;
        // state.successMessageOrder = payload.message;
      })
      .addCase(getExcelData.rejected, (state, { payload }) => {
        state.excelData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase("clearMessageOrder", (state) => {
        state.errorMessage = "";
        state.successMessageOrder = "";
        state.success = false;
      });
  },
});

export default OrderSlice.reducer;
