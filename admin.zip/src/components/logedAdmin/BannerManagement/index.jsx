import React, { useEffect, useState } from 'react';

import searchIcon from '../../../assets/img/search-icon.svg';
import filterIcon from '../../../assets/img/filter-filled.svg';
import plusIcon from '../../../assets/img/plus.svg';
import fourdot from '../../../assets/img/four-square.svg';
// import ViewModal from "./ViewModal";
import { CommonTableHeader } from '../../common/CommonTableHeader';
import Loader from '../../../assets/img/Loader.gif';
import nodataicon from '../../../assets/img/no_data.svg';
import CustomPagination from '../../common/CustomPagination';
import view from '../../../assets/img/view-icon.svg';
import deleteicon from '../../../assets/img/table-delete-icon.svg';
import editIcon from '../../../assets/img/edit-icon.svg';

import '../../../assets/scss/header.scss';
import '../../../assets/scss/dashboard.scss';
import '../../../assets/scss/customer-management.scss';
import '../../../assets/scss/table.scss';
import '../../../assets/scss/form.scss';
import '../../../assets/scss/modal.scss';
import '../../../assets/css/bootstrap.css';
import '../../../assets/scss/common.scss';
import '../../../assets/scss/side-nav.scss';
import '../../../assets/scss/filter.scss';

import { useDispatch, useSelector } from 'react-redux';
// import { bannerTableData } from "../../../config/TableData";
import { Tooltip } from 'react-tooltip';
import AddModal from './Components/AddModal';
import {
  clearMessageBanner,
  deleteBannerById,
  getBanner,
  getBannerById,
} from './BannerManagementSlice';
import { Notifications } from '../../../config/utils';
import DeleteModal from '../../common/deletemodal';

const Banner = () => {
  const [addModal, setAddModal] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const dispatch = useDispatch();
  const { isLoadingBanners, allBanners, errorMessage, successMessageBanner } =
    useSelector((state) => state.bannerReducer) || [];

  const [dataId, setDataId] = useState('');

  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: '',
    sortOrder: 'asc',
    sortBy: 'name',
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  useEffect(() => {
    getAllBanners();
  }, [
    params.page,
    params.search,
    params.limit,
    params.sortOrder,
    params.sortby,
  ]);

  useEffect(() => {
    if (params.search !== '') {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  useEffect(() => {
    if (allBanners?.banners?.count) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(allBanners?.banners?.count),
        totalPages: Math.ceil(
          Number(allBanners?.banners?.count) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [allBanners?.banners?.count]);
  useEffect(() => {
    if (successMessageBanner) {
      Notifications(successMessageBanner, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageBanner());
  }, [successMessageBanner, errorMessage]);

  const getAllBanners = async () => {
    await dispatch(getBanner(params));
  };

  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  const handleEdit = (item) => {
    setDataId(item.id);
    dispatch(getBannerById(item.id));
    setShowEdit(true);
    setAddModal(true);
  };

  const handleDeleteBanner = (id) => {
    setDataId(id);
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    await dispatch(deleteBannerById(dataId));
    await getAllBanners();
    setDeleteModal(false);
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;

  return (
    <>
      <Tooltip id="banner-tooltip" className="tooltip" />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <AddModal
        isShow={addModal}
        setShow={setAddModal}
        getAllBanners={getAllBanners}
        showEdit={showEdit}
        editId={dataId}
      />
      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Banner Management</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
              <div className="tbl-filter-block">
                <div className="dropdown">
                  <button
                    className={`btn  ${showSort ? 'show' : ''} `}
                    type="button"
                    id="tbl-filter"
                    data-bs-toggle="dropdown"
                    aria-expanded="true"
                    onClick={() => setShowSort(!showSort)}
                  >
                    <img src={filterIcon} alt="filter" />
                  </button>
                  <ul
                    className={`dropdown-menu dropdown-menu-end ${
                      showSort ? 'show' : ''
                    }`}
                    aria-labelledby="tbl-filter"
                    onClick={() => setShowSort(!showSort)}
                  >
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortBy === 'name' && params.sortOrder === 'asc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'name',
                            sortOrder: 'asc',
                            page: 1,
                          })
                        }
                      >
                        A-Z
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortBy === 'name' &&
                          params.sortOrder === 'desc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'name',
                            sortOrder: 'desc',
                            page: 1,
                          })
                        }
                      >
                        Z-A
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="tbl-add-btn">
                <button
                  className="btn"
                  onClick={() => {
                    if (allBanners?.banners?.count >= 5) {
                      Notifications(
                        'Maximum Banner Creation Limit Reached',
                        'error'
                      );
                    } else {
                      setShowEdit(false);
                      setAddModal(true);
                    }
                  }}
                >
                  <img src={plusIcon} alt="plus" />
                  <span>Add Banner</span>
                </button>
              </div>
            </div>
          </div>
          <div className="table-section custom-scroll custom-scroll-h banner-category-tbl">
            {isLoadingBanners ? (
              <tr>
                <td className="table-loader" colSpan={5}>
                  <img src={Loader} alt="" />
                </td>
              </tr>
            ) : (
              <>
                <table className="table">
                  <tr>
                    <th>
                      {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                      No.
                    </th>
                    <th>Banner Image</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th className="tbl-description">Description</th>
                    <th className="action">Action</th>
                  </tr>
                  {allBanners?.banners?.rows?.length ? (
                    allBanners?.banners?.rows?.map((item, index) => (
                      <>
                        <tr key={index}>
                          <td>
                            {startSerialNumber + index}
                            {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                          </td>
                          <td>
                            <img
                              src={item?.banner_image}
                              className="product-img"
                              alt="product"
                            />
                          </td>

                          <td>{item?.category?.name}</td>

                          <td>{item?.banner_title}</td>
                          <td>{item?.description}</td>
                          <td>
                            <div className="action-icons">
                              <img
                                src={editIcon}
                                className="edit-icon"
                                data-tooltip-id="banner-tooltip"
                                data-tooltip-content="Edit"
                                alt=""
                                onClick={() => handleEdit(item)}
                              />
                              <img
                                src={deleteicon}
                                className="delete-icon"
                                data-tooltip-id="banner-tooltip"
                                data-tooltip-content="Delete"
                                alt="delete-modal"
                                onClick={() => handleDeleteBanner(item.id)}
                              />
                            </div>
                          </td>
                        </tr>
                      </>
                    ))
                  ) : (
                    <tr>
                      <td className="text-center no-data-table" colSpan={6}>
                        <img
                          src={nodataicon}
                          className="no-data-table-img"
                          alt=""
                        />
                      </td>
                    </tr>
                  )}
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {allBanners?.banners?.rows?.length ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default Banner;
