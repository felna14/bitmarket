import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import uploadIcon from "../../../../assets/img/upload-img.svg";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";
import warndngr from "../../../../assets/img/warn-dngr.svg";
import { useDispatch, useSelector } from "react-redux";
import { Notifications } from "../../../../config/utils";
import { createBanner, updateBanner } from "../BannerManagementSlice";
import Loader from "../../../../assets/img/Loader.gif";

const AddModal = ({ isShow, setShow, getAllBanners, showEdit, editId }) => {
  const dispatch = useDispatch();

  const [previewUrl, setPreview] = useState("");
  const { allBanners, singleBannerData, isLoading } =
    useSelector((state) => state.bannerReducer) || [];

  const [filePresent, setFilePresent] = useState(null);

  const handleSubmit = async (values) => {
    if (showEdit) {
      const data = { ...values, editId: editId };
      await dispatch(updateBanner(data));
    } else {
      await dispatch(createBanner(values));
    }
    await getAllBanners();
    setPreview("");
    setShow(false);
  };

  const handleFileChange = (event, setFieldValue) => {
    if (event?.target?.files[0]?.size > 10e6) {
      Notifications("Please upload a file less than 10 MB", "error");
    } else {
      const files = event?.target?.files[0];
      if (files) {
        setFilePresent(files.name);
        setFieldValue("banner_image", files);
        setPreview(URL.createObjectURL(files));
      }
    }
  };

  return (
    <>
      <Modal
        show={isShow}
        className="modal fade add-banner-modal mid"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="sub-category-managementLabel"
        aria-hidden="true"
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="modal-header">
              <h5 className="modal-title">
                {showEdit ? "Edit Banner" : "Add Banner"}
              </h5>
              {/* <button
            type="button"
            className="btn-close"
            onClick={() => {
              setShow(false);
              setPreview('');
            }}
          ></button> */}
            </div>
            <Formik
              initialValues={{
                banner_title:
                  (showEdit && singleBannerData?.data?.banner_title) || "",
                category_id:
                  (showEdit && singleBannerData?.data?.category?.id) || "",
                banner_image:
                  (showEdit && singleBannerData?.data?.banner_image) || "",
                description:
                  (showEdit && singleBannerData?.data?.description) || "",
                banner_subtitle:
                  (showEdit && singleBannerData?.data?.banner_sub_title) || "",
                link: (showEdit && singleBannerData?.data?.link) || "",
              }}
              validationSchema={yup.object({
                category_id: yup
                  .string()
                  .trim(" Name without spaces")
                  .required("Category  is Required"),

                description: yup.string().required("Description is Required"),
                banner_title: yup.string().required("Title  is Required"),
                banner_subtitle: yup.string().required("Subtitle  is Required"),
                link: yup.string().required("Link  is Required"),
                banner_image: yup.mixed().required("Image is Required"),
              })}
              enableReinitialize
              onSubmit={(values, { resetForm }) => {
                handleSubmit(values);
              }}
            >
              {({ values, setFieldValue, isSubmitting }) => (
                <Form>
                  <div className="modal-body">
                    <div className="outer-main">
                      <div className="row">
                        <div className="col-lg-6">
                          <div className="form-group frm-itm">
                            <label className="form-label">
                              {" "}
                              Category<span className="text-danger">*</span>
                            </label>
                            <Field
                              name="category_id"
                              as="select"
                              className="form-control select"
                            >
                              <option>Select Category</option>
                              {allBanners &&
                                allBanners?.categories?.map((data, index) => (
                                  <option key={index} value={data?.id}>
                                    {data?.name}
                                  </option>
                                ))}
                            </Field>
                            <ErrorMessage
                              name="category_id"
                              render={(msg) => (
                                <span className="val-msg ps-2">
                                  <img src={warndngr} alt="" /> {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="form-group frm-itm">
                            <label className="form-label">
                              {" "}
                              Title<span className="text-danger">*</span>
                            </label>
                            <Field
                              name="banner_title"
                              type="text"
                              className="form-control"
                              placeholder="Title"
                            />
                            <ErrorMessage
                              name="banner_title"
                              render={(msg) => (
                                <span className="error">
                                  <img src={warndngr} alt="" />
                                  {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>
                        <div className="col-lg-12">
                          <div className="form-group frm-itm address">
                            <label className="form-label">
                              {" "}
                              Subtitle<span className="text-danger">*</span>
                            </label>
                            <Field
                              name="banner_subtitle"
                              className="form-control"
                              placeholder="Subtitle"
                            />
                            <ErrorMessage
                              name="banner_subtitle"
                              render={(msg) => (
                                <span className="error">
                                  <img src={warndngr} alt="" />
                                  {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>
                        <div className="col-lg-12">
                          <div className="form-group frm-itm address">
                            <label className="form-label">
                              {" "}
                              Description<span className="text-danger">*</span>
                            </label>
                            <Field
                              name="description"
                              as={"textarea"}
                              className="form-control"
                              placeholder="Type Here.."
                            />
                            <ErrorMessage
                              name="description"
                              render={(msg) => (
                                <span className="error">
                                  <img src={warndngr} alt="" />
                                  {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>
                        <div className="col-lg-12">
                          <div className="form-group frm-itm">
                            <label className="form-label">
                              {" "}
                              Link<span className="text-danger">*</span>
                            </label>
                            <Field
                              name="link"
                              type="text"
                              className="form-control"
                              placeholder="Link"
                            />
                            <ErrorMessage
                              name="link"
                              render={(msg) => (
                                <span className="error">
                                  <img src={warndngr} alt="" />
                                  {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>
                        <div className="col-lg-12">
                          <div className="cutom-form-control position-relative">
                            <label className="form-label">
                              Upload Image<span className="text-danger">*</span>
                            </label>
                            <div className="file-input cutom-input-group">
                              <Field name="banner_image">
                                {({ field }) => (
                                  <>
                                    <input
                                      type="file"
                                      accept="image/*"
                                      id="file-input"
                                      className="file-input__input"
                                      onChange={(event) =>
                                        handleFileChange(event, setFieldValue)
                                      }
                                    />
                                  </>
                                )}
                              </Field>
                              <label
                                className="file-input__label"
                                htmlFor="file-input"
                              >
                                <img src={uploadIcon} alt="" />
                                <span>Upload your image</span>
                              </label>
                            </div>
                            {/* <img
                                src={previewUrl}
                                className="image-banner-preview"
                                alt=""
                              /> */}
                            {previewUrl.length ? (
                              <img
                                src={previewUrl}
                                className="image-banner-preview"
                                alt=""
                              />
                            ) : showEdit ? (
                              <img
                                src={singleBannerData?.data?.banner_image}
                                className="image-banner-preview"
                                alt=""
                              />
                            ) : null}
                            <ErrorMessage
                              name="banner_image"
                              render={(msg) => (
                                <span className="error">
                                  <img src={warndngr} alt="" />
                                  {msg}
                                </span>
                              )}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="modal-footer">
                    <div className="btn-area">
                      <button
                        type="button"
                        onClick={() => {
                          setShow(false);
                          setPreview("");
                        }}
                        className="btn btn-cus btn-cancel"
                      >
                        Cancel
                      </button>
                      <button type="submit" className="btn btn-cus btn-save">
                        Submit
                      </button>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </>
        )}
      </Modal>
    </>
  );
};

export default AddModal;
