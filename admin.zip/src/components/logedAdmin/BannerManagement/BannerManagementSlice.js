import { createAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../config/utils';

export const clearMessageBanner = createAction('clearMessageBanner');

export const getBanner = createAsyncThunk(
  'banner-get',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('page', data.page);
    params.append('limit', data.limit);
    params.append('search', data.search);
    params.append('sortBy', data.sortBy);
    params.append('sortOrder', data.sortOrder);
    
    const endPoint = `${serviceEndpoints.banner}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

// &sortBy=${data.sortBy}&sortOrder=${data.sortOrder}
export const createBanner = createAsyncThunk(
  'create-banner',
  async (data, { rejectWithValue }) => {
    const formData = new FormData();
    data.banner_image && formData.append('banner_image', data.banner_image);
    formData.append('banner_title', data.banner_title);
    formData.append('description', data.description);
    formData.append('banner_sub_title', data.banner_subtitle);
    formData.append('link', data.link);
    formData.append('category_id', data.category_id);
    const headers = {
      'Content-Type': 'multipart/form-data',
    };
    const endPoint = `${serviceEndpoints.banner}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      'post',
      formData,
      headers
    );
  }
);

export const updateBanner = createAsyncThunk(
  'update-banner',
  async (data, { rejectWithValue }) => {
    const formData = new FormData();
    typeof data.banner_image !== 'string' &&
      data.banner_image &&
      formData.append('banner_image', data.banner_image);
    formData.append('banner_title', data.banner_title);
    formData.append('description', data.description);
    formData.append('banner_sub_title', data.banner_subtitle);
    formData.append('link', data.link);
    formData.append('category_id', data.category_id);
    const headers = {
      'Content-Type': 'multipart/form-data',
    };
    const endPoint = `${serviceEndpoints.banner}/${data.editId}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      'put',
      formData,
      headers
    );
  }
);

export const getBannerById = createAsyncThunk(
  'single-banner',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.banner}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const deleteBannerById = createAsyncThunk(
  'delete-banner',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.banner}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'delete');
  }
);

const BannerSlice = createSlice({
  name: 'banner',
  initialState: {
    allBanners: '',
    singleBannerData: '',
    excelData: {},
    isLoading: false,
    successMessageBanner: '',
    errorMessage: '',
    success: false,
  },
  extraReducers: (builder) => {
    builder
      .addCase(getBanner.pending, (state) => {
        state.isLoadingBanners = true;
        state.errorMessage = '';
        state.successMessageBanner = '';
        state.entityParams = '';
      })

      .addCase(getBanner.fulfilled, (state, { payload }) => {
        state.isLoadingBanners = false;
        state.allBanners = payload;
      })
      .addCase(getBanner.rejected, (state, { payload }) => {
        state.allBanners = '';
        state.isLoadingBanners = false;
        state.errorMessage = payload?.message;
      })
      .addCase(getBannerById.pending, (state) => {
        state.errorMessage = '';
        state.isLoading = true;
        state.singleBannerData = '';
        state.successMessageBanner = '';
      })
      .addCase(getBannerById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.singleBannerData = payload;
      })
      .addCase(getBannerById.rejected, (state, { payload }) => {
        state.singleBannerData = '';
        state.errorMessage = payload.message;
      })
      .addCase(createBanner.pending, (state) => {
        state.errorMessage = '';
        state.isLoading = true;
        state.successMessageBanner = '';
      })
      .addCase(createBanner.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageBanner = payload.message;
      })
      .addCase(createBanner.rejected, (state, { payload }) => {
        state.errorMessage = payload.message;
      })
      .addCase(updateBanner.pending, (state) => {
        state.errorMessage = '';
        state.isLoading = true;
        state.successMessageBanner = '';
      })
      .addCase(updateBanner.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageBanner = payload.message;
      })
      .addCase(updateBanner.rejected, (state, { payload }) => {
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(deleteBannerById.pending, (state) => {
        state.errorMessage = '';
        state.isLoading = true;
        state.successMessageBanner = '';
      })
      .addCase(deleteBannerById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageBanner = payload.message;
      })
      .addCase(deleteBannerById.rejected, (state, { payload }) => {
        state.errorMessage = payload.message;
      })

      .addCase('clearMessageBanner', (state) => {
        state.errorMessage = '';
        state.successMessageBanner = '';
        state.success = false;
      });
  },
});

export default BannerSlice.reducer;