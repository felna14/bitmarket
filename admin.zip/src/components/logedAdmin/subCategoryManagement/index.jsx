import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DeleteModal from '../../common/deletemodal';
import {
  deleteSubcategoryById,
  getSubCategoryDataById,
  getSubCategoryDetails,
  clearMessageSubCategory,
} from './subcategorymanagementSlice';
import { Tooltip } from 'react-tooltip';
import AddSubCategory from './Components/AddSubCategory';
import EditSub from './Components/EditSub';
import ViewModal from './Components/ViewSub';
import CustomPagination from '../../common/CustomPagination';
import searchIcon from '../../../assets/img/search-icon.svg';
import viewicon from '../../../assets/img/view-icon.svg';
import editIcon from '../../../assets/img/edit-icon.svg';
import deleteicon from '../../../assets/img/table-delete-icon.svg';
import filtericon from '../../../assets/img/filter-filled.svg';
import plusiconn from '../../../assets/img/plus.svg';
import nodataicon from '../../../assets/img/no_data.svg';
import Loader from '../../../assets/img/Loader.gif';
import fourdot from '../../../assets/img/four-square.svg';
import altimagee from '../../../assets/img/avatar.png';
import '../../../assets/css/bootstrap.css';
import '../../../assets/scss/customer-management.scss';
import '../../../assets/scss/table.scss';
import '../../../assets/scss/form.scss';
import '../../../assets/scss/modal.scss';
import '../../../assets/scss/common.scss';

import { Notifications } from '../../../config/utils';
import { getCategoryDetails } from '../CategoryManagement/categorymanagementSlice';
const SubCategory = () => {
  const [addModal, setAddModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [viewModal, setViewModal] = useState(false);
  const [dataId, setDataId] = useState('');
  const [showSort, setShowSort] = useState(false);
  const [itemIsActive, setItemActive] = useState(false);

  const {
    subcategoryData,
    successMessageSubcategory,
    errorMessage,
    isLoadingsubCategory,
  } = useSelector((state) => state.subCategoryReducer);

  const dispatch = useDispatch();
  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: '',
    sortby: 'created_at',
    sortOrder: 'desc',
    categories: 'subCategory',
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  useEffect(() => {
    getCategory();
  }, [params.page, params.search, params.sortby, params.sortOrder]);

  useEffect(() => {
    if (params.search !== '') {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);
  useEffect(() => {
    if (subcategoryData?.pagination?.total) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(subcategoryData?.pagination?.total),
        totalPages: Math.ceil(
          Number(subcategoryData?.pagination?.total) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [subcategoryData?.pagination?.total]);

  useEffect(() => {
    if (successMessageSubcategory) {
      Notifications(successMessageSubcategory, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageSubCategory());
  }, [successMessageSubcategory, errorMessage]);

  const getCategory = async () => {
    await dispatch(getSubCategoryDetails(params));
  };
  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };
  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };
  const handleShowView = (item) => {
    setDataId(item.id);
    setViewModal(true);
    dispatch(getSubCategoryDataById(item.id));
    if (item?.is_active === true) setItemActive(true);
    else setItemActive(false);
  };

  const handleEdit = async (item) => {
    setDataId(item.id);
    await dispatch(getSubCategoryDataById(item.id));
    setEditModal(true);
  };

  const handleDeleteUser = (id) => {
    setDataId(id);
    setDeleteModal(true);
  };
  const handleDelete = async () => {
    await dispatch(deleteSubcategoryById(dataId));
    await getCategory();
    setDeleteModal(false);
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;
  return (
    <>
      <Tooltip id="sub-category-tooltip" className="tooltip" />
      <AddSubCategory
        isShow={addModal}
        setShow={setAddModal}
        getSubCategory={getCategory}
      />
      <EditSub
        isShow={editModal}
        setShow={setEditModal}
        editId={dataId}
        getCategory={getCategory}
      />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <ViewModal
        isShow={viewModal}
        setShow={setViewModal}
        viewId={dataId}
        getCategory={getCategory}
        itemIsActive={itemIsActive}
      />

      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Subcategory Management</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
              <div className="tbl-filter-block ">
                <div className="dropdown">
                  <button
                    className={`btn  ${showSort ? 'show' : ''} `}
                    type="button"
                    onClick={() => setShowSort(!showSort)}
                  >
                    <img src={filtericon} alt="filter" />
                  </button>
                  <ul
                    className={`dropdown-menu dropdown-menu-end ${
                      showSort ? 'show' : ''
                    }`}
                    onClick={() => setShowSort(!showSort)}
                  >
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'name' && params.sortOrder === 'asc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'name',
                            sortOrder: 'asc',
                            page: 1,
                          })
                        }
                      >
                        A-Z
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'name' &&
                          params.sortOrder === 'desc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'name',
                            sortOrder: 'desc',
                            page: 1,
                          })
                        }
                      >
                        Z-A
                      </a>
                    </li>
                    {/* <li>
                      <a className="dropdown-item" href="#/">
                        Status
                      </a>
                    </li> */}
                  </ul>
                </div>
              </div>
              <div className="tbl-add-btn">
                <button className="btn" onClick={() => setAddModal(true)}>
                  <img src={plusiconn} alt="plus" />
                  <span>Add Subcategory</span>
                </button>
              </div>
            </div>
          </div>

          <div className="table-section custom-scroll custom-scroll-h sub-category-tbl sub-category-table">
            {isLoadingsubCategory ? (
              <tr>
                <td className="table-loader" colSpan={6}>
                  <img src={Loader} alt="" />
                </td>
              </tr>
            ) : (
              <>
                <table className="table">
                  <tbody>
                    <tr>
                      <th>
                        {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                        No.
                      </th>
                      <th>Image</th>
                      <th>Category</th>
                      <th>Subcategory</th>
                      <th className="tbl-description">Description</th>
                      <th>Active</th>
                      <th className="action">Action</th>
                    </tr>

                    {subcategoryData && subcategoryData?.rows?.length ? (
                      subcategoryData?.rows?.map((item, index) => (
                        <>
                          <tr key={index}>
                            <td>
                              {startSerialNumber + index}
                              {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                            </td>
                            <td>
                              <img
                                src={item?.image || altimagee}
                                className="product-img"
                                alt="product"
                              />
                            </td>
                            <td>{item?.Category.name || '-'}</td>
                            <td>{item?.name || '-'}</td>
                            <td
                              className="td-sub-description"
                              data-tooltip-id="sub-category-tooltip"
                              data-tooltip-content={
                                item.description.length > 60
                                  ? item.description
                                  : ''
                              }
                            >
                              {item?.description || '-'}
                            </td>
                            <td
                              className={
                                item?.is_active === true
                                  ? 'approved-txt'
                                  : 'rejected-txt'
                              }
                            >
                              {item?.is_active === true ? 'Yes' : 'No' || ''}
                            </td>
                            <td>
                              <div className="action-icons">
                                <img
                                  src={viewicon}
                                  className="view-icon"
                                  data-tooltip-id="sub-category-tooltip"
                                  data-tooltip-content="View"
                                  alt=""
                                  onClick={() => handleShowView(item)}
                                />
                                {item?.is_active === true ? (
                                  <>
                                    <img
                                      src={editIcon}
                                      className="edit-icon"
                                      data-tooltip-id="sub-category-tooltip"
                                      data-tooltip-content="Edit"
                                      alt=""
                                      onClick={() => handleEdit(item)}
                                    />
                                    <img
                                      src={deleteicon}
                                      className="delete-icon"
                                      data-tooltip-id="sub-category-tooltip"
                                      data-tooltip-content="Delete"
                                      alt=""
                                      onClick={() => handleDeleteUser(item.id)}
                                    />
                                  </>
                                ) : (
                                  ''
                                )}
                              </div>
                            </td>
                          </tr>
                        </>
                      ))
                    ) : (
                      <tr>
                        <td className="text-center no-data-table" colSpan={6}>
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {subcategoryData?.rows?.length ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default SubCategory;
