import React, { useEffect, useState } from "react";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";
import { Modal } from "react-bootstrap";
import galleryimport from "../../../../assets/img/gallery-import.svg";
import warndngr from "../../../../assets/img/warn-dngr.svg";
import Loader from "../../../../assets/img/Loader.gif";
import {
  editSubCategoryDatabyId,
  getSubCategoryDataById,
} from "../subcategorymanagementSlice";
import { useDispatch, useSelector } from "react-redux";
import { Notifications } from "../../../../config/utils";
import altimagee from "../../../../assets/img/avatar.png";
import { getAllCategoryDetails } from "../../CategoryManagement/categorymanagementSlice";

const EditSub = ({ isShow, setShow, getCategoryList, editId }) => {
  const dispatch = useDispatch();
  const [previewUrl, setPreview] = useState("");
  const { singleCategoryData, subcategoryData, isLoading } = useSelector(
    (state) => state.subCategoryReducer
  );

  const { categoryData, allCategoryData } = useSelector(
    (state) => state.categoryManagementReducer
  );

  const [params, setParams] = useState({
    limit: 300,
    page: 1,
    search: "",
    sortby: "name",
    sortOrder: "asc",
    categories: "subCategory",
  });

  useEffect(() => {
    getAllCategory();
  }, []);

  const getAllCategory = async () => {
    await dispatch(getAllCategoryDetails(params));
  };

  const initialValues = {
    name: singleCategoryData?.category?.name || "",
    description: singleCategoryData?.category?.description || "",
    image: singleCategoryData?.category?.image || "",
    parent_id: singleCategoryData?.category?.parent_id,
    platform: "web",
  };
  const handleSubmit = async (event) => {
    const data = { ...event, editId: editId };
    await dispatch(editSubCategoryDatabyId(data));
    await dispatch(getSubCategoryDataById(editId));
    await getCategoryList();
    setShow(false);
    setPreview("");
  };
  const SUPPORTED_FORMATS = [
    "image/jpg",
    "image/jpeg",
    "image/gif",
    "image/png",
  ];

  const handleFileChange = (event, setFieldValue) => {
    const files = event?.target?.files[0];
    if (files?.size > 10e6) {
      Notifications("Please upload a file less than 10 MB", "error");
    } else {
      if (files) {
        setFieldValue("image", files);
        setPreview(URL.createObjectURL(files));
      }
    }
  };
  return (
    <Modal
      show={isShow}
      className="modal fade sub-cat-edit mid sub-category-management-editLabel-modal"
      id="sub-category-management-edit"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="sub-category-management-editLabel"
      aria-hidden="true"
      centered
    >
      {isLoading ? (
        <>
          <div className="loaderWrapper loader-wrapper-height ">
            <div className="table-loader">
              <img src={Loader} alt="" />
            </div>
          </div>
        </>
      ) : (
        <>
          <Formik
            initialValues={initialValues}
            validationSchema={yup.object({
              parent_id: yup
                .string()
                .trim(" Name without spaces")
                .required("Category Name is Required"),
              name: yup
                .string()
                .trim(" Name without spaces")
                .required("Sub-Category Name is Required"),

              description: yup.string().required("Description is Required"),
            })}
            enableReinitialize
            onSubmit={(values, { resetForm }) => {
              handleSubmit(values);
              resetForm({ values: "" });
            }}
          >
            {({ values, setFieldValue, isSubmitting }) => (
              <Form>
                <div className="modal-dialog-centered">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5
                        className="modal-title"
                        id="sub-category-management-editLabel"
                      >
                        Edit Subcategory
                      </h5>
                    </div>

                    <div className="modal-body">
                      <div className="outer-main row">
                        <div className="col-lg-3 upload-sec">
                          <label className="form-label">
                            {" "}
                            Upload Image<span className="text-danger">*</span>
                          </label>
                          <div className="profile-img">
                            <img
                              src={
                                previewUrl.length
                                  ? previewUrl
                                  : values.image || altimagee
                              }
                              alt="Preview"
                              // alt= { <img src={altimagee}/>}
                            />
                            <div className="upload-btn">
                              <Field name="image">
                                {({ field }) => (
                                  <>
                                    <input
                                      type="file"
                                      accept="image/*"
                                      id="image"
                                      className="file-input__input"
                                      title=""
                                      onChange={(event) =>
                                        handleFileChange(event, setFieldValue)
                                      }
                                    />
                                  </>
                                )}
                              </Field>
                              <img src={galleryimport} alt="" />
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-9 profile-data-main">
                          <div className=" row profile-data">
                            <div className="col-md-6 form-group frm-itm">
                              <label className="form-label">
                                {" "}
                                Category<span className="text-danger">*</span>
                              </label>
                              <Field
                                name="parent_id"
                                className="form-control select"
                                as="select"
                              >
                                <option
                                  selected
                                  value={
                                    singleCategoryData?.category?.Category?.id
                                  }
                                >
                                  {singleCategoryData?.category?.Category?.name}
                                </option>
                                {/* {categoryData?.rows?.map((item, index) => (
                              <option key={index} value={item?.id}>
                                {item?.name}
                              </option>
                            ))} */}

                                {allCategoryData &&
                                  allCategoryData?.rows?.map((data, index) => (
                                    <option key={index} value={data?.id}>
                                      {data?.name}
                                    </option>
                                  ))}
                              </Field>
                              <ErrorMessage
                                name="parent_id"
                                render={(msg) => (
                                  <span className="val-msg">
                                    <img src={warndngr} alt="" /> {msg}
                                  </span>
                                )}
                              />
                            </div>
                            <div className="col-md-6 form-group frm-itm">
                              <label className="form-label">
                                {" "}
                                Subcategory
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                type="text"
                                name="name"
                                className="form-control"
                                placeholder=" Enter Subcategory"
                              />
                              <ErrorMessage
                                name="name"
                                render={(msg) => (
                                  <span className="val-msg">
                                    <img src={warndngr} alt="" /> {msg}
                                  </span>
                                )}
                              />
                            </div>
                            <div className="col-md-6 form-group frm-itm address">
                              <label className="form-label">
                                {" "}
                                Description
                                <span className="text-danger">*</span>
                              </label>
                              <Field
                                name="description"
                                as="textarea"
                                className="form-control"
                                placeholder="Enter Description"
                              ></Field>

                              <ErrorMessage
                                name="description"
                                render={(msg) => (
                                  <span className="val-msg">
                                    <img src={warndngr} alt="" /> {msg}
                                  </span>
                                )}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="modal-footer">
                      <div className="btn-area">
                        <button
                          type="button"
                          className="btn btn-cus btn-cancel"
                          data-bs-dismiss="modal"
                          onClick={() => {
                            setShow(false);
                            setPreview("");
                          }}
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="btn btn-cus btn-save"
                        >
                          {isSubmitting ? (
                            <span
                              class="spinner-border spinner-border-sm"
                              role="status"
                              aria-hidden="true"
                            ></span>
                          ) : (
                            "Save"
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </>
      )}
    </Modal>
  );
};

export default EditSub;
