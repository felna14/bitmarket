import React, { useEffect, useState } from 'react';
import { Modal } from 'react-bootstrap';
import { Field, Formik, ErrorMessage, Form } from 'formik';
import * as yup from 'yup';
import warndngr from '../../../../assets/img/warn-dngr.svg';
import uploadimg from '../../../../assets/img/upload-img.svg';
import { useDispatch, useSelector } from 'react-redux';
import { postAddSubCategory } from '../subcategorymanagementSlice';
import { Notifications } from '../../../../config/utils';
import { getAllCategoryDetails } from '../../CategoryManagement/categorymanagementSlice';

const AddSubCategory = ({ isShow, setShow, getSubCategory }) => {
  const dispatch = useDispatch();
  const [previewUrl, setPreview] = useState('');
  const { allCategoryData } = useSelector(
    (state) => state.categoryManagementReducer
  );
  const [filePresent, setFilePresent] = useState(null);

  const [params, setParams] = useState({
    limit: 300,
    page: 1,
    search: '',
    sortby: 'name',
    sortOrder: 'asc',
    categories: 'subCategory',
  });

  useEffect(() => {
    getCategory();
  }, []);

  const getCategory = async () => {
    await dispatch(getAllCategoryDetails(params));
  };

  const handleSubmit = async (event) => {
    await dispatch(postAddSubCategory(event));
    await getSubCategory();
    setPreview('');
    setShow(false);
  };

  const handleFileChange = (event, setFieldValue) => {
    if (event?.target?.files[0]?.size > 10e6) {
      Notifications('Please upload a file less than 10 MB', 'error');
    } else {
      const files = event?.target?.files[0];
      if (files) {
        setFilePresent(files.name);
        setFieldValue('image', files);
        setPreview(URL.createObjectURL(files));
      }
    }
  };

  return (
    <Modal
      show={isShow}
      className="modal fade sub-cat-edit mid addSubcategory-modal"
      id="sub-category-management"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="sub-category-managementLabel"
      aria-hidden="true"
      centered
    >
      <Formik
        initialValues={{
          name: '',
          image: '',
          parent_id: '',
          description: '',
          slug: 'slug',
        }}
        validationSchema={yup.object({
          parent_id: yup
            .string()
            .trim(' Name without spaces')
            .required('Category Name is Required'),
          name: yup
            .string()
            .trim(' Name without spaces')
            .required('Subcategory Name is Required'),

          description: yup
            .string()
            .required('Description is Required')
            .trim(' Name without spaces'),
          image: yup
            .mixed()
            .test('fileSize', 'Image must be less than 10MB', (value) =>
              value ? value.size <= 10 * 1024 * 1024 : true
            )
            .required('Image is Required'),
        })}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          handleSubmit(values);
        }}
      >
        {({ values, setFieldValue, isSubmitting }) => (
          <Form>
            <div className="modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="sub-category-managementLabel">
                    Add Subcategory{' '}
                  </h5>
                  {/* <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => {
                      setShow(false);
                      setPreview('');
                      setFilePresent('');
                    }}
                  ></button> */}
                </div>

                <div className="modal-body">
                  <div className="outer-main row">
                    <div className="col-lg-4 upload-sec">
                      <label className="form-label">
                        {' '}
                        Upload Image<span className="text-danger">*</span>
                      </label>

                      <div className="upload-area">
                        <div className="upload">
                          <img
                            src={
                              previewUrl.length
                                ? previewUrl
                                : values.image || uploadimg
                            }
                            alt="Preview"
                          />
                          {!previewUrl.length ? (
                            <>
                              <h3 className="heading">
                                Drag And Drop Your Image Here
                              </h3>
                              <p className="content">
                                File Should be Jpeg and PNG Maximum Size 5mb
                              </p>
                            </>
                          ) : null}{' '}
                          <Field name="image">
                            {({ field }) => (
                              <>
                                <input
                                  type="file"
                                  accept="image/*"
                                  id="image"
                                  className="upload-hide"
                                  title=""
                                  onChange={(event) =>
                                    handleFileChange(event, setFieldValue)
                                  }
                                />
                              </>
                            )}
                          </Field>
                        </div>

                        <div>
                          <ErrorMessage
                            name="image"
                            render={(msg) => (
                              <span className="error">
                                <img src={warndngr} alt="" />
                                {msg}
                              </span>
                            )}
                          />
                        </div>

                        {filePresent ? (
                          <div className="process">
                            <div className="head-sec">
                              <h3 className="name">{filePresent}</h3>
                              <h3 className="size">150 kB</h3>
                            </div>
                            <div className="progress">
                              <div
                                className="progress-bar progress-bar-striped"
                                role="progressbar"
                                aria-valuenow="75"
                                aria-valuemin="0"
                                aria-valuemax="100"
                                style={{ width: '100%' }}
                              ></div>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                    <div className="col-lg-8 profile-data-main">
                      <div className=" row profile-data">
                        <div className="col-md-6 form-group frm-itm">
                          <label className="form-label">
                            {' '}
                            Category<span className="text-danger">*</span>
                          </label>
                          <Field
                            name="parent_id"
                            as="select"
                            className="form-control select"
                          >
                            <option>Select Category</option>
                            {allCategoryData &&
                              allCategoryData?.rows?.map((data, index) => (
                                <option key={index} value={data?.id}>
                                  {data?.name}
                                </option>
                              ))}
                          </Field>
                          <ErrorMessage
                            name="parent_id"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={warndngr} alt="" /> {msg}
                              </span>
                            )}
                          />
                        </div>
                        <div className="col-md-6 form-group frm-itm">
                          <label className="form-label">
                            {' '}
                            Subcategory<span className="text-danger">*</span>
                          </label>
                          <Field
                            type="text"
                            name="name"
                            className="form-control"
                            placeholder="Enter Subcategory"
                          />
                          <ErrorMessage
                            name="name"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={warndngr} alt="" /> {msg}
                              </span>
                            )}
                          />
                        </div>
                        <div className="col-md-6 form-group frm-itm address mb-4">
                          <label className="form-label">
                            {' '}
                            Description<span className="text-danger">*</span>
                          </label>
                          <Field
                            name="description"
                            as="textarea"
                            className="form-control"
                            placeholder="Type Here.."
                          />

                          <ErrorMessage
                            name="description"
                            render={(msg) => (
                              <span className="val-msg">
                                <img src={warndngr} alt="" /> {msg}
                              </span>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <div className="btn-area">
                    <button
                      type="button"
                      className="btn btn-cus btn-cancel"
                      data-bs-dismiss="modal"
                      onClick={() => {
                        setShow(false);
                        setPreview('');
                        setFilePresent('');
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="btn btn-cus btn-save"
                    >
                      {isSubmitting ? (
                        <span
                          class="spinner-border spinner-border-sm"
                          role="status"
                          aria-hidden="true"
                        ></span>
                      ) : (
                        'Submit'
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Modal>
  );
};

export default AddSubCategory;
