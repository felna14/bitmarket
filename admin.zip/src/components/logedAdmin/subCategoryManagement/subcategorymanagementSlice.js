import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import serviceEndpoints from "../../../config/serviceEndPoints";
import { ResponseApiConfig } from "../../../config/utils";

export const clearMessageSubCategory = createAction("clearMessageSubCategory");

export const getSubCategoryDetails = createAsyncThunk(
  "sub-category-management",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("page", data.page);
    params.append("limit", data.limit);
    params.append("name", data.search);
    params.append("subCategory", data.categories);
    params.append("sortBy", data.sortby);
    params.append("sortOrder", data.sortOrder);

    const endPoint = `${serviceEndpoints.category}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const getSubCategoryDataById = createAsyncThunk(
  "single-sub-category-management",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.category}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const postAddSubCategory = createAsyncThunk(
  "add-sub-category",
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();
    body.image && formData.append("image", body.image);
    formData.append("name", body.name);
    formData.append("description", body.description);
    formData.append("slug", body.slug);
    formData.append("parent_id", body.parent_id);

    const headers = {
      "Content-Type": "multipart/form-data",
    };

    const endPoint = `${serviceEndpoints.category}`;

    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      "post",
      formData,
      headers
    );
  }
);

export const deleteSubcategoryById = createAsyncThunk(
  "delete-sub-category",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.category}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "delete");
  }
);

export const editSubCategoryDatabyId = createAsyncThunk(
  "single-sub-category-management-edit",
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();
    formData.append("image", body.image);
    formData.append("name", body.name);
    formData.append("description", body.description);
    formData.append("parent_id", body.parent_id);

    formData.append("platform", "web");
    const headers = {
      "Content-Type": "multipart/form-data",
    };
    const endPoint = `${serviceEndpoints.category}/${editId}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      "patch",
      formData,
      headers
    );
  }
);

const subCategoryManagementSlice = createSlice({
  name: "sub-category-management",
  initialState: {
    subcategoryData: {},
    isLoadingsubCategory: false,
    success: false,
    isLoading: false,
    errorMessage: "",
    successMessageSubcategory: "",
    singleCategoryData: "",
  },

  extraReducers: (builder) => {
    builder
      .addCase(getSubCategoryDetails.pending, (state) => {
        state.isLoadingsubCategory = true;
        state.errorMessage = "";
        state.successMessage = "";
        state.success = false;
        state.entityParams = "";
      })

      .addCase(getSubCategoryDetails.fulfilled, (state, { payload }) => {
        state.isLoadingsubCategory = false;
        state.success = true;
        state.subcategoryData = payload;
        state.successMessage = payload.message;
      })
      .addCase(getSubCategoryDetails.rejected, (state, { payload }) => {
        state.subcategoryData = {};
        state.isLoadingsubCategory = false;
        state.success = false;
        state.errorMessage = payload.message;
      })
      .addCase(getSubCategoryDataById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessage = "";
        state.entityParams = "";
      })
      .addCase(getSubCategoryDataById.fulfilled, (state, { payload }) => {
        state.singleCategoryData = payload;
        state.successMessage = payload.message;
        state.isLoading = false;
      })
      .addCase(getSubCategoryDataById.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.errorMessage = payload.message;
        state.isLoading = false;
      })
      .addCase(editSubCategoryDatabyId.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageSubcategory = "";
      })
      .addCase(editSubCategoryDatabyId.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageSubcategory = payload.message;
      })
      .addCase(editSubCategoryDatabyId.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(deleteSubcategoryById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageSubcategory = "";
      })
      .addCase(deleteSubcategoryById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageSubcategory = payload.message;
      })
      .addCase(deleteSubcategoryById.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(postAddSubCategory.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageSubcategory = "";
      })
      .addCase(postAddSubCategory.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageSubcategory = payload.message;
      })
      .addCase(postAddSubCategory.rejected, (state, { payload }) => {
        state.singleCategoryData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase("clearMessageSubCategory", (state) => {
        state.errorMessage = "";
        state.successMessageSubcategory = "";
        state.success = false;
      });
  },
});

export default subCategoryManagementSlice.reducer;
