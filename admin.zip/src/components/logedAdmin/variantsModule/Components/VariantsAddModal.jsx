import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import btnView from "../../../../assets/img/btn-view.svg";
import btnMin from "../../../../assets/img/btn-min.svg";
import "../../../../assets/scss/modal.scss";
import warndngr from "../../../../assets/img/warn-dngr.svg";
import { Field, Formik, ErrorMessage, Form, FieldArray } from "formik";
import * as yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import {
  clearMessageVariant,
  postAddvariants,
  VarientUpdate,
} from "../variantsmoduleSlice";
import { Notifications } from "../../../../config/utils";
import Loader from "../../../../assets/img/Loader.gif";

const VarientsAddModal = ({
  isShow,
  setShow,
  showEdit,
  dataId,
  getVariant,
}) => {
  const dispatch = useDispatch();
  const { singleVariantData, successMessageVariant, errorMessage, isLoading } =
    useSelector((state) => state.variantsReducer);
  const [removedIds, setRemovedIds] = useState([]);

  useEffect(() => {
    if (successMessageVariant) {
      Notifications(successMessageVariant, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageVariant());
  }, [successMessageVariant, errorMessage]);

  const handleSubmit = async (event) => {
    const { variant_name, ...varient } = event;
    const variantName = variant_name?.map((item) => item.variant_name);

    if (showEdit) {
      const data = {
        ...varient,
        dataId: dataId,
        variant_name: variantName,
      };

      const changedVariantNames = variant_name?.reduce((acc, item, index) => {
        if (
          item?.variant_name !==
          singleVariantData?.variant?.variant_category_names[index]
            ?.variant_name
        ) {
          acc.push(item.variant_name);
        }
        return acc;
      }, []);

      const uniqueRemovedIds = removedIds?.length > 0 && [
        ...new Set(removedIds),
      ];

      const filteredArray =
        uniqueRemovedIds?.length > 0 &&
        uniqueRemovedIds.filter((value) => {
          return value !== null && value !== undefined && value !== "";
        });
      if (changedVariantNames.length > 0) {
        data["variant_name"] = changedVariantNames;
      }

      if (filteredArray.length > 0) {
        data["deleted"] = filteredArray;
      }
      if (singleVariantData?.variant?.variant === data?.variant) {
        const { variant, ...varient_data } = data;
        await dispatch(VarientUpdate(varient_data));
      } else {
        await dispatch(VarientUpdate(data));
      }
    } else {
      const data = { ...varient, variant_name: variantName };
      await dispatch(postAddvariants(data));
    }

    await getVariant();
    setRemovedIds("");
    setShow(false);
  };

  const handleRemove = (remove, index, setFieldValue, values) => {
    if (showEdit) {
      setRemovedIds([...removedIds, values.variant_name[index].id]);
      remove(index);
    } else {
      remove(index);
    }
  };

  const handleRemoveChanged = (index, setFieldValue, values, e) => {
    if (showEdit) {
      setRemovedIds([...removedIds, values.variant_name[index].id]);
      setFieldValue(`variant_name.${index}.variant_name`, e.target.value);
    } else {
      setFieldValue(`variant_name.${index}.variant_name`, e.target.value);
    }
  };

  return (
    <>
      <Modal
        show={isShow}
        className="modal fade modal-login variant-modal-new"
        id="forgotPassword"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="forgotPasswordLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <Formik
              initialValues={{
                variant:
                  (showEdit && singleVariantData?.variant?.variant) || "",
                variant_name: (showEdit &&
                  singleVariantData?.variant?.variant_category_names) || [
                  { variant_name: "" },
                ],
              }}
              validationSchema={yup.object().shape({
                variant: yup.string().required("Variant Category is Required"),
                variant_name: yup
                  .array()
                  .of(
                    yup.object().shape({
                      variant_name: yup
                        .string()
                        .required("Variant Type is Required"),
                    })
                  )
                  .required("At least one Variant Type is Required"),
              })}
              enableReinitialize={showEdit ? true : false}
              onSubmit={(values, { resetForm }) => {
                handleSubmit(values);
              }}
            >
              {({
                isSubmitting,
                setFieldValue,
                values,
                errors,
                initialValues,
              }) => (
                <Form>
                  <div className="modal-dialog modal-dialog-centered ">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="VariantsLabel">
                          {showEdit ? "Edit Variants" : "Add Variants"}
                        </h5>
                        {/* <button
                      type="button"
                      className="btn-close"
                      data-bs-dismiss="modal"
                      aria-label="Close"
                      onClick={() => setShow(false)}
                    ></button> */}
                      </div>
                      <div className="modal-body variants-add-modal-body custom-scroll">
                        <div className="outer-main">
                          <div className="row variant">
                            <div className="col-md-12 form-group frm-itm p-0">
                              <div class="frm-item">
                                <label className="form-label">
                                  Variant Category
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="text"
                                  name="variant"
                                  className="form-control"
                                  placeholder="Enter Variant Category"
                                />
                                <ErrorMessage
                                  name="variant"
                                  render={(msg) => (
                                    <span className="val-msg ps-3">
                                      <img src={warndngr} alt="" /> {msg}
                                    </span>
                                  )}
                                />
                              </div>
                            </div>
                            <div className="col-md-12 form-group frm-itm p-0 add">
                              <FieldArray name="variant_name">
                                {({ push, remove }) => (
                                  <>
                                    <div className="add-sec add-btn-block">
                                      <label className="form-label">
                                        Variant Type
                                        <span className="text-danger">*</span>
                                      </label>
                                      <button
                                        type="button"
                                        disabled={
                                          Object.keys(errors).length > 0
                                        }
                                        className="btn btn-add"
                                        onClick={() => {
                                          if (
                                            Object.keys(errors).length === 0
                                          ) {
                                            push({ variant_name: "" });
                                          }
                                        }}
                                      >
                                        <img src={btnView} alt="view" />
                                      </button>
                                    </div>
                                    <div>
                                      {values?.variant_name?.map(
                                        (name, index) => (
                                          <div key={index} className="add-sec">
                                            <Field
                                              name={`variant_name.${index}.variant_name`}
                                            >
                                              {() => (
                                                <>
                                                  <input
                                                    type="text"
                                                    className="form-control"
                                                    placeholder="Enter Variant Type"
                                                    value={name?.variant_name}
                                                    onChange={(e) =>
                                                      handleRemoveChanged(
                                                        index,
                                                        setFieldValue,
                                                        values,
                                                        e
                                                      )
                                                    }
                                                  />
                                                </>
                                              )}
                                            </Field>
                                            <ErrorMessage
                                              name={`variant_name.${index}.variant_name`}
                                              render={(msg) => (
                                                <span className="val-msg ps-3">
                                                  <img src={warndngr} alt="" />{" "}
                                                  {msg}
                                                </span>
                                              )}
                                            />
                                            {index > 0 && (
                                              <button
                                                type="button"
                                                className="btn btn-min"
                                                onClick={() =>
                                                  handleRemove(
                                                    remove,
                                                    index,
                                                    setFieldValue,
                                                    values
                                                  )
                                                }
                                              >
                                                <img src={btnMin} alt="view" />
                                              </button>
                                            )}
                                          </div>
                                        )
                                      )}
                                    </div>
                                  </>
                                )}
                              </FieldArray>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="modal-footer">
                        <div className="btn-area">
                          <button
                            type="button"
                            className="btn btn-cus btn-cancel"
                            data-bs-dismiss="modal"
                            onClick={() => setShow(false)}
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            disabled={isSubmitting}
                            className="btn btn-cus btn-save"
                          >
                            {isSubmitting ? (
                              <span
                                class="spinner-border spinner-border-sm"
                                role="status"
                                aria-hidden="true"
                              ></span>
                            ) : (
                              "Submit"
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </>
        )}
      </Modal>
    </>
  );
};

export default VarientsAddModal;
