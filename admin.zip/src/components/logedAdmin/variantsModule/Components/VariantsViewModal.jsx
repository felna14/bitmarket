import React from "react";
import { Modal } from "react-bootstrap";
import { useSelector } from "react-redux";
import "../../../../assets/scss/form.scss";
import "../../../../assets/scss/modal.scss";
import Loader from "../../../../assets/img/Loader.gif";

const VariantsViewModal = ({ isShow, setShow }) => {
  const { singleVariantData, isLoading } = useSelector(
    (state) => state.variantsReducer
  );
  const { variant } = singleVariantData;
  return (
    <Modal
      show={isShow}
      className="modal fade varients-view sml-modal "
      id="forgotPassword"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="forgotPasswordLabel"
      aria-hidden="true"
      centered
    >
      {isLoading ? (
        <>
          <div className="loaderWrapper loader-wrapper-height ">
            <div className="table-loader">
              <img src={Loader} alt="" />
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="variants-viewLabel">
                  View Variants
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={() => setShow(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="outer-main">
                  <div className="row variant">
                    <div className="col-md-6 frm-itm line">
                      <label className="form-label">Variants Category</label>
                      <h3 className="frm-value">{variant?.variant || "-"}</h3>
                    </div>
                    <div className="col-md-6 frm-itm line">
                      <label className="form-label">No. of Variants</label>
                      <h3 className="frm-value">
                        {variant?.variant_category_names?.length || "-"}
                      </h3>
                    </div>
                    <div className="col-md-12 frm-itm line light-red m-0">
                      <label className="form-label">Variant Type</label>
                      <div className="colors">
                        {variant?.variant_category_names?.map((item) => (
                          <span className="color-view">
                            {item.variant_name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
};

export default VariantsViewModal;
