import { createAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import serviceEndpoints from "../../../config/serviceEndPoints";
import { ResponseApiConfig } from "../../../config/utils";

export const clearMessageVariant = createAction("clearMessageVariants");

export const getVariantDetails = createAsyncThunk(
  "variants-module",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append("page", data.page);
    params.append("limit", data.limit);
    params.append("search", data.search);
    params.append("sortBy", data.sortby);
    params.append("sortOrder", data.sortOrder);

    const endPoint = `${serviceEndpoints.variants_module}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const getVariantById = createAsyncThunk(
  "single-variant",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.variants_module}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const postAddvariants = createAsyncThunk(
  "add-variants",
  async (data, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.variants_add}`;

    return ResponseApiConfig(rejectWithValue, endPoint, "post", data);
  }
);
export const VarientUpdate = createAsyncThunk(
  "update-variants",
  async (data, { rejectWithValue }) => {
    const { dataId, ...body } = data;
    const endPoint = `${serviceEndpoints.VarientUpdate}/${dataId}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "put", body);
  }
);

export const deleteVariantsById = createAsyncThunk(
  "delete-variants",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.variants_module}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "delete");
  }
);

const variantsmoduleSlice = createSlice({
  name: "variants-module",
  initialState: {
    variantData: {},
    success: false,
    isLoading: false,
    isLoadingvariant: false,
    errorMessage: "",
    successMessageVariant: "",
    singleVariantData: "",
  },

  extraReducers: (builder) => {
    builder
      .addCase(getVariantDetails.pending, (state) => {
        state.isLoadingvariant = true;
        state.errorMessage = "";
        state.successMessage = "";
        state.success = false;
      })
      .addCase(getVariantDetails.fulfilled, (state, { payload }) => {
        state.isLoadingvariant = false;
        state.success = true;
        state.variantData = payload;
        state.successMessage = payload.message;
      })
      .addCase(getVariantDetails.rejected, (state, { payload }) => {
        state.variantData = {};
        state.isLoadingvariant = false;
        state.success = false;
        state.errorMessage = payload.message;
      })

      .addCase(getVariantById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessage = "";
      })
      .addCase(getVariantById.fulfilled, (state, { payload }) => {
        state.singleVariantData = payload;
        state.successMessage = payload.message;
        state.isLoading = false;
      })
      .addCase(getVariantById.rejected, (state, { payload }) => {
        state.singleVariantData = {};
        state.errorMessage = payload.message;
        state.isLoading = false;
      })

      .addCase(VarientUpdate.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageVariant = "";
      })
      .addCase(VarientUpdate.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        // state.success=true;
        state.singleVariantData = payload;
        state.successMessageVariant = payload.message;
      })
      .addCase(VarientUpdate.rejected, (state, { payload }) => {
        state.singleVariantData = {};
        state.isLoading = false;
        // state.success=false
        state.errorMessage = payload.message;
      })

      .addCase(deleteVariantsById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageVariant = "";
      })
      .addCase(deleteVariantsById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageVariant = payload.message;
      })
      .addCase(deleteVariantsById.rejected, (state, { payload }) => {
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(postAddvariants.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageVariant = "";
      })
      .addCase(postAddvariants.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageVariant = payload.message;
      })
      .addCase(postAddvariants.rejected, (state, { payload }) => {
        // state.singleVariantData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase("clearMessageVariants", (state) => {
        state.errorMessage = "";
        state.successMessageVariant = "";
        state.success = false;
      });
  },
});

export default variantsmoduleSlice.reducer;
