import React, { useEffect, useState } from 'react';

import searchIcon from '../../../assets/img/search-icon.svg';
import filterIcon from '../../../assets/img/filter-filled.svg';
import plusIcon from '../../../assets/img/plus.svg';
import view from '../../../assets/img/view-icon.svg';
import deleteicon from '../../../assets/img/table-delete-icon.svg';
import fourdot from '../../../assets/img/four-square.svg';
import Loader from '../../../assets/img/Loader.gif';
import nodataicon from '../../../assets/img/no_data.svg';

import '../../../assets/scss/dashboard.scss';
import '../../../assets/scss/customer-management.scss';
import '../../../assets/scss/table.scss';
import '../../../assets/scss/form.scss';
import '../../../assets/scss/modal.scss';
import '../../../assets/css/bootstrap.css';
import '../../../assets/scss/common.scss';
import '../../../assets/scss/side-nav.scss';
import VariantsAddModal from './Components/VariantsAddModal';
import VariantsViewModal from './Components/VariantsViewModal';
import DeleteModal from '../../common/deletemodal';
import { useDispatch, useSelector } from 'react-redux';
import editIcon from '../../../assets/img/edit-icon.svg';
import {
  clearMessageVariant,
  deleteVariantsById,
  getVariantById,
  getVariantDetails,
} from './variantsmoduleSlice';
import { Notifications } from '../../../config/utils';
import CustomPagination from '../../common/CustomPagination';
import { Tooltip } from 'react-tooltip';

const Varients = () => {
  const [viewModal, setViewModal] = useState(false);
  const [addModal, setAddModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [dataId, setDataId] = useState('');
  const [showSort, setShowSort] = useState(false);
  const { variantData, successMessageVariant, errorMessage, isLoadingvariant } =
    useSelector((state) => state.variantsReducer);
  const dispatch = useDispatch();
  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: '',
    sortby: 'created_at',
    sortOrder: 'asc',
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });

  const getVariant = async () => {
    await dispatch(getVariantDetails(params));
  };

  useEffect(() => {
    getVariant();
  }, [params.page, params.search, params.sortby, params.sortOrder]);

  useEffect(() => {
    if (params.search !== '') {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  useEffect(() => {
    if (variantData?.pagination?.total) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(variantData?.pagination?.total),
        totalPages: Math.ceil(
          Number(variantData?.pagination?.total) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [variantData?.pagination?.total]);

  useEffect(() => {
    if (successMessageVariant) {
      Notifications(successMessageVariant, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageVariant());
  }, [successMessageVariant, errorMessage]);

  const handleShowView = (data) => {
    setDataId(data.id);
    setViewModal(true);
    dispatch(getVariantById(data.id));
  };
  const addModalHandler = () => {
    setShowEdit(false);
    setAddModal(true);
  };

  const handleDeleteUser = (id) => {
    setDataId(id);
    setDeleteModal(true);
  };
  const handleDelete = async () => {
    await dispatch(deleteVariantsById(dataId));
    await getVariant();
    setDeleteModal(false);
  };
  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };
  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  const handleEdit = (item) => {
    setDataId(item.id);
    setShowEdit(true);
    setAddModal(true);
    dispatch(getVariantById(item.id));
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;

  return (
    <div>
      <Tooltip id="variant-tooltip" className="tooltip" />
      <VariantsAddModal
        isShow={addModal}
        setShow={setAddModal}
        showEdit={showEdit}
        dataId={dataId}
        getVariant={getVariant}
      />
      <VariantsViewModal
        isShow={viewModal}
        setShow={setViewModal}
        viewId={dataId}
      />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Variants Management</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="searchicon" />
                </span>
              </div>

              <div className="tbl-filter-block">
                <div className="dropdown">
                  <button
                    className={`btn  ${showSort ? 'show' : ''} `}
                    type="button"
                    onClick={() => setShowSort(!showSort)}
                  >
                    <img src={filterIcon} alt="filterIcon" />
                  </button>
                  <ul
                    className={`dropdown-menu dropdown-menu-end ${
                      showSort ? 'show' : ''
                    }`}
                    onClick={() => setShowSort(!showSort)}
                  >
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'variant' &&
                          params.sortOrder === 'asc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'variant',
                            sortOrder: 'asc',
                            page:1
                          })
                        }
                      >
                        A-Z
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'variant' &&
                          params.sortOrder === 'desc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'variant',
                            sortOrder: 'desc',
                            page:1
                          })
                        }
                      >
                        Z-A
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'created_at' &&
                          params.sortOrder === 'asc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'created_at',
                            sortOrder: 'desc',
                            page:1
                          })
                        }
                      >
                        Created at
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="tbl-add-btn" onClick={addModalHandler}>
                <button
                  className="btn"
                  data-bs-toggle="modal"
                  data-bs-target="#VariantsAdd"
                >
                  <img src={plusIcon} alt="plus" />
                  <span>Add Variants</span>
                </button>
              </div>
            </div>
          </div>

          <div className="table-section custom-scroll custom-scroll-h sub-category-tbl variants-table">
            {isLoadingvariant ? (
              <tr>
                <td className="table-loader" colSpan={6}>
                  <img src={Loader} alt="" />
                </td>
              </tr>
            ) : (
              <>
                <table className="table">
                  <tbody>
                    <tr>
                      <th className="checkbox-section">
                        No.
                      </th>
                      <th>Variant Category</th>
                      <th className='variant-type-text'>Variant Type</th>
                      <th className="text-center">Number of Variants</th>
                      <th className="action text-start">Action</th>
                    </tr>
                    {variantData && variantData?.rows?.length ? (
                      variantData?.rows?.map((data, index) => (
                        <>
                          <tr key={index}>
                            <td>
                              {startSerialNumber + index}
                            </td>
                            <td>{data?.variant || '-'}</td>

                            <td>
                              {data.variant_category_names
                                .map((item) => item.variant_name)
                                .join(', ') || '-'}
                            </td>
                            <td className="text-center">
                              {data?.variant_category_names?.length || '-'}
                            </td>
                            <td>
                              <div className="action-icons">
                                <img
                                  src={view}
                                  data-tooltip-id="variant-tooltip"
                                  data-tooltip-content="View"
                                  alt="varients-view"
                                  onClick={() => handleShowView(data)}
                                />
                                <img
                                  src={editIcon}
                                  className="edit-icon"
                                  data-tooltip-id="variant-tooltip"
                                  data-tooltip-content="Edit"
                                  alt=""
                                  onClick={() => handleEdit(data)}
                                />
                                <img
                                  src={deleteicon}
                                  className="delete-icon"
                                  data-tooltip-id="variant-tooltip"
                                  data-tooltip-content="Delete"
                                  alt="delete-modal"
                                  onClick={() => handleDeleteUser(data.id)}
                                />
                              </div>
                            </td>
                          </tr>
                        </>
                      ))
                    ) : (
                      <tr>
                        <td className="text-center no-data-table" colSpan={6}>
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {variantData?.rows?.length ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Varients;
