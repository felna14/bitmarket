import { createAction, createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import serviceEndpoints from '../../../config/serviceEndPoints';
import { ResponseApiConfig } from '../../../config/utils';

export const clearMessageProducts = createAction('clearMessageProducts');

export const getProducts = createAsyncThunk(
  'products-management',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams({
      page: data.page,
      limit: data.limit,
      sortBy: data.sortby,
      sortOrder: data.sortOrder,
      search: data.search,
    });
    if (data.filter) {
      params.append('filter', data.filter);
    }
    const endPoint = `${serviceEndpoints.products}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const getProductDataById = createAsyncThunk(
  'single-product-management',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.products}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

export const deleteProductsById = createAsyncThunk(
  'delete-products',
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.products}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'delete');
  }
);

export const getExcelDataForProduct = createAsyncThunk(
  'export-excel-management-product',
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('filter', data.filter);
    params.append('type', 'products');
    if (data.search) {
      params.append("search", data.search);
    }
    
    const endPoint = `${serviceEndpoints.excel}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, 'get');
  }
);

const ProductsSlice = createSlice({
  name: 'products-management',
  initialState: {
    allProducts: '',
    singleProductData: '',
    excelData: {},
    isLoading: false,
    successMessageProduct: '',
    errorMessage: '',
    success: false,
  },
  extraReducers: (builder) => {
    builder
      .addCase(getProducts.pending, (state) => {
        state.isLoadingProducts = true;
        state.errorMessage = '';
        state.successMessage = '';
        // state.success = false;
        state.entityParams = '';
      })

      .addCase(getProducts.fulfilled, (state, { payload }) => {
        state.isLoadingProducts = false;
        // state.success = true;
        state.allProducts = payload;
        // state.successMessage = payload.message;
      })
      .addCase(getProducts.rejected, (state, { payload }) => {
        state.allProducts = '';
        state.isLoadingProducts = false;
        state.success = false;
        state.errorMessage = payload.message;
      })
      .addCase(getProductDataById.pending, (state) => {
        state.errorMessage = '';
        state.isLoading = true;
        state.successMessage = '';
      })
      .addCase(getProductDataById.fulfilled, (state, { payload }) => {
        state.singleProductData = payload;
        state.isLoading = false;
      })
      .addCase(getProductDataById.rejected, (state, { payload }) => {
        state.singleProductData = '';
        state.errorMessage = payload.message;
        state.isLoading = false;
      })
      .addCase(deleteProductsById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
        state.successMessageProduct = '';
      })
      .addCase(deleteProductsById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageProduct = payload.message;
      })
      .addCase(deleteProductsById.rejected, (state, { payload }) => {
        state.singleCustomerData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase(getExcelDataForProduct.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = '';
      })
      .addCase(getExcelDataForProduct.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.excelData = payload;
      })
      .addCase(getExcelDataForProduct.rejected, (state, { payload }) => {
        state.excelData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })
      .addCase('clearMessageProducts', (state) => {
        state.errorMessage = '';
        state.successMessageProduct = '';
        state.success = false;
      });
  },
});

export default ProductsSlice.reducer;
