/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react';

import searchIcon from '../../../assets/img/search-icon.svg';
import exporticon from '../../../assets/img/export-excel.svg';
import viewicon from '../../../assets/img/view-icon.svg';
import deleteicon from '../../../assets/img/table-delete-icon.svg';
import filtericon from '../../../assets/img/filter-filled.svg';
import fourdot from '../../../assets/img/four-square.svg';
import Loader from '../../../assets/img/Loader.gif';
import noImage from '../../../assets/img/noImage.jpg';
import nodataicon from '../../../assets/img/no_data.svg';
import excel from '../../../assets/img/export-excel.svg';

import '../../../assets/scss/dashboard.scss';
import '../../../assets/scss/customer-management.scss';
import '../../../assets/scss/table.scss';
import '../../../assets/scss/form.scss';
import '../../../assets/scss/modal.scss';
import '../../../assets/css/bootstrap.css';
import '../../../assets/scss/common.scss';
import '../../../assets/scss/side-nav.scss';

import DeleteModal from '../../common/deletemodal';
import ViewProduct from './Components/ViewProduct';
import { CommonTableHeader } from '../../common/CommonTableHeader';
import { productTableData } from '../../../config/TableData';
import { useDispatch, useSelector } from 'react-redux';
import {
  clearMessageProducts,
  deleteProductsById,
  getProductDataById,
  getProducts,
  getExcelData,
  getExcelDataForProduct,
} from '../../../components/logedAdmin/products/ProductsSlice.js';
import { Notifications } from '../../../config/utils';
import CustomPagination from '../../common/CustomPagination';
import { Tooltip } from 'react-tooltip';
import { Indexed } from 'ethers/lib/utils.js';

const Products = () => {
  const [deleteModal, setDeleteModal] = useState(false);
  const [viewmodal, setViewModal] = useState(false);
  const [filter, setFilter] = useState('');
  const [showSort, setShowSort] = useState(false);

  const {
    isLoadingProducts,
    allProducts,
    errorMessage,
    excelData,
    successMessageProduct,
  } = useSelector((state) => state.ProductsManagementReducer);

  const dispatch = useDispatch();

  const [dataId, setDataId] = useState('');

  const [params, setParams] = useState({
    limit: 10,
    page: 1,
    search: '',
    sortby: 'created_at',
    sortOrder: 'desc',
    filter: '',
  });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  useEffect(() => {
    getAllProducts();
  }, [
    params.page,
    params.search,
    params.sortby,
    params.sortOrder,
    params.filter,
  ]);

  useEffect(() => {
    if (params.search !== '') {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  useEffect(() => {
    if (allProducts?.count) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(allProducts?.count),
        totalPages: Math.ceil(
          Number(allProducts?.count) / Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [allProducts]);
  useEffect(() => {
    if (successMessageProduct) {
      Notifications(successMessageProduct, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageProducts());
  }, [successMessageProduct, errorMessage]);

  const getAllProducts = async () => {
    await dispatch(getProducts(params));
  };

  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  useEffect(() => {
    if (filter.length) {
      const data = {filter:filter,search:params.search}
      dispatch(getExcelDataForProduct(data));
    }
  }, [filter,params.search]);

  const handleDownloadExcel = () => {
    if (excelData?.filename?.url) {
      const fileName = excelData?.filename?.url.split('/').pop();
      const link = document.createElement('a');
      link.href = `https://devapi-bitmarket.spericorn.com${excelData?.filename?.url}`;
      link.setAttribute('download', `${fileName}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
  };

  const handleChageFilter = (e) => {
    const filter = e.target.value || '';
    setParams({
      ...params,
      filter: filter,
      page: 1,
    });
    setFilter(e.target.value);
  };

  const handleShowView = (item) => {
    setViewModal(true);
    setDataId(item.id);
    dispatch(getProductDataById(item.id));
  };

  const handleDeleteProduct = (item) => {
    setDataId(item.id);
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    await dispatch(deleteProductsById(dataId));
    await getAllProducts();
    setDeleteModal(false);
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;

  return (
    <>
      <Tooltip id="product-tooltip" className="tooltip" />
      <ViewProduct isShow={viewmodal} setShow={setViewModal} />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <main className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Products</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>

              <div className="tbl-filter-block">
                <div className="dropdown">
                  <button
                    className={`btn  ${showSort ? 'show' : ''} `}
                    type="button"
                    onClick={() => setShowSort(!showSort)}
                  >
                    <img src={filtericon} alt="filter" />
                  </button>
                  <ul
                    className={`dropdown-menu dropdown-menu-end ${
                      showSort ? 'show' : ''
                    }`}
                    onClick={() => setShowSort(!showSort)}
                  >
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'product_name' &&
                          params.sortOrder === 'asc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'product_name',
                            sortOrder: 'asc',
                            page: 1,
                          })
                        }
                      >
                        A-Z
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'product_name' &&
                          params.sortOrder === 'desc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'product_name',
                            sortOrder: 'desc',
                            page: 1,
                          })
                        }
                      >
                        Z-A
                      </a>
                    </li>
                    <li>
                      <a
                        className={`dropdown-item ${
                          params.sortby === 'created_at' &&
                          params.sortOrder === 'desc'
                            ? 'is-active'
                            : ''
                        }`}
                        onClick={() =>
                          setParams({
                            ...params,
                            sortby: 'created_at',
                            sortOrder: 'desc',
                            page: 1,
                          })
                        }
                      >
                        Created At
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <select
                className="form-select export-select"
                aria-label="Default select example"
                value={filter}
                onChange={(e) => handleChageFilter(e)}
              >
                <option value="" selected>
                  Select
                </option>
                <option value="today">Today</option>
                <option value="this_week">This Week</option>
                <option value="last_week">Last Week</option>
                <option value="this_month">This Month</option>
                <option value="last_month">last Month</option>
                <option value="last_six_months">Last Six Months</option>
                <option value="this_year">This Year</option>
              </select>
              <div className="tbl-add-btn">
                <button
                  className="btn"
                  data-bs-toggle="modal"
                  data-bs-target="#sub-category-management"
                  onClick={() => handleDownloadExcel()}
                >
                  <img src={excel} alt="excel" />
                  <span>Export to Excel</span>
                </button>
              </div>
            </div>
          </div>

          <div className="table-section custom-scroll  custom-scroll-h sub-category-tbl products-table">
            {isLoadingProducts ? (
              <table>
                <tbody>
                  <tr>
                    <td
                      className="table-loader"
                      colSpan={productTableData?.keys?.length + 2}
                    >
                      <img src={Loader} alt="" />
                    </td>
                  </tr>
                </tbody>
              </table>
            ) : (
              <>
                <table className="table">
                  <tbody>
                    <tr>
                      <th>
                        {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                        No.
                      </th>
                      <CommonTableHeader tableData={productTableData} />
                    </tr>
                    {allProducts?.rows?.length ? (
                      allProducts?.rows?.map((data, index) => (
                        <tr key={data.id}>
                          <td>{startSerialNumber + index}</td>
                          <td>
                            <img
                              src={
                                data?.ProductImages[0]?.product_image
                                  ? data?.ProductImages[0]?.product_image
                                  : noImage
                              }
                              className="product-img"
                              alt="product"
                            />
                          </td>
                          <td>{data?.product_name || ''}</td>
                          <td>{data?.category?.name || ''}</td>
                          <td>{data?.brand?.brand_name || ''}</td>
                          <td>{data?.vendor?.vendor_name || ''}</td>
                          <td
                            className={
                              data?.is_active === true
                                ? 'approved-txt'
                                : 'rejected-txt'
                            }
                          >
                            {data?.is_active === true ? 'Yes' : 'No' || ''}
                          </td>

                          <td>
                            <div className="action-icons">
                              <img
                                src={viewicon}
                                data-tooltip-id="product-tooltip"
                                data-tooltip-content="View"
                                alt="view-icon"
                                onClick={() => handleShowView(data)}
                              />
                              {data?.is_active &&
                              <img
                                src={deleteicon}
                                className="delete-icon"
                                data-tooltip-id="product-tooltip"
                                data-tooltip-content="Delete"
                                alt="delete-icon"
                                onClick={() => handleDeleteProduct(data)}
                              />
}
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          className="text-center no-data-table"
                          colSpan={productTableData?.keys?.length + 2}
                        >
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>
          <div className="footer-table col-md-12">
            {allProducts?.rows?.length ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
              />
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default Products;
