/* eslint-disable jsx-a11y/alt-text */
import React, { useState } from "react";
import { Modal } from "react-bootstrap";
import { useSelector } from "react-redux";

import "../../../../assets/scss/modal.scss";
import "../../../../assets/scss/profile.scss";
import Loader from "../../../../assets/img/Loader.gif";
import { formatMoney } from "../../../../config/utils";

const ViewProduct = ({ isShow, setShow }) => {
  const { singleProductData, isLoading } = useSelector(
    (state) => state.ProductsManagementReducer
  );

  const [selectVariant, setSelectedVariant] = useState("");

  const filteredByVariant = singleProductData?.result?.variants?.find(
    (d) => d.variant_name === selectVariant
  );

  const filteredImageCondition = (value) => {
    return filteredByVariant?.product_images[value]?.product_image;
  };

  const singleProductImageCondition = (value) => {
    return singleProductData?.result?.product_images[value]?.product_image;
  };

  return (
    <Modal
      show={isShow}
      className="modal fade oder-view mid product-view-modal"
      id="ProductsViewModal"
      data-bs-backdrop="static"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby="OrderViewLabel"
      aria-hidden="true"
      centered
    >
      {isLoading ? (
        <>
          <div className="loaderWrapper loader-wrapper-height ">
            <div className="table-loader">
              <img src={Loader} alt="" />
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="OrderViewLabel">
                  View Product
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                  onClick={() => {
                    setSelectedVariant("");
                    setShow(false);
                  }}
                ></button>
              </div>

              <div className="modal-body">
                <div className="outer-main">
                  <div className=" row OrderView">
                    <div className="col-md-9">
                      <div className="row oder-spc">
                        <div className="col-md-4 frm-itm">
                          <label className="form-label">Vendor Name</label>
                          <h3 className="frm-value">
                            {singleProductData?.result?.vendor?.vendor_name ||
                              "-"}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm light-red">
                          <label className="form-label">Category</label>
                          <h3 className="frm-value">
                            {singleProductData?.result?.category?.name}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm">
                          <label className="form-label">SubCategory</label>
                          <h3 className="frm-value">
                            {singleProductData?.result?.subCategory?.name}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm">
                          <label className="form-label">Product Name</label>
                          <h3 className="frm-value">
                            {singleProductData?.result?.product_name}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm light-red">
                          <label className="form-label">Brand</label>
                          <h3 className="frm-value">
                            {singleProductData?.result?.brand?.brand_name}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm light-red  ">
                          <label className="form-label">Unit</label>
                          <h3 className="frm-value">
                            {singleProductData?.result?.unit}
                          </h3>
                        </div>
                        <div className="col-md-12 frm-itm light-red txt-description">
                          <label className="form-label">Description</label>
                          <h3 className="frm-value txt-discritionWidth">
                            {singleProductData?.result?.description}
                          </h3>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-8 form-group frm-itm ">
                          <label className="form-label">Variants</label>
                          <select
                            className="form-control select"
                            onChange={(e) => setSelectedVariant(e.target.value)}
                          >
                            {singleProductData?.result?.variants.length ? (
                              <option value="">Select a Variant</option>
                            ) : null}
                            {singleProductData?.result?.variants.length ? (
                              singleProductData?.result?.variants?.map(
                                (data) => (
                                  <option value={data.variant_name}>
                                    {data.variant_name}
                                  </option>
                                )
                              )
                            ) : (
                              <option>No Variants Available</option>
                            )}
                          </select>
                        </div>
                        <div className="col-md-4 frm-itm">
                          <label className="form-label">Stock</label>
                          <h3 className="frm-value textStock">
                            {!filteredByVariant
                              ? singleProductData?.result?.stock
                              : filteredByVariant?.stock}
                          </h3>
                        </div>
                      </div>
                      <div className="head">
                        <h3 className="title">Price Details</h3>
                      </div>
                      <div className="row">
                        <div className="col-md-4 frm-itm">
                          <label className="form-label">Selling Price</label>
                          <h3 className="frm-value">
                            {!filteredByVariant
                              ? formatMoney(singleProductData?.result?.selling_price)
                              : formatMoney(filteredByVariant?.selling_price)}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm light-red">
                          <label className="form-label">Actual Price</label>
                          <h3 className="frm-value">
                            {!filteredByVariant
                              ? formatMoney(singleProductData?.result?.actual_price)
                              : formatMoney(filteredByVariant?.actual_price)}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm light-red">
                          <label className="form-label">Discount Price</label>
                          <h3 className="frm-value">
                            {!filteredByVariant
                              ?formatMoney(singleProductData?.result?.discount_price)
                              :formatMoney(filteredByVariant?.discount_price)}
                          </h3>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-3 oder-img">
                      <div className="oder-preview">
                        {filteredImageCondition(0) ||
                        singleProductImageCondition(0) ? (
                          <div>
                            <h4 className="title">Main Image</h4>
                            <div className="main-Image">
                              <img
                                src={
                                  filteredImageCondition(0)
                                    ? filteredImageCondition(0)
                                    : singleProductImageCondition(0)
                                }
                                className="main-pro-img"
                                alt="No Preview"
                              />
                            </div>
                          </div>
                        ) : null}

                        {selectVariant === "" &&
                        singleProductImageCondition(1) ? (
                          <h4 className="title">Secondary Images</h4>
                        ) : selectVariant !== "" &&
                          filteredImageCondition(1) ? (
                          <h4 className="title">Secondary Images</h4>
                        ) : null}

                        <div className="secondary-Image-list">
                          {selectVariant === "" &&
                          singleProductImageCondition(1) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={singleProductImageCondition(1)}
                                className="secondary-pro-img"
                              />
                            </div>
                          ) : null}

                          {selectVariant !== "" && filteredImageCondition(1) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={filteredImageCondition(1)}
                                className="secondary-pro-img"
                              />
                            </div>
                          ) : null}

                          {selectVariant === "" &&
                          singleProductImageCondition(2) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={singleProductImageCondition(2)}
                                className="secondary-pro-img"
                                alt=""
                              />
                            </div>
                          ) : null}

                          {selectVariant !== "" && filteredImageCondition(2) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={filteredImageCondition(2)}
                                className="secondary-pro-img"
                                alt=""
                              />
                            </div>
                          ) : null}

                          {selectVariant === "" &&
                          singleProductImageCondition(3) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={singleProductImageCondition(3)}
                                className="secondary-pro-img"
                                alt=""
                              />
                            </div>
                          ) : null}

                          {selectVariant !== "" && filteredImageCondition(3) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={filteredImageCondition(3)}
                                className="secondary-pro-img"
                                alt=""
                              />
                            </div>
                          ) : null}

                          {selectVariant === "" &&
                          singleProductImageCondition(4) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={singleProductImageCondition(4)}
                                className="secondary-pro-img"
                                alt=""
                              />
                            </div>
                          ) : null}

                          {selectVariant !== "" && filteredImageCondition(4) ? (
                            <div className="secondary-Image-item">
                              <img
                                src={filteredImageCondition(4)}
                                className="secondary-pro-img"
                                alt=""
                              />
                            </div>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
};

export default ViewProduct;
