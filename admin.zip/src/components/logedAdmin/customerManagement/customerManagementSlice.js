import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
// import bitMarketGateway from '../../../config/service';
import serviceEndpoints from "../../../config/serviceEndPoints";
import { ResponseApiConfig } from "../../../config/utils";

export const clearMessageCustomer = createAction("clearMessageCustomer");
export const getCustomerDetails = createAsyncThunk(
  "customer-management",
  async (data, { rejectWithValue }) => {
    const params = new URLSearchParams();
    params.append('page', data.page);
    params.append('limit', data.limit);
    params.append('search', data.search);
    
    const endPoint = `${serviceEndpoints.customer_list}?${params.toString()}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const getCustomerDataById = createAsyncThunk(
  "single-customer-management",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.customer_management}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "get");
  }
);

export const blockToggleById = createAsyncThunk(
  "block-user-customer",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.customer_status}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "put");
  }
);

export const deleteUserById = createAsyncThunk(
  "delete-customer",
  async (id, { rejectWithValue }) => {
    const endPoint = `${serviceEndpoints.customer_management}/${id}`;
    return ResponseApiConfig(rejectWithValue, endPoint, "delete");
  }
);

export const editCustomerDatabyId = createAsyncThunk(
  "single-customer-management-edit",
  async (data, { rejectWithValue }) => {
    const { editId, ...body } = data;
    const formData = new FormData();

    body?.profile_image && body?.profile_image?.length !== 0 && formData.append("profile_image", body.profile_image);
    formData.append("first_name", body.first_name);
    formData.append("last_name", body.last_name);
    formData.append("phone", body.phone);
    formData.append("email", body.email);
    formData.append("line1", body.line1);
    formData.append("country", body.country);
    formData.append("state", body.state);
    formData.append("city", body.city);
    formData.append("postal_code", body.postal_code);
    formData.append("platform", "web");

    body.address_id && formData.append("address_id", body.address_id);
    const headers = {
      "Content-Type": "multipart/form-data",
    };
    const endPoint = `${serviceEndpoints.customer_management}/${editId}`;
    return ResponseApiConfig(
      rejectWithValue,
      endPoint,
      "put",
      formData,
      headers
    );

  }
);

const customerManagementSlice = createSlice({
  name: "customer-management",
  initialState: {
    customerData: {},
    success: false,
    isLoadingcustomer: false,
    isLoading:false,
    errorMessage: "",
    successMessageCustomer: "",
    singleCustomerData: "",
  },

  extraReducers: (builder) => {
    builder
      .addCase(getCustomerDetails.pending, (state) => {
        state.isLoadingcustomer = true;
        state.errorMessage = "";
        state.success = false;
      })

      .addCase(getCustomerDetails.fulfilled, (state, { payload }) => {
        state.isLoadingcustomer = false;
        state.success = true;
        state.customerData = payload;
      })
      .addCase(getCustomerDetails.rejected, (state, { payload }) => {
        state.customerData = {};
        state.isLoadingcustomer = false;
        state.success = false;
        state.errorMessage = payload.message;
      })
      .addCase(getCustomerDataById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
      })
      .addCase(getCustomerDataById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.singleCustomerData = payload;
      })
      .addCase(getCustomerDataById.rejected, (state, { payload }) => {
        state.singleCustomerData = {};
        state.isLoading = false;
      })

      .addCase(deleteUserById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageCustomer = "";
      })
      .addCase(deleteUserById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageCustomer = payload.message;
      })
      .addCase(deleteUserById.rejected, (state, { payload }) => {
        state.singleCustomerData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })

      .addCase(editCustomerDatabyId.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageCustomer = "";
      })
      .addCase(editCustomerDatabyId.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageCustomer = payload.message;
      })
      .addCase(editCustomerDatabyId.rejected, (state, { payload }) => {
        state.singleCustomerData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })

      .addCase(blockToggleById.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessageCustomer = "";
      })
      .addCase(blockToggleById.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.successMessageCustomer = payload.message;
      })
      .addCase(blockToggleById.rejected, (state, { payload }) => {
        state.singleCustomerData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
      })

      .addCase("clearMessageCustomer", (state) => {
        state.errorMessage = "";
        state.successMessageCustomer = "";
        state.success = false;
      });
  },
});

export default customerManagementSlice.reducer;
