import React, { useEffect, useState } from 'react';
import searchIcon from '../../../assets/img/search-icon.svg';
import viewicon from '../../../assets/img/view-icon.svg';
import editIcon from '../../../assets/img/edit-icon.svg';
import blockicon from '../../../assets/img/block-icon.svg';
import deleteicon from '../../../assets/img/table-delete-icon.svg';
import unBlockIcon from '../../../assets/img/unblocked-icon.svg';
import ViewModal from './Components/ViewModal';
import EditModal from './Components/EditModal';
import fourdot from '../../../assets/img/four-square.svg';

import '../../../assets/css/bootstrap.css';
import '../../../assets/scss/customer-management.scss';
import '../../../assets/scss/table.scss';
import '../../../assets/scss/form.scss';
import '../../../assets/scss/modal.scss';

import DeleteModal from '../../common/deletemodal';
import { useDispatch, useSelector } from 'react-redux';
import {
  blockToggleById,
  clearMessageCustomer,
  deleteUserById,
  getCustomerDataById,
  getCustomerDetails,
} from './customerManagementSlice';
import CustomPagination from '../../common/CustomPagination';
import { CommonTableHeader } from '../../common/CommonTableHeader';
import { customerTableData } from '../../../config/TableData';
import { Tooltip } from 'react-tooltip';
import { Notifications } from '../../../config/utils';
import ConfirmationModal from '../../common/ConfirmationModal';
import Loader from '../../../assets/img/Loader.gif';
import nodataicon from '../../../assets/img/no_data.svg';

const CustomerManagement = () => {
  const [viewModal, setViewModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [dataId, setDataId] = useState('');
  const [blockModal, setBlockModal] = useState(false);
  const [isStatusUser, setStatusUser] = useState(false);
  const {
    customerData,
    successMessageCustomer,
    errorMessage,
    isLoadingcustomer,
  } = useSelector((state) => state.customerManagementReducer);
  const dispatch = useDispatch();
  const [params, setParams] = useState({ limit: 10, page: 1, search: '' });
  const [paginationParams, setPaginationParams] = useState({
    totalPages: 0,
    perPage: 10,
    currentPage: 0,
    totalCount: 0,
  });
  useEffect(() => {
    getCustomer();
  }, [params.page, params.search]);

  useEffect(() => {
    if (params.search !== '') {
      params.page = 1;
      paginationParams.currentPage = 1;
    }
  }, [params.search]);

  // const CustomerName =
  //   customerData &&
  //   customerData?.customers?.rows?.filter((d) =>
  //     d.customer?.first_name
  //       ?.toLowerCase()
  //       .includes(params.search?.toLowerCase())
  //   );

  useEffect(() => {
    if (customerData?.customers?.count) {
      setPaginationParams({
        ...paginationParams,
        totalCount: Number(customerData?.customers?.count),
        totalPages: Math.ceil(
          Number(customerData?.customers?.count) /
            Number(paginationParams?.perPage) || 1
        ),
      });
    }
  }, [customerData.customers]);
  useEffect(() => {
    if (successMessageCustomer) {
      Notifications(successMessageCustomer, 'success');
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageCustomer());
    return () => {
      dispatch(clearMessageCustomer());
    };
  }, [successMessageCustomer, errorMessage]);

  const getCustomer = async () => {
    await dispatch(getCustomerDetails(params));
  };
  const handlePageClick = async (page) => {
    await setPaginationParams({
      ...paginationParams,
      currentPage: Number(page),
    });
    setParams({
      ...params,
      page: Number(page) + 1,
    });
  };

  const handleSearch = async (e) => {
    setParams({
      ...params,
      search: e.target.value,
    });
  };

  const handleShowView = (item) => {
    setDataId(item.id);
    setViewModal(true);
    dispatch(getCustomerDataById(item.id));
  };

  const handleEdit = (item) => {
    setDataId(item.id);
    dispatch(getCustomerDataById(item.id));
    setEditModal(true);
  };
  const handleBlock = async () => {
    await dispatch(blockToggleById(dataId));
    await getCustomer();
    setBlockModal(false);
  };

  const handleBlockUser = (id, status) => {
    setDataId(id);
    setBlockModal(true);
    setStatusUser(status);
  };

  const handleDeleteUser = (id) => {
    setDataId(id);
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    await dispatch(deleteUserById(dataId));
    await getCustomer();
    setDeleteModal(false);
  };
  const itemsPerPage = 10;
  const startSerialNumber = (params.page - 1) * itemsPerPage + 1;
  return (
    <>
      <ViewModal
        viewId={dataId}
        isShow={viewModal}
        setShow={setViewModal}
        getCustomer={getCustomer}
      />
      <EditModal
        isShow={editModal}
        editId={dataId}
        setShow={setEditModal}
        getCustomer={getCustomer}
      />
      <DeleteModal
        isShow={deleteModal}
        setDeleteModal={setDeleteModal}
        handleDelete={handleDelete}
      />
      <ConfirmationModal
        isShow={blockModal}
        setBlockModal={setBlockModal}
        handleConfirm={handleBlock}
        isStatus={isStatusUser}
      />
      <div className="content-block custom-scroll">
        <div className="right-section-outer">
          <div className="top-title-section">
            <div className="title-text">
              <h3>Customer Management</h3>
            </div>
            <div className="right-filter">
              <div className="input-group search-filter">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={(e) => handleSearch(e)}
                />
                <span className="input-group-text">
                  <img src={searchIcon} alt="search-icon" />
                </span>
              </div>
            </div>
          </div>
          <div className="table-section custom-scroll custom-scroll-h customer-table">
            {isLoadingcustomer ? (
              <tr>
                <td
                  className="table-loader"
                  colSpan={customerTableData?.keys?.length + 2}
                >
                  <img src={Loader} alt="" />
                </td>
              </tr>
            ) : (
              <>
                <table className="table">
                  <tbody>
                    <tr>
                      <th>
                        {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                        No.
                      </th>

                      <CommonTableHeader tableData={customerTableData} />
                    </tr>

                    {customerData?.customers?.rows?.length ? (
                      customerData?.customers?.rows?.map((item, index) => (
                        <tr key={index}>
                          <td>
                            {startSerialNumber + index}
                            {/* <img src={fourdot} className="tbl-icon" alt="" /> */}
                          </td>
                          <td onClick={() => handleShowView(item)}>
                            <span className="cursor-pointer">
                              {item?.customer?.first_name || ''}
                            </span>
                          </td>
                          <td>{item?.customer?.last_name || ''}</td>
                          <td>{item?.email || ''}</td>
                          <td>{item.phone || ''}</td>
                          <td>
                            <div className="action-icons ">
                              <img
                                src={viewicon}
                                className="view-icon"
                                data-tooltip="view"
                                data-tooltip-id="customer-tooltip"
                                data-tooltip-content="View"
                                alt=""
                                onClick={() => handleShowView(item)}
                              />
                              <img
                                src={editIcon}
                                className="edit-icon"
                                data-tooltip-id="customer-tooltip"
                                data-tooltip-content="Edit"
                                alt=""
                                onClick={() => handleEdit(item)}
                              />
                              <img
                                src={
                                  item?.customer?.is_active
                                    ? unBlockIcon
                                    : blockicon
                                }
                                data-tooltip-id="customer-tooltip"
                                data-tooltip-content={
                                  item?.customer?.is_active
                                    ? 'Unblocked'
                                    : 'Blocked'
                                }
                                className="block-icon"
                                onClick={() =>
                                  handleBlockUser(
                                    item.id,
                                    item?.customer?.is_active
                                  )
                                }
                                alt=""
                              />
                              <img
                                src={deleteicon}
                                data-tooltip-id="customer-tooltip"
                                data-tooltip-content="Delete"
                                className="delete-icon"
                                alt="delete"
                                onClick={() => handleDeleteUser(item.id)}
                              />
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          className="text-center no-data-table"
                          colSpan={customerTableData?.keys?.length + 2}
                        >
                          <img
                            src={nodataicon}
                            className="no-data-table-img"
                            alt=""
                          />
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </>
            )}
          </div>

          <div className="footer-table col-md-12">
            {customerData?.customers?.rows?.length ? (
              <CustomPagination
                currentPage={params?.page}
                totalPages={paginationParams?.totalPages}
                onPageChange={handlePageClick}
                totalCount={paginationParams.totalCount}
              />
            ) : null}
          </div>
        </div>
      </div>
      <Tooltip id="customer-tooltip" className="tooltip" />
    </>
  );
};

export default CustomerManagement;
