export const customerTableData = {
    keys:["First Name","Last Name","Email Id","Phone Number"]
}
export const categoryTableData = {
    keys:["Image","Name","Description",]
}
export const subCategoryTableData = {
    keys:["Image","Category","Subcategory","Description",]
}