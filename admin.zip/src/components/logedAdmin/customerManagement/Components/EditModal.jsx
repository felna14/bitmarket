import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import "../../../../assets/scss/modal.scss";
import profileimg from "../../../../assets/img/avatar.jpeg";
import galleryimport from "../../../../assets/img/gallery-import.svg";
import warndngr from "../../../../assets/img/warn-dngr.svg";
import { Field, Formik, ErrorMessage, Form } from "formik";
import * as yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { parsePhoneNumberFromString } from "libphonenumber-js";
import {
  clearMessageCustomer,
  editCustomerDatabyId,
  getCustomerDataById,
} from "../customerManagementSlice";
import { Notifications } from "../../../../config/utils";
import Loader from "../../../../assets/img/Loader.gif";

const EditModal = ({ isShow, setShow, getCustomer, editId }) => {
  const dispatch = useDispatch();
  const [previewUrl, setPreview] = useState("");
  const {
    singleCustomerData,
    successMessageCustomer,
    errorMessage,
    isLoading,
  } = useSelector((state) => state.customerManagementReducer);

  const initialValues = {
    first_name: singleCustomerData?.customer?.customer?.first_name || "",
    last_name: singleCustomerData?.customer?.customer?.last_name || "",
    email: singleCustomerData?.customer?.email || "",
    phone: singleCustomerData?.customer?.phone || "",
    line1: singleCustomerData?.customer?.customer?.addresses[0]?.line1 || "",
    country:
      singleCustomerData?.customer?.customer?.addresses[0]?.country || "",
    state: singleCustomerData?.customer?.customer?.addresses[0]?.state || "",
    city: singleCustomerData?.customer?.customer?.addresses[0]?.city || "",
    postal_code:
      singleCustomerData?.customer?.customer?.addresses[0]?.postal_code || "",
    profile_image: "",
    address_id: singleCustomerData?.customer?.customer?.addresses[0]?.id,
    platform: "web",
  };

  useEffect(() => {
    if (successMessageCustomer) {
      Notifications(successMessageCustomer, "success");
    }
    if (errorMessage) {
      Notifications(errorMessage, "error");
    }
    dispatch(clearMessageCustomer());
  }, [successMessageCustomer, errorMessage]);

  const handleSubmit = async (event) => {
    const data = { ...event, editId: editId };
    await dispatch(editCustomerDatabyId(data));
    dispatch(getCustomerDataById(editId));
    await getCustomer();
    setShow(false);
    setPreview("");
  };

  const handleFileChange = (event, setFieldValue) => {
    if (event?.target?.files[0]?.size > 10e6) {
      Notifications("Please upload a file smaller than 10 MB", "error");
    } else {
      const files = event.target.files[0];
      setFieldValue("profile_image", files);
      setPreview(URL.createObjectURL(files));
    }
  };
  return (
    <>
      <Modal
        show={isShow}
        className="modal fade cust-man mid cust-mng-editLabel-modal"
        id="cust-mng-edit"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="cust-mng-editLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="modal-dialog-centered">
              <div className="edit-modal-Customer">
                <div className="modal-header">
                  <h5 className="modal-title" id="cust-mng-editLabel">
                    Edit Customer
                  </h5>
                  {/* <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={() => {
                  setShow(false);
                  setPreview('');
                }}
              ></button> */}
                </div>
                <Formik
                  initialValues={initialValues}
                  validationSchema={yup.object({
                    first_name: yup
                      .string()
                      .test(
                        "no-numbers-special-characters",
                        "First Name Should Only Contain Letters",
                        (value) => {
                          return /^[a-zA-Z]+$/.test(value);
                        }
                      )
                      .trim("First Name without spaces")
                      .required("First Name is Required"),
                    last_name: yup
                      .string()
                      .test(
                        "no-numbers-special-characters",
                        "Last Name Should Only Contain Letters",
                        (value) => {
                          return /^[a-zA-Z]+$/.test(value);
                        }
                      )
                      .trim("Last Name without spaces")
                      .required("Last Name is Required"),
                    line1: yup
                      .string()
                      .trim("Address without spaces")
                      .required("Address is Required"),
                    email: yup
                      .string()
                      .required("Email Id is Required")
                      .email("Invalid Email ID"),
                    phone: yup
                      .string()
                      .test("Invalid Phone Number", (value) => {
                        if (!value) {
                          return false;
                        }
                        const phoneNumber = parsePhoneNumberFromString(value);
                        return phoneNumber ? phoneNumber.isValid() : false;
                      })
                      .matches(
                        /^[0-9+]+$/,
                        "Phone Number must contain only numbers"
                      )
                      .required("Phone Number is Required"),

                    country: yup
                      .string()
                      .trim("Country without spaces")
                      .required("Country is Required"),
                    state: yup
                      .string()
                      .trim("State without spaces")
                      .required("State is Required"),
                    city: yup
                      .string()
                      .trim("City without spaces")
                      .required("City is Required"),
                    postal_code: yup
                      .string()
                      .trim("Postal Code without spaces")
                      .required("Postal Code is Required"),
                  })}
                  enableReinitialize
                  onSubmit={(values) => {
                    handleSubmit(values);
                  }}
                >
                  {({ values, setFieldValue, isSubmitting }) => (
                    <Form>
                      <div className="modal-body">
                        <div className="outer-main">
                          <div className="col-lg-3 profile-img-up">
                            <label className="form-label"> Upload Image</label>
                            <div className="profile-img">
                              <img
                                src={
                                  previewUrl.length
                                    ? previewUrl
                                    : singleCustomerData?.customer
                                        ?.profile_image || profileimg
                                }
                                className="Vendor-pic-block"
                                alt="Preview"
                              />
                              <div className="upload-btn">
                                <Field name="profile_image">
                                  {({ field }) => (
                                    <>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        id="profile_image"
                                        className="file-input__input"
                                        title=""
                                        onChange={(event) =>
                                          handleFileChange(event, setFieldValue)
                                        }
                                      />
                                    </>
                                  )}
                                </Field>
                                <img src={galleryimport} alt="" />
                              </div>
                            </div>
                          </div>

                          <div className="col-lg-9 profile-data-main">
                            <div className=" row profile-data">
                              <div className="col-md-6 form-group frm-itm">
                                <label className="form-label">
                                  {" "}
                                  First Name
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="text"
                                  name="first_name"
                                  className="form-control"
                                  placeholder=" Enter First Name"
                                />
                                <ErrorMessage
                                  name="first_name"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>
                              <div className="col-md-6 form-group frm-itm">
                                <label className="form-label">
                                  Last Name
                                  <span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="text"
                                  name="last_name"
                                  className="form-control"
                                  placeholder=" Enter Last Name"
                                />
                                <ErrorMessage
                                  name="last_name"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>
                              <div className="col-md-6 form-group frm-itm">
                                <label className="form-label">
                                  {" "}
                                  Email ID<span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="email"
                                  name="email"
                                  className="form-control cursor-not-allowed"
                                  placeholder="Enter Email ID"
                                  disabled={true}
                                />
                                <ErrorMessage
                                  name="email"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>
                              <div className="col-md-6 form-group frm-itm tel">
                                <label className="form-label">
                                  {" "}
                                  Phone Number
                                  <span className="text-danger">*</span>
                                </label>
                                <div className="phone-number">
                                  {/* <input
                                type="tel"
                                className="form-control code-sec"
                                placeholder="+91"
                              /> */}
                                  <Field
                                    type="text"
                                    name="phone"
                                    maxlength="14"
                                    minlength="7"
                                    className="form-control"
                                    placeholder="Enter Phone Number"
                                  />
                                </div>
                                <ErrorMessage
                                  name="phone"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>
                              <div className="col-md-12 form-group frm-itm address">
                                <label className="form-label">
                                  {" "}
                                  Address<span className="text-danger">*</span>
                                </label>

                                <Field
                                  name="line1"
                                  as="textarea"
                                  className="form-control"
                                  placeholder="Type Here.."
                                ></Field>

                                <ErrorMessage
                                  name="line1"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-6 form-group frm-itm tel">
                                <label className="form-label">
                                  City<span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="text"
                                  name="city"
                                  className="form-control"
                                  placeholder="City"
                                />
                                <ErrorMessage
                                  name="city"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-6 form-group frm-itm tel">
                                <label className="form-label">
                                  State<span className="text-danger">*</span>
                                </label>
                                <Field
                                  type="text"
                                  name="state"
                                  className="form-control"
                                  placeholder="State"
                                />
                                <ErrorMessage
                                  name="state"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-6 form-group frm-itm tel">
                                <label className="form-label">
                                  Country<span className="text-danger">*</span>
                                </label>

                                <Field
                                  type="text"
                                  name="country"
                                  className="form-control"
                                  placeholder="Country"
                                />
                                <ErrorMessage
                                  name="country"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>

                              <div className="col-md-6 form-group frm-itm tel">
                                <label className="form-label">
                                  Postal Code
                                  <span className="text-danger">*</span>
                                </label>

                                <Field
                                  type="text"
                                  name="postal_code"
                                  className="form-control"
                                  placeholder="Postal Code"
                                />
                                <ErrorMessage
                                  name="postal_code"
                                  render={(msg) => (
                                    <span className="val-msg">
                                      <img src={warndngr} alt="" />
                                      {msg}
                                    </span>
                                  )}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="modal-footer">
                        <div className="btn-area">
                          <button
                            type="button"
                            className="btn btn-cus btn-cancel"
                            onClick={() => {
                              setShow(false);
                              setPreview("");
                            }}
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            disabled={isSubmitting}
                            className="btn btn-cus btn-save"
                          >
                            {isSubmitting ? (
                              <span
                                class="spinner-border spinner-border-sm"
                                role="status"
                                aria-hidden="true"
                              ></span>
                            ) : (
                              "Save"
                            )}
                          </button>
                        </div>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </div>
          </>
        )}
      </Modal>
    </>
  );
};

export default EditModal;
