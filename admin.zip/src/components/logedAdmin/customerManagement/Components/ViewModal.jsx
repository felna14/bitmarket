import React, { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import "../../../../assets/scss/modal.scss";
import profileimg from "../../../../assets/img/avatar.jpeg";
import deletepng from "../../../../assets/img/delete-icon.svg";
import editpng from "../../../../assets/img/edit-pen-icon.svg";
import blockpng from "../../../../assets/img/block-white.svg";
import Deletemodal from "../../../common/deletemodal";
import EditModal from "./EditModal";
import { useDispatch, useSelector } from "react-redux";
import { blockToggleById, deleteUserById } from "../customerManagementSlice";
import ConfirmationModal from "../../../common/ConfirmationModal";
import Loader from "../../../../assets/img/Loader.gif";

const ViewModal = ({ isShow, setShow, viewId, getCustomer }) => {
  const [deleteModal, setDeleteModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [blockModal, setBlockModal] = useState(false);
  const [isStatusUser, setStatusUser] = useState(false);
  const dispatch = useDispatch();
  const { singleCustomerData, isLoading } = useSelector(
    (state) => state.customerManagementReducer
  );

  const { city, country, state, postal_code, line1 } =
    singleCustomerData?.customer?.customer?.addresses[0] ?? {};
  const handleEdit = () => {
    setEditModal(true);
  };
  const handleShowDelete = async () => {
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    await dispatch(deleteUserById(viewId));
    await getCustomer();
    setDeleteModal(false);
    setShow(false);
  };

  const handleBlock = async () => {
    await dispatch(blockToggleById(viewId));
    await getCustomer();

    setBlockModal(false);
    setShow(false);
  };

  const handleBlockUser = (status) => {
    setBlockModal(true);
    setStatusUser(status);
  };

  return (
    <>
      <Deletemodal
        isShow={deleteModal}
        handleDelete={handleDelete}
        setDeleteModal={setDeleteModal}
      />
      <EditModal
        isShow={editModal}
        setShow={setEditModal}
        editId={viewId}
        getCustomer={getCustomer}
      />
      <ConfirmationModal
        isShow={blockModal}
        setBlockModal={setBlockModal}
        handleConfirm={handleBlock}
        isStatus={isStatusUser}
      />
      <Modal
        show={isShow}
        className="fade cust-man mid"
        id="cust-mng-view"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="cust-mng-viewLabel"
        aria-hidden="true"
        centered
      >
        {isLoading ? (
          <>
            <div className="loaderWrapper loader-wrapper-height ">
              <div className="table-loader">
                <img src={Loader} alt="" />
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="modal-dialog-centered">
              <div className="w-100">
                <div className="modal-header">
                  <h5 className="modal-title" id="cust-mng-viewLabel">
                    View Customer Details
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => {
                      setShow(false);
                    }}
                  ></button>
                </div>

                <div className="modal-body">
                  <div className="outer-main">
                    <div className="col-lg-3 profile-img-view">
                      <div className="profile-img">
                        <img
                          src={
                            singleCustomerData?.customer?.profile_image ||
                            profileimg
                          }
                          alt=""
                        />
                      </div>
                    </div>

                    <div className="col-lg-9 profile-data-main">
                      <div className="row profile-data">
                        <div className="col-md-4 frm-itm">
                          <label className="form-label"> First Name</label>
                          <h3 className="frm-value">
                            {singleCustomerData?.customer?.customer
                              ?.first_name || "-"}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm">
                          <label className="form-label"> Last Name</label>
                          <h3 className="frm-value">
                            {singleCustomerData?.customer?.customer
                              ?.last_name || "-"}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm">
                          <label className="form-label"> Email ID</label>
                          <h3 className="frm-value">
                            {singleCustomerData?.customer?.email || "-"}
                          </h3>
                        </div>
                        <div className="col-md-8 frm-itm ">
                          <label className="form-label"> Address</label>
                          <h3 className="frm-value">
                            {line1 ? line1 + ", " : ""}
                            {city ? city + ", " : ""}
                            {state ? state + " -" : ""}
                            {postal_code ? postal_code + ", " : ""}
                            {country ? country : "-"}
                          </h3>
                        </div>
                        <div className="col-md-4 frm-itm">
                          <label className="form-label"> Phone Number</label>
                          <h3 className="frm-value">
                            {singleCustomerData?.customer?.phone || "-"}
                          </h3>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <div className="btn-area">
                    <button
                      type="button"
                      className="btn btn-cus"
                      data-tooltip="Delete"
                      onClick={() => handleShowDelete()}
                    >
                      <img src={deletepng} alt="" /> Delete
                    </button>
                    <button
                      type="button"
                      data-tooltip="Edit"
                      className="btn btn-cus edit-Button"
                      onClick={() => {
                        handleEdit();
                      }}
                    >
                      <img src={editpng} alt="" /> Edit
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        handleBlockUser(
                          singleCustomerData?.customer?.customer?.is_active
                        )
                      }
                      className={
                        !singleCustomerData?.customer?.customer?.is_active
                          ? "btn btn-cus btn-green"
                          : "btn btn-cus btn-red"
                      }
                    >
                      <img title="Block" src={blockpng} alt="" />
                      {!singleCustomerData?.customer?.customer?.is_active
                        ? "UnBlock"
                        : "Block"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </Modal>
    </>
  );
};

export default ViewModal;
