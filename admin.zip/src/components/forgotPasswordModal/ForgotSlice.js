import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import axios from "axios";
export const clearMessageForgot = createAction("clearMessageForgot");
export const getForgotDetails = createAsyncThunk(
  "auth/forgot-password",
  async (data, { rejectWithValue }) => {
    const body = { ...data };
    try {
      const response = await axios.post(
        `https://devapi-bitmarket.spericorn.com/api/auth/forgot-password`,
        body
      );
      if (response.status < 200 || response.status >= 300) {
        return rejectWithValue(response.data);
      }
      return response.data;
    } catch (error) {
      if (error.response && error.response.status === 401 ||  error.response.status === 400) {
        return rejectWithValue(error.response.data);
      } else {
        throw error;
      }
    }
  }
);

const forgotslice = createSlice({
  name: "forgot",
  initialState: {
    forgotData: {},
    isLoading: false,
    errorMessage:"",
    successMessage:""
  },

  extraReducers: (builder) => {
    builder
      .addCase(getForgotDetails.pending, (state) => {
        state.isLoading = true;
        state.errorMessage = "";
        state.successMessage = "";
      })

      .addCase(getForgotDetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.forgotData = payload;
        state.successMessage = payload.message
      })
      .addCase(getForgotDetails.rejected, (state,{payload}) => {
        state.forgotData = {};
        state.isLoading = false;
        state.errorMessage = payload.message;
        
      })
      .addCase("clearMessageForgot", (state) => {
        state.errorMessage = "";
        state.successMessage = "";
      });
  },
});

export default forgotslice.reducer;
