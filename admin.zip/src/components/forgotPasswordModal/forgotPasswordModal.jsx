import React, { useEffect } from 'react';
import { Modal } from 'react-bootstrap';
import { Field, Formik, ErrorMessage, Form } from 'formik';
import * as yup from 'yup';
import frgtmail from '../../assets/img/frgt-mail.svg';
import fgtblock from '../../assets/img/fgt-block.svg';
import logmail from '../../assets/img/log-mail.svg';
import warndngr from '../../assets/img/warn-dngr.svg';
import { useDispatch, useSelector } from 'react-redux';
import { clearMessageForgot, getForgotDetails } from './ForgotSlice';
import { Notifications } from '../../config/utils';

const ForgotPasswordModal = ({ isShow, setShow }) => {
  const dispatch = useDispatch();
  const { successMessage, errorMessage } = useSelector(
    (state) => state?.forgotmodalReducer
  );
  const handleSubmit = (values) => {
    dispatch(getForgotDetails(values));
  };
  useEffect(() => {
    if (successMessage) {
      Notifications(
        'We have sent a reset password link to your email ',
        'success'
      );
      setShow(false);
    }
    if (errorMessage) {
      Notifications(errorMessage, 'error');
    }
    dispatch(clearMessageForgot());
  }, [successMessage, errorMessage]);

  return (
    <>
      <Modal
        show={isShow}
        className="modal fade modal-login"
        id="forgotPassword"
        data-bs-keyboard="false"
        tabIndex="-1"
        aria-labelledby="forgotPasswordLabel"
        aria-hidden="true"
        centered
      >
        <Formik
          initialValues={{
            email: '',
            role: 'Admin',
          }}
          validationSchema={yup.object({
            email: yup
              .string()
              .required('Email ID is Required')
              .email('Invalid Email ID')
              .typeError('Must be a Text'),
          })}
          onSubmit={(values, { resetForm }) => {
            handleSubmit(values);
            // resetForm({ values: "" });
          }}
        >
          <div className="modal-lg modal-dialog-centered">
            <div className="modal-body">
              <Form className="form-block-cover form-block-cover-pswd">
                <button
                  type="button"
                  className="btn-close forgot-close"
                  onClick={() => {
                    setShow(false);
                  }}
                ></button>
                <div className="form-title">
                  <img src={frgtmail} alt="" />
                  Forgot Password ?
                </div>
                <div className="form-img-block">
                  <img src={fgtblock} alt="" />
                </div>
                <div className="form-container">
                  <div className="cutom-form-control">
                    <label htmlFor="Email ID" className="form-label">
                      Email ID<span className="text-danger">*</span>
                    </label>
                    <div className="input-group cutom-input-group">
                      <span className="input-group-text" id="basic-addon1">
                        <img src={logmail} alt="" />
                      </span>
                      <Field
                        name="email"
                        type="text"
                        className="form-control"
                        placeholder="Enter Email ID"
                        aria-label="Email ID"
                        aria-describedby="basic-addon1"
                      />
                      <ErrorMessage
                        name="email"
                        render={(msg) => (
                          <span className="val-msg">
                            <img src={warndngr} alt="" /> {msg}
                          </span>
                        )}
                      />
                    </div>
                  </div>

                  <div className="btn-wrapper d-flex">
                    <button
                      type="button"
                      className="btn-def btn-cancel"
                      onClick={() => {
                        setShow(false);
                      }}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="btn-def btn-submit">
                      Submit
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </Formik>
      </Modal>
    </>
  );
};

export default ForgotPasswordModal;
