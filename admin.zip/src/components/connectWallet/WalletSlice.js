import { createSlice } from '@reduxjs/toolkit';

const WalletSlice = createSlice({
  name: 'wallet-slice',
  initialState: {
    AddressOfWallet: null,
    selectedWalletData: null,
    web3Object: null,
  },
  reducers: {
    AddWalletAddress: (state, { payload }) => {
      state.AddressOfWallet = payload;
      if (payload !== undefined) {
        localStorage.setItem('wallet_address', JSON.stringify(payload));
      }
    },
    AddSelectedWallet: (state, { payload }) => {
      state.selectedWalletData = payload;
    },
    disconnectWallet: (state) => {
      state.AddressOfWallet = null;
      localStorage.removeItem('wallet_address');
      state.web3Object= null;
    },
    newWeb3ObjectAction: (state, { payload }) => {
      state.web3Object = payload;
    },
  },
});

export const {
  AddWalletAddress,
  AddSelectedWallet,
  disconnectWallet,
  newWeb3ObjectAction,
} = WalletSlice.actions;
export default WalletSlice.reducer;
