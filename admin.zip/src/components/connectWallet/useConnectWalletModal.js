// import {
//   DEFAULT_NETWORK,
//   CHAIN_ID,
//   checkNetwork,
//   getweb3Provider,
// } from '../../modules/blockchainNetwork';

import getweb3Provider from '../Contractor/web3Provider';
import { DEFAULT_NETWORK, CHAIN_ID, checkNetwork } from '../Contractor';
import coinbaseProvider from '../Contractor/coinBase/coinbaseProvider';
import metaMaskProvider from '../Contractor/metamask/metaMaskProvider';

import { Notifications } from '../../config/utils';
// import { authentication } from '../common/redux/Auth';
// import { hideLoader } from '../common/redux/Loader';
// import {
//   disconnectWallet,
//   getNetwork,
//   getTokenFromBalance,
//   getTokenToBalance,
//   setAddress,
//   setWeb3Object,
// } from './redux';

import {
  disconnectWallet,
  AddWalletAddress,
  newWeb3ObjectAction,
} from './WalletSlice';

import Web3 from 'web3';

const useConnectWalletModal = ({
  dispatch,
  selectedWallet,
  getUpdatedAccountBalance,
  getToUpdatedBalance,
  tokenFrom,
  tokenTo,
}) => {
  const processDappConnection = async ({
    accountSelected,
    networkId,
    web3Object,
  }) => {
    const web3 =
      web3Object ||
      getweb3Provider({
        walletselect: selectedWallet,
        blockchainNetwork: DEFAULT_NETWORK,
      });
    const correctNetworkId = await checkNetwork({
      blockchainNetwork: DEFAULT_NETWORK,
      networkGeneric: true,
      networkId: networkId,
      web3,
    });
    const provider = await getMetaAndCoinProvider();
    console.log('provider', provider);
    if (!correctNetworkId && web3) {
      // dispatch(
      //   disconnectWallet({
      //     from: `tokenFromBalance:${tokenFrom?.shortName}`,
      //     to: `tokenToBalance:${tokenTo?.shortName}`,
      //   })
      // );
      await getNetworkFromExtensionProvider(provider);
    }

    const accounts = accountSelected;
    // || (await getAccountsFromExtensionProvider(provider));
    if (accounts && accounts[0]) {
      const account = accounts[0];
      dispatch(AddWalletAddress(account));
      dispatch(newWeb3ObjectAction(web3));
    }

    // dispatch(authentication(account));
    if (correctNetworkId) {
      const networkName = getNetworkName(parseInt(correctNetworkId));
      // dispatch(getNetwork(networkName));
    }
    // else dispatch(getNetwork('Polygon Mumbai'));
    // await getAccountBalance();
    // await getToBalance();
  };

  const disconnect = ({ provider }) => {
    if (provider) {
      provider.close();
    }
    if (window.ethereum) {
      window.ethereum.close();
    }
    dispatch(
      disconnectWallet({
        from: `tokenFromBalance:${tokenFrom?.shortName}`,
        to: `tokenToBalance:${tokenTo?.shortName}`,
      })
    );
  };

  const getNetworkName = (networkId) => {
    switch (networkId) {
      case 1:
        return 'Ethereum Mainnet';
      case 3:
        return 'Ropsten';
      case 4:
        return 'Rinkeby';
      case 5:
        return 'Goerli';
      case 42:
        return 'Kovan';
      case 137:
        return 'Polygon Mainnet';
      case 11155111:
        return 'Sepolia';
      case 59140:
        return 'Linea Goerli Test Network';
      case 80001:
        return 'Polygon Mumbai';
      default:
        return 'Invalid';
    }
  };

  // const getAccountBalance = async () => {
  //   const cachedTokenFromBalance = localStorage.getItem(
  //     `tokenFromBalance:${tokenFrom?.shortName}`
  //   );
  //   if (cachedTokenFromBalance) {
  //     dispatch(getTokenFromBalance(parseFloat(cachedTokenFromBalance)));
  //   } else {
  //     await getUpdatedAccountBalance();
  //   }
  // };

  // const getToBalance = async () => {
  //   const cachedTokenToBalance = localStorage.getItem(
  //     `tokenToBalance:${tokenTo?.shortName}`
  //   );

  //   if (cachedTokenToBalance) {
  //     dispatch(getTokenToBalance(parseFloat(cachedTokenToBalance)));
  //   } else {
  //     await getToUpdatedBalance();
  //   }
  // };

  // getAccountsFromExtensionProvider need not have the arg selectedWallet if its state is within this hook

  const getMetaAndCoinProvider = async (selectedWallet) => {
    let provider;

    if (
      selectedWallet === 'Metamask' ||
      localStorage.getItem('selected_wallet') === 'Metamask'
    ) {
      provider = await metaMaskProvider;
    } else {
      provider = await coinbaseProvider;
    }

    return provider;
  };
  const getNetworkFromExtensionProvider = async (provider) => {
    await provider?.request({
      method: 'wallet_switchEthereumChain',
      params: [
        { chainId: Web3.utils.toHex(parseInt(CHAIN_ID[DEFAULT_NETWORK])) },
      ],
    });
  };

  const getAccountsFromExtensionProvider = async (provider) => {
    let accounts;

    accounts = await provider?.request({
      method: 'eth_requestAccounts',
    });

    return accounts;
  };

  return {
    processDappConnection,
    getAccountsFromExtensionProvider,
    // getToBalance,
    // getAccountBalance,
    getNetworkName,
    disconnect,
    getMetaAndCoinProvider,
    getNetworkFromExtensionProvider,
  };
};

export default useConnectWalletModal;
