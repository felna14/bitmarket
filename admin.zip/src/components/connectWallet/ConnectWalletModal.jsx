import React, { useEffect, useState } from 'react';
import CustomModal from '../common/CustomModal';
import {
  EthereumClient,
  w3mConnectors,
  w3mProvider,
} from '@web3modal/ethereum';
import { configureChains, createClient, WagmiConfig } from 'wagmi';
import Web3Modal from 'web3modal';

import web3ObjectAction, { newWeb3ObjectAction } from './WalletSlice';
import { Web3Modal as Web3ConnectWallet, useWeb3Modal } from '@web3modal/react';

import { arbitrum, mainnet, polygon } from 'wagmi/chains';
import { useMetamask } from 'use-metamask';
import CoinbaseWalletSDK from '@coinbase/wallet-sdk';
import { ethers } from 'ethers';
import { useDispatch } from 'react-redux';
import {
  AddSelectedWallet,
  AddWalletAddress,
  disconnectWallet,
} from './WalletSlice';
import { Notifications } from '../../config/utils';

import crypto1 from '../../assets/img/crypto1.png';
import crypto2 from '../../assets/img/crypto2.png';
import crypto3 from '../../assets/img/crypto3.png';
import '../../assets/scss/login.scss';
import Web3 from 'web3';
import {
  WalletConnectProviderWithInfura,
  WalletConnectWeb3,
} from '../Contractor/walletConnect';
import { DEFAULT_NETWORK, checkNetwork, getNetworkId } from '../Contractor';

const chains = [arbitrum, mainnet, polygon];
const projectId = 'b9f582f8624bc050a0c2ba01e01665a3';

const { provider } = configureChains(chains, [w3mProvider({ projectId })]);
const wagmiClient = createClient({
  autoConnect: true,
  connectors: w3mConnectors({ projectId, version: 1, chains }),
  provider,
});
const ethereumClient = new EthereumClient(wagmiClient, chains);

const providerOptions = {
  Metamask: {
    package: useMetamask,
  },
  coinbasewallet: {
    package: CoinbaseWalletSDK,
  },
};

const isCoinbaseWalletInstalled = () => {
  return Boolean(window.ethereum && window.coinbaseWalletExtension);
};
const isMetamaskInstalled = () => {
  return Boolean(window.ethereum && window.ethereum.isMetaMask);
};

const ConnectWalletModal = ({ showModal, closeModal }) => {
  const dispatch = useDispatch();
  const [walletAddress, setWalletAddress] = useState(null);
  const [selectedWallet, setSelectedWallet] = useState('Metamask');

  useEffect(() => {
    if (walletAddress !== null && walletAddress !== undefined) {
      dispatch(AddWalletAddress(walletAddress));
      closeModal(true);
    }
    dispatch(AddSelectedWallet(selectedWallet));
  }, [walletAddress, selectedWallet]);

  useEffect(() => {
    const wallet_address = localStorage.getItem("wallet_address")
    try {
      if (
        typeof window.ethereum !== 'undefined' &&
        typeof window.ethereum.selectedAddress !== 'undefined'&& wallet_address.length
      ) {
        const web3 = new Web3(window.ethereum);

        web3.eth
          .getAccounts()
          .then((accounts) => {
            if (accounts.length > 0) {
              setWalletAddress(accounts[0]);
            } else {
              setWalletAddress(null);
            }
          })
          .catch((error) => {
            // console.error('Failed to fetch wallet address:', error);
          });
      } else {
        dispatch(disconnectWallet());
        dispatch(AddWalletAddress(null));
      }
    } catch (error) {
      // console.log('Error:', error);
    }
  }, [window.ethereum?.selectedAddress]);


  const handleWalletSelection = (wallet) => {
    setSelectedWallet(wallet);
  };

  async function connectWallet() {
    try {
      const web3Modal = new Web3Modal({
        cacheProvider: false,
        providerOptions: providerOptions,
      });

      const web3ModalInstance = await web3Modal.connect();
      const web3ModalProvider = new ethers.providers.Web3Provider(
        web3ModalInstance
      );

      if (web3ModalProvider) {
        closeModal(false);
        setWalletAddress(web3ModalProvider.provider.selectedAddress);
      }
    } catch (error) {}
  }

  const handleConnectClick = async () => {
    if (selectedWallet) {
      if (selectedWallet === 'Metamask') {
        if (isMetamaskInstalled()) {
          const coinbaseProvider = window.ethereum?.providers?.find(
            (x) => x.isCoinbaseWallet
          );
          if (coinbaseProvider && coinbaseProvider._addresses.length > 0) {
            Notifications(
              'Please Disconnect Coinbase Wallet before connecting Metamask.',
              'error'
            );
            return;
          }
          await connectWallet('metamask');
        } else {
          Notifications('Please Install / Enable Metamask Extension', 'error');
        }
      }
      if (selectedWallet === 'Coinbase Wallet') {
        const metamaskProvider = window.ethereum?.providers?.find(
          (x) => x.isMetaMask
        );
        if (metamaskProvider && metamaskProvider._state.accounts.length > 0) {
          Notifications(
            'Please Disconnect Metamask before connecting Coinbase Wallet.',
            'error'
          );
          return;
        }
        if (isCoinbaseWalletInstalled()) {
          await connectWallet('coinbase');
        } else {
          Notifications('Please Install / Enable Coinbase Extension', 'error');
        }
      }

      if (selectedWallet === 'Walletconnect') {
        if (isCoinbaseWalletInstalled()) {
          await connectWallet();
        } else {
          Notifications('Please Install Walletconnect');
        }
      }
    }
  };

  const connectWalletConnectProvider = async () => {
    WalletConnectProviderWithInfura(false);
    const provider = WalletConnectProviderWithInfura();
    const enabled = await provider.enable();
    const web3 = WalletConnectWeb3(provider);

    dispatch(newWeb3ObjectAction(web3));

    const accounts = await web3.eth.getAccounts();
    const account = accounts[0];

    if (account) {
      const networkId = await getNetworkId({
        web3,
      });
      setWalletAddress(account);

      // const networkName = getNetworkName(parseInt(networkId));
      // dispatch(getNetwork(networkName));

      // dispatch(authentication(account));
      closeModal(false);
      const incorrectNetwork = await checkNetwork({
        blockchainNetwork: DEFAULT_NETWORK,
        networkGeneric: true,
        networkId,
        web3,
      });
      if (!incorrectNetwork) {
        dispatch(AddWalletAddress(account));

        // await getAccountBalance();
        // await getToBalance();

        // dispatch(getNetwork(networkName));
        dispatch(AddSelectedWallet(selectedWallet));
      } else {
        Notifications(
          'Please choose the blockchain network ' +
            process.env.REACT_APP_BLOCKCHAIN_NETWORK,
          'error'
        );
        // dispatch(hideLoader());

        // dispatch(
        //   disconnectWallet({
        //     from: `tokenFromBalance:${tokenFrom?.shortName}`,
        //     to: `tokenToBalance:${tokenTo?.shortName}`,
        //   })
        // );
        dispatch(disconnectWallet());
      }
    }
    provider.on('accountsChanged', async (accounts) => {
      const account = accounts[0];
      const web3 = WalletConnectWeb3(provider);
      const networkId = await getNetworkId({
        web3,
      });
      const incorrectNetwork = await checkNetwork({
        blockchainNetwork: DEFAULT_NETWORK,
        networkGeneric: true,
        networkId,
        web3,
      });

      // const networkName = getNetworkName(parseInt(networkId));
      // dispatch(getNetwork(networkName));
      if (!incorrectNetwork) {
        // await getAccountBalance();
        // await getToBalance();

        dispatch(AddWalletAddress(account));

        // dispatch(getNetwork(networkName));
        dispatch(AddSelectedWallet(selectedWallet));
      } else {
        Notifications(
          'Please choose the blockchain network ' +
            process.env.REACT_APP_BLOCKCHAIN_NETWORK,
          'error'
        );
        // dispatch(hideLoader());

        // dispatch(
        //   disconnectWallet({
        //     from: `tokenFromBalance:${tokenFrom?.shortName}`,
        //     to: `tokenToBalance:${tokenTo?.shortName}`,
        //   })
        // );
        dispatch(disconnectWallet());
        return null;
      }
    });
  };

  const renderBody = () => {
    return (
      <div className="">
        <WagmiConfig client={wagmiClient}>
          <h5 className="title-txt">Connect a wallet</h5>
          <div className="card-block">
            <div
              className={`card-list ${
                selectedWallet === 'Metamask' ? 'active-wallet' : ''
              } `}
              onClick={() => handleWalletSelection('Metamask')}
            >
              <div className="card-img">
                <img
                  src={crypto3}
                  alt=""
                />
              </div>
              <div className="card-txt ">Metamask</div>
            </div>
            {process.env.REACT_APP_COINBASE_WALLET === 'true' && (
            <div
              className={`card-list ${
                selectedWallet === 'Coinbase Wallet' ? 'active-wallet' : ''
              } `}
              onClick={() => handleWalletSelection('Coinbase Wallet')}
            >
              <div className="card-img">
                <img src={crypto1} alt="" />
              </div>
              <div className="card-txt ">Coinbase Wallet</div>
            </div>)}
            <div
              className={`card-list ${
                selectedWallet === 'Walletconnect' ? 'active-wallet' : ''
              } `}
              onClick={() => handleWalletSelection('Walletconnect')}
            >
              <div className="card-img">
                <img src={crypto2} alt="" />
              </div>
              <div className="card-txt">Walletconnect</div>
            </div>
          </div>

          {selectedWallet === 'Walletconnect' ? (
            <>
              <button
                className="btn btn-def btn-submit"
                onClick={() => connectWalletConnectProvider()}
              >
                Connect
              </button>
            </>
          ) : (
            <button
              className="btn btn-def btn-submit"
              onClick={() => {
                handleConnectClick();
              }}
            >
              Connect
            </button>
          )}
        </WagmiConfig>
      </div>
    );
  };

  return (
    <div>
      <CustomModal
        className="modal fade custom-modal wallet-connect-modal"
        dialgName="modal-dialog modal-xl modal-dialog-centered"
        createModal
        show={!!showModal}
        closeModal={() => {
          closeModal(false);
          setSelectedWallet(null);
        }}
        body={renderBody()}
      />
    </div>
  );
};

export default ConnectWalletModal;
